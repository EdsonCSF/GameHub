import { useMemo, useState } from 'react';
import { SLOTS, SLOT_LABEL, RARITIES, type Slot } from '../game/items';
import { SKILLS, BRANCHES, ETERNALS, eternalCost } from '../game/skills';
import { ZONES } from '../game/world';
import { fmt } from '../game/rng';
import { audio } from '../game/audio';
import type { Game, Snapshot } from '../game/engine';
import { ItemCard, ItemIcon, SectionTitle, SlotBadge, Bar } from './ui';
import { StatusStrip } from './Hud';
import { metalUrl, ASSETS } from '../game/assets';

export function Panel({ title, subtitle, onClose, children }: {
  title: string; subtitle?: string; onClose: () => void; children: React.ReactNode;
}) {
  return (
    <div className="absolute inset-0 z-20 flex flex-col justify-end">
      <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px]" onClick={onClose} />
      <div
        className="relative max-h-[82%] overflow-hidden rounded-t-3xl border-t border-amber-200/20 bg-[#0b0a0e] shadow-[0_-20px_60px_rgba(0,0,0,0.7)]"
        style={{
          backgroundImage: `radial-gradient(120% 60% at 50% 0%, rgba(255,140,60,0.14), transparent 70%), linear-gradient(180deg, rgba(10,9,12,0.78), rgba(8,7,10,0.92)), url(${metalUrl})`,
          backgroundSize: 'auto, auto, 420px',
        }}
      >
        <div className="pointer-events-none absolute inset-x-10 top-0 h-px bg-gradient-to-r from-transparent via-amber-300/60 to-transparent" />
        <div className="mx-auto mt-2 h-1 w-10 rounded-full bg-white/20" />
        <div className="flex items-start justify-between gap-3 border-b border-white/10 px-4 pb-3 pt-3">
          <div>
            <h2 className="font-mono text-[13px] font-bold uppercase tracking-[0.2em] text-amber-200/90">{title}</h2>
            {subtitle && <p className="mt-0.5 font-mono text-[10px] text-white/40">{subtitle}</p>}
          </div>
          <button onClick={onClose} className="rounded-lg border border-white/10 bg-black/50 px-3 py-1.5 font-mono text-[11px] text-white/60 active:scale-95">
            fechar ✕
          </button>
        </div>
        <div className="max-h-[calc(82vh-64px)] overflow-y-auto overscroll-contain px-4 pb-8 pt-3">{children}</div>
      </div>
    </div>
  );
}

// ============================================================
//  MOCHILA
// ============================================================
export function BagPanel({ snap, game }: { snap: Snapshot; game: Game }) {
  const [filter, setFilter] = useState<Slot | 'todos'>('todos');
  const items = useMemo(
    () => snap.inventory.filter((i) => filter === 'todos' || i.slot === filter).sort((a, b) => b.score - a.score),
    [snap.inventory, filter],
  );
  return (
    <>
      <div
        className="relative flex items-stretch justify-between gap-2 overflow-hidden rounded-2xl border border-white/10 p-2"
        style={{ background: 'radial-gradient(60% 70% at 50% 60%, rgba(255,130,50,0.22), rgba(0,0,0,0.55) 70%)' }}
      >
        <div className="flex flex-col justify-between gap-1.5">
          {SLOTS.slice(0, 3).map((s) => <SlotBadge key={s} slot={s} item={snap.equipped[s]} />)}
        </div>
        <div className="relative flex flex-1 items-end justify-center">
          <div className="absolute bottom-1 h-4 w-28 rounded-[50%] bg-black/60 blur-[2px]" />
          {ASSETS?.heroFull ? (
            <img src={ASSETS.heroFull} alt="Guardião" className="relative z-10 h-[190px] object-contain drop-shadow-[0_0_18px_rgba(255,140,60,0.35)]" />
          ) : (
            <div className="h-[190px]" />
          )}
          <div className="absolute left-1/2 top-1 z-20 -translate-x-1/2 rounded-full border border-amber-300/30 bg-black/60 px-2.5 py-0.5 font-mono text-[10px] text-amber-200">
            nível {snap.level} · poder {Object.values(snap.equipped).reduce((a, it) => a + (it ? it.score : 0), 0)}
          </div>
        </div>
        <div className="flex flex-col justify-between gap-1.5">
          {SLOTS.slice(3).map((s) => <SlotBadge key={s} slot={s} item={snap.equipped[s]} />)}
        </div>
      </div>

      <div className="mt-3 flex items-center gap-2">
        <button
          onClick={() => game.toggleAutoEquip()}
          className="flex-1 rounded-lg border px-2 py-1.5 font-mono text-[10px] uppercase tracking-wider active:scale-95"
          style={{
            borderColor: snap.autoEquip ? 'rgba(255,180,90,0.5)' : 'rgba(255,255,255,0.12)',
            color: snap.autoEquip ? '#ffc98a' : 'rgba(255,255,255,0.45)',
            background: snap.autoEquip ? 'rgba(255,150,60,0.12)' : 'rgba(0,0,0,0.35)',
          }}
        >
          auto-equipar {snap.autoEquip ? 'ON' : 'OFF'}
        </button>
        <button
          onClick={() => game.sellAll(1)}
          className="flex-1 rounded-lg border border-white/10 bg-black/40 px-2 py-1.5 font-mono text-[10px] uppercase tracking-wider text-white/55 active:scale-95"
        >
          vender comuns
        </button>
      </div>

      <div className="mt-3 flex gap-1 overflow-x-auto pb-1">
        {(['todos', ...SLOTS] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f as Slot | 'todos')}
            className="shrink-0 rounded-full border px-2.5 py-1 font-mono text-[10px] active:scale-95"
            style={{
              borderColor: filter === f ? 'rgba(255,180,120,0.5)' : 'rgba(255,255,255,0.1)',
              color: filter === f ? '#ffc98a' : 'rgba(255,255,255,0.45)',
            }}
          >
            {f === 'todos' ? 'Tudo' : SLOT_LABEL[f]}
          </button>
        ))}
      </div>

      <div className="mt-3 space-y-1.5">
        <SectionTitle right={<span className="font-mono text-[10px] text-white/35">{items.length} itens</span>}>
          Achados
        </SectionTitle>
        {items.length === 0 && (
          <p className="rounded-lg border border-dashed border-white/10 p-4 text-center font-mono text-[11px] text-white/30">
            Nada aqui. A cinza guarda pouco — caçe mais.
          </p>
        )}
        {items.map((it) => {
          const cur = snap.equipped[it.slot];
          const better = !cur || it.score > cur.score;
          return (
            <div key={it.uid} className="flex items-center gap-1.5">
              <div className="min-w-0 flex-1">
                <ItemCard item={it} compare={cur} onClick={() => game.equip(it.uid)} actionLabel={better ? 'VESTIR ▸' : 'vestir'} />
              </div>
              <button
                onClick={() => game.sell(it.uid)}
                className="flex h-[46px] w-[42px] shrink-0 flex-col items-center justify-center rounded-lg border border-white/10 bg-black/40 text-[13px] text-amber-300/80 active:scale-95"
              >
                $
                <span className="font-mono text-[8px] text-white/35">{Math.round((8 + it.ilvl * 2.2) * (1 + it.rarity * 0.7))}</span>
              </button>
            </div>
          );
        })}
      </div>
    </>
  );
}

// ============================================================
//  ÁRVORE DE FOGO
// ============================================================
export function FirePanel({ snap, game }: { snap: Snapshot; game: Game }) {
  return (
    <>
      <div className="mb-3 flex items-center justify-between rounded-xl border border-amber-400/25 bg-amber-500/5 px-3 py-2">
        <div>
          <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-white/45">Pontos de Fogo</div>
          <div className="font-mono text-2xl font-bold text-amber-300">{snap.skillPoints}</div>
        </div>
        <p className="max-w-[52%] text-right font-mono text-[9px] leading-relaxed text-white/35">
          Cada nível concede 1 ponto. Invista sem medo: o fogo não julga.
        </p>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {BRANCHES.map((b) => {
          const nodes = SKILLS.filter((s) => s.branch === b.id).sort((a, c) => a.tier - c.tier);
          return (
            <div key={b.id} className="space-y-1.5">
              <div className="rounded-lg border px-2 py-1.5 text-center" style={{ borderColor: `${b.color}55`, background: `${b.color}12` }}>
                <div className="text-[14px]" style={{ color: b.color }}>{b.icon}</div>
                <div className="font-mono text-[10px] font-bold uppercase tracking-wider" style={{ color: b.color }}>{b.name}</div>
              </div>
              {nodes.map((n) => {
                const lvl = snap.skills[n.id] || 0;
                const maxed = lvl >= n.max;
                const locked = !!n.req && !(snap.skills[n.req] > 0);
                const can = !maxed && !locked && snap.skillPoints > 0;
                return (
                  <button
                    key={n.id}
                    disabled={!can}
                    onClick={() => game.learnSkill(n.id)}
                    className="w-full rounded-lg border p-2 text-left transition active:scale-[0.97]"
                    style={{
                      borderColor: locked ? 'rgba(255,255,255,0.07)' : maxed ? `${b.color}aa` : `${b.color}33`,
                      background: locked ? 'rgba(0,0,0,0.35)' : lvl > 0 ? `${b.color}14` : 'rgba(0,0,0,0.45)',
                      opacity: locked ? 0.45 : 1,
                    }}
                  >
                    <div className="flex items-baseline justify-between gap-1">
                      <span className="truncate font-mono text-[10px] font-bold" style={{ color: locked ? 'rgba(255,255,255,0.4)' : b.color }}>
                        {n.name}
                      </span>
                      <span className="shrink-0 font-mono text-[9px] text-white/40">{lvl}/{n.max}</span>
                    </div>
                    <div className="mt-1">
                      <Bar pct={lvl / n.max} color={b.color} h={3} />
                    </div>
                    <p className="mt-1 font-mono text-[9px] leading-tight text-white/45">
                      {locked ? `requer ${SKILLS.find((s) => s.id === n.req)?.name}` : n.desc(Math.max(1, lvl + 1))}
                    </p>
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>
    </>
  );
}

// ============================================================
//  MAPA
// ============================================================
export function MapPanel({ snap, game }: { snap: Snapshot; game: Game }) {
  return (
    <>
      <SectionTitle right={<span className="font-mono text-[10px] text-white/35">ciclo {snap.cycle}</span>}>
        Regiões do Colapso
      </SectionTitle>
      <div className="space-y-2">
        {ZONES.map((z) => {
          const locked = z.id > snap.unlocked;
          const current = z.id === snap.zoneId;
          const lvlOk = snap.level >= z.reqLevel;
          return (
            <div
              key={z.id}
              className="relative overflow-hidden rounded-xl border p-3"
              style={{
                borderColor: current ? 'rgba(255,180,120,0.5)' : locked ? 'rgba(255,255,255,0.07)' : 'rgba(255,255,255,0.14)',
                background: current
                  ? 'linear-gradient(100deg, rgba(255,150,60,0.14), rgba(0,0,0,0.5))'
                  : `linear-gradient(100deg, ${z.fog}, rgba(0,0,0,0.55))`,
                opacity: locked ? 0.5 : 1,
              }}
            >
              <div className="flex items-start gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-black/50 text-[18px]" style={{ color: z.accent }}>
                  {z.emblem}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="truncate font-mono text-[12px] font-bold text-white/85">{z.name}</h4>
                    <span className="shrink-0 rounded border border-white/10 px-1 font-mono text-[9px] text-white/40">T{z.tier}</span>
                  </div>
                  <p className="mt-0.5 font-mono text-[10px] italic leading-tight text-white/40">{z.desc}</p>
                  <div className="mt-1.5 flex items-center gap-2">
                    <span className="font-mono text-[9px] text-white/35">nível {z.reqLevel}+</span>
                    {locked && <span className="font-mono text-[9px] text-rose-400/80">derrote o chefe anterior</span>}
                  </div>
                </div>
                {!locked && !current && (
                  <button
                    onClick={() => game.travel(z.id)}
                    disabled={!lvlOk}
                    className="shrink-0 self-center rounded-lg border border-amber-300/40 bg-amber-500/10 px-3 py-1.5 font-mono text-[10px] uppercase tracking-wider text-amber-200 active:scale-95 disabled:opacity-30"
                  >
                    {lvlOk ? 'viajar' : `nível ${z.reqLevel}`}
                  </button>
                )}
                {current && <span className="shrink-0 self-center font-mono text-[10px] uppercase tracking-wider text-amber-300/90">aqui</span>}
              </div>
            </div>
          );
        })}
      </div>
      <p className="mt-3 rounded-lg border border-white/10 bg-black/40 p-2.5 font-mono text-[10px] leading-relaxed text-white/40">
        Cada 40 abates numa região invoca o seu <span className="text-rose-400/90">Colosso</span>. Vencê-lo revela a estrada seguinte
        e rende <span className="text-orange-400/90">1 Cinza Eterna</span> + relíquias garantidas.
      </p>
    </>
  );
}

// ============================================================
//  ETERNO (prestígio)
// ============================================================
export function EternalPanel({ snap, game }: { snap: Snapshot; game: Game }) {
  const [confirm, setConfirm] = useState(false);
  const gain = game.eternaGain();
  return (
    <>
      <div className="mb-3 flex items-center justify-between rounded-xl border border-orange-400/30 bg-orange-500/5 px-3 py-2.5">
        <div>
          <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-white/45">Cinzas Eternas</div>
          <div className="font-mono text-2xl font-bold text-orange-400">✦ {snap.eterna}</div>
        </div>
        <div className="text-right">
          <div className="font-mono text-[10px] text-white/45">ciclo atual</div>
          <div className="font-mono text-xl font-bold text-white/80">{snap.cycle}</div>
        </div>
      </div>

      <SectionTitle>Forja do Renascimento</SectionTitle>
      <div className="space-y-1.5">
        {ETERNALS.map((e) => {
          const lvl = snap.eternums[e.id] || 0;
          const maxed = lvl >= e.max;
          const cost = eternalCost(e, lvl);
          const can = !maxed && snap.eterna >= cost;
          return (
            <button
              key={e.id}
              disabled={!can}
              onClick={() => game.buyEternal(e.id)}
              className="flex w-full items-center gap-2.5 rounded-lg border p-2 text-left active:scale-[0.98] disabled:opacity-45"
              style={{
                borderColor: maxed ? 'rgba(255,140,60,0.6)' : can ? 'rgba(255,140,60,0.3)' : 'rgba(255,255,255,0.08)',
                background: lvl > 0 ? 'rgba(255,140,60,0.07)' : 'rgba(0,0,0,0.4)',
              }}
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-black/50 text-[15px]">{e.icon}</span>
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline gap-2">
                  <span className="truncate font-mono text-[11px] font-bold text-white/85">{e.name}</span>
                  <span className="font-mono text-[9px] text-white/40">{lvl}/{e.max}</span>
                </div>
                <p className="font-mono text-[9px] text-white/45">{e.desc(lvl + 1)}</p>
              </div>
              <span className="shrink-0 font-mono text-[10px] font-bold text-orange-300">
                {maxed ? 'MAX' : `✦${cost}`}
              </span>
            </button>
          );
        })}
      </div>

      <div className="mt-4 rounded-xl border border-rose-400/25 bg-rose-500/5 p-3">
        <SectionTitle>Renascar o Ciclo</SectionTitle>
        <p className="font-mono text-[10px] leading-relaxed text-white/45">
          Apagar o farol e reacender do zero: você perde nível, itens e habilidades, mas as <span className="text-orange-300">Cinzas Eternas</span> e
          o ciclo permanecem. Inimigos ficam <span className="text-rose-300">85% mais fortes</span> por ciclo — e você muito mais.
        </p>
        {!confirm ? (
          <button
            onClick={() => setConfirm(true)}
            disabled={gain <= 0}
            className="mt-2.5 w-full rounded-lg border border-rose-400/40 bg-rose-600/20 py-2.5 font-mono text-[12px] font-bold uppercase tracking-[0.15em] text-rose-200 active:scale-95 disabled:opacity-35"
          >
            renascer por ✦{gain}
          </button>
        ) : (
          <div className="mt-2.5 flex gap-2">
            <button
              onClick={() => { game.renascer(); setConfirm(false); }}
              className="flex-1 rounded-lg border border-rose-400/60 bg-rose-600/30 py-2.5 font-mono text-[11px] font-bold uppercase tracking-wider text-white active:scale-95"
            >
              confirmar
            </button>
            <button onClick={() => setConfirm(false)} className="rounded-lg border border-white/15 bg-black/40 px-4 py-2.5 font-mono text-[11px] text-white/60 active:scale-95">
              não
            </button>
          </div>
        )}
      </div>
    </>
  );
}

// ============================================================
//  STATUS / OPÇÕES
// ============================================================
const STAT_ROWS: [string, string][] = [
  ['Potência', 'power'], ['Vel. ataque', 'atkSpeed'], ['Crítico', 'crit'], ['Dano crít.', 'critDmg'],
  ['Armadura', 'armor'], ['Vida máx.', 'maxHp'], ['Regeneração', 'hpRegen'], ['Mobilidade', 'speed'],
  ['Sorte', 'luck'], ['Alcance', 'range'], ['Roubo de vida', 'lifesteal'], ['Espinhos', 'thorns'],
  ['Área', 'aoe'], ['Projéteis', 'proj'], ['XP', 'xpGain'], ['Sucata', 'scrapGain'],
];

export function InfoPanel({ snap, game, onReset, onOpenMenu }: { snap: Snapshot; game: Game; onReset: () => void; onOpenMenu?: () => void }) {
  const [music, setMusic] = useState(audio.musicVol);
  const [sfx, setSfx] = useState(audio.sfxVol);
  const [confirm, setConfirm] = useState(false);

  return (
    <>
      <SectionTitle right={<StatusStrip snap={snap} />}>O Guardião</SectionTitle>
      <div className="mb-3">
        <EquippedRow snap={snap} game={game} />
      </div>
      <div className="mb-4 grid grid-cols-2 gap-1.5">
        {STAT_ROWS.map(([label, key]) => {
          const v = (snap.stats as unknown as Record<string, number>)[key];
          const isPct = ['crit', 'critDmg', 'lifesteal', 'xpGain', 'scrapGain', 'aoe'].includes(key);
          const val = key === 'critDmg' ? `${Math.round(v * 100)}%` : isPct ? `${Math.round(v * 100)}%` : fmt(v);
          return (
            <div key={key} className="flex items-center justify-between rounded-lg border border-white/8 bg-black/40 px-2.5 py-1.5">
              <span className="font-mono text-[10px] text-white/45">{label}</span>
              <span className="font-mono text-[11px] font-bold text-amber-100/90">{val}</span>
            </div>
          );
        })}
      </div>

      <div className="mb-4 grid grid-cols-3 gap-1.5">
        {[
          ['DPS', fmt(snap.dps), '#ff9a4a'],
          ['Recorde', fmt(snap.bestDps), '#ffd24a'],
          ['Abates', fmt(snap.totalKills), '#a678ff'],
        ].map(([l, v, c]) => (
          <div key={l} className="rounded-lg border border-white/8 bg-black/40 p-2 text-center">
            <div className="font-mono text-[9px] uppercase tracking-wider text-white/35">{l}</div>
            <div className="font-mono text-[14px] font-bold" style={{ color: c }}>{v}</div>
          </div>
        ))}
      </div>

      <SectionTitle>Som</SectionTitle>
      <div className="mb-4 space-y-2 rounded-xl border border-white/10 bg-black/40 p-3">
        <div>
          <div className="mb-1 flex justify-between font-mono text-[10px] text-white/50">
            <span>Música</span><span>{Math.round(music * 100)}%</span>
          </div>
          <input
            type="range" min={0} max={1} step={0.05} value={music}
            onChange={(e) => { const v = +e.target.value; setMusic(v); audio.setMusicVol(v); }}
            className="w-full accent-amber-400"
          />
        </div>
        <div>
          <div className="mb-1 flex justify-between font-mono text-[10px] text-white/50">
            <span>Efeitos</span><span>{Math.round(sfx * 100)}%</span>
          </div>
          <input
            type="range" min={0} max={1} step={0.05} value={sfx}
            onChange={(e) => { const v = +e.target.value; setSfx(v); audio.setSfxVol(v); }}
            className="w-full accent-amber-400"
          />
        </div>
        <button
          onClick={() => { audio.enabled = !audio.enabled; audio.ui(audio.enabled); }}
          className="w-full rounded-lg border border-white/15 bg-black/40 py-1.5 font-mono text-[10px] uppercase tracking-wider text-white/55 active:scale-95"
        >
          ligar / desligar áudio
        </button>
      </div>

      <SectionTitle>Diário do Farol</SectionTitle>
      <div className="mb-4 space-y-1.5 rounded-xl border border-white/10 bg-black/40 p-3 font-mono text-[10px] leading-relaxed text-white/45">
        <p><span className="text-amber-200/80">Ciclo {snap.cycle}:</span> o mundo terminou numa terça-feira. Ninguém percebeu — havia fumaça demais.</p>
        <p>Você carrega o último núcleo de fogo. Enquanto ele queimar, a cinza não vence.</p>
        <p>Deixe o <span className="text-amber-300">auto</span> ligado: o Guardião caça sozinho, mesmo com você longe.</p>
      </div>

      {onOpenMenu && (
        <button
          onClick={onOpenMenu}
          className="mb-2 w-full rounded-lg border border-amber-300/30 bg-amber-500/10 py-2 font-mono text-[10px] uppercase tracking-wider text-amber-200 active:scale-95"
        >
          voltar ao menu inicial
        </button>
      )}
      {!confirm ? (
        <button
          onClick={() => setConfirm(true)}
          className="w-full rounded-lg border border-white/10 bg-black/40 py-2 font-mono text-[10px] uppercase tracking-wider text-white/40 active:scale-95"
        >
          apagar progresso
        </button>
      ) : (
        <div className="flex gap-2">
          <button onClick={() => { game.hardReset(); onReset(); setConfirm(false); }} className="flex-1 rounded-lg border border-rose-400/50 bg-rose-600/20 py-2 font-mono text-[10px] uppercase tracking-wider text-rose-200 active:scale-95">
            apagar tudo
          </button>
          <button onClick={() => setConfirm(false)} className="rounded-lg border border-white/15 bg-black/40 px-4 py-2 font-mono text-[10px] text-white/55 active:scale-95">cancelar</button>
        </div>
      )}
    </>
  );
}

// ============================================================
//  Equipado (mini resumo usado no painel de status)
// ============================================================
export function EquippedRow({ snap, game }: { snap: Snapshot; game: Game }) {
  void game;
  return (
    <div className="flex gap-1.5 overflow-x-auto pb-1">
      {SLOTS.map((s) => {
        const it = snap.equipped[s];
        return (
          <div key={s} className="shrink-0 text-center">
            <div className="rounded-lg border border-white/10 bg-black/50 p-1" style={{ boxShadow: it ? `inset 0 0 10px ${RARITIES[it.rarity].glow}` : undefined }}>
              {it ? <ItemIcon item={it} size={40} /> : <div className="h-[40px] w-[40px]" />}
            </div>
            <div className="mt-0.5 font-mono text-[8px] text-white/35">{SLOT_LABEL[s]}</div>
          </div>
        );
      })}
    </div>
  );
}
