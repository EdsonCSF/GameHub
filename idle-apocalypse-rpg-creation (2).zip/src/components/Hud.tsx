import { useEffect, useRef } from 'react';
import { Bar } from './ui';
import { fmt, fmtTime } from '../game/rng';
import type { Snapshot, Game } from '../game/engine';
import { ZONES } from '../game/world';
import { metalUrl, ASSETS } from '../game/assets';

// ------------------------------------------------------------
//  Minimapa em tempo real (raster leve, destaca baús e inimigos)
// ------------------------------------------------------------
export function MiniMap({ game }: { game: Game }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    let raf = 0;
    const S = 80;
    const draw = () => {
      const c = ref.current;
      if (c) {
        const ctx = c.getContext('2d')!;
        ctx.clearRect(0, 0, S, S);
        const z = ZONES[game.state.zone];
        const range = 950;
        const px = (x: number) => ((x - game.px) / range) * (S / 2) + S / 2;
        const py = (y: number) => ((y - game.py) / range) * (S / 2) + S / 2;

        ctx.fillStyle = 'rgba(8,7,10,0.72)';
        ctx.fillRect(0, 0, S, S);

        // terreno e baús
        for (const p of game.world.propsNear(game.px, game.py, 1000)) {
          const x = px(p.x), y = py(p.y);
          if (x < 0 || y < 0 || x > S || y > S) continue;
          if (p.kind === 'caixa' && !p.open) {
            ctx.fillStyle = '#ffd24a';
            ctx.fillRect(x - 2, y - 2, 4, 4);
          } else {
            ctx.fillStyle = 'rgba(255,255,255,0.10)';
            ctx.fillRect(x - 0.75, y - 0.75, 1.5, 1.5);
          }
        }

        // inimigos
        for (const e of game.enemies) {
          const x = px(e.x), y = py(e.y);
          if (x < 0 || y < 0 || x > S || y > S) continue;
          ctx.fillStyle = e.isBoss ? '#ff2d55' : e.isElite ? '#ffd24a' : '#ff7a5c';
          const sz = e.isBoss ? 5 : e.isElite ? 3.5 : 2.2;
          ctx.fillRect(x - sz / 2, y - sz / 2, sz, sz);
        }

        // jogador
        ctx.fillStyle = z.accent;
        ctx.fillRect(S / 2 - 2, S / 2 - 2, 4, 4);
        ctx.strokeStyle = 'rgba(255,208,138,0.35)';
        ctx.beginPath();
        ctx.arc(S / 2, S / 2, 4.5 + Math.sin(performance.now() / 260) * 1.4, 0, Math.PI * 2);
        ctx.stroke();

        // moldura
        ctx.strokeStyle = 'rgba(255,255,255,0.12)';
        ctx.strokeRect(0.5, 0.5, S - 1, S - 1);
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [game]);

  return (
    <canvas
      ref={ref}
      width={80}
      height={80}
      className="pointer-events-none rounded-lg border border-white/10 bg-black/55 backdrop-blur-sm"
      style={{ width: 72, height: 72 }}
    />
  );
}

const PANELS = [
  { id: 'bag', label: 'Mochila', icon: '🜲' },
  { id: 'fire', label: 'Fogo', icon: '🜂' },
  { id: 'map', label: 'Mapa', icon: '✧' },
  { id: 'eternal', label: 'Eterno', icon: '∞' },
  { id: 'info', label: 'Status', icon: '☰' },
] as const;

export type PanelId = typeof PANELS[number]['id'] | null;

export function Hud({
  snap, game, panel, setPanel,
}: { snap: Snapshot; game: Game; panel: PanelId; setPanel: (p: PanelId) => void }) {
  const hpPct = snap.hp / snap.maxHp;
  const xpPct = snap.xp / snap.xpNeed;
  const bossPct = snap.boss ? snap.boss.hp / snap.boss.maxHp : 0;

  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col justify-between">
      {/* ---------- TOPO (periférico e compacto) ---------- */}
      <div className="flex flex-col gap-1.5 p-2 pt-[max(0.45rem,env(safe-area-inset-top))]">
        <div className="flex items-start justify-between gap-2">
          {/* Guardião */}
          <div className="pointer-events-auto w-[46%] max-w-[230px] rounded-xl border border-white/10 bg-black/55 p-1.5 backdrop-blur-sm">
            <div className="flex items-center gap-2">
              <div className="relative h-9 w-9 shrink-0 overflow-hidden rounded-lg border border-amber-400/50 bg-amber-500/10">
                {ASSETS?.heroFace && <img src={ASSETS.heroFace} alt="" className="h-full w-full object-cover" />}
                <span className="absolute bottom-0 right-0 rounded-tl bg-black/85 px-1 font-mono text-[8px] font-bold text-amber-300">
                  {snap.level}
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="mb-0.5 flex items-center justify-between">
                  <span className="font-mono text-[8px] uppercase tracking-wider text-white/50">Vida</span>
                  <span className="font-mono text-[8px] text-white/60">{fmt(snap.hp)}/{fmt(snap.maxHp)}</span>
                </div>
                <Bar pct={hpPct} color="linear-gradient(90deg,#ff5f3d,#ffb03d)" h={6} glow />
                <div className="mt-1">
                  <Bar pct={xpPct} color="linear-gradient(90deg,#5fd0ff,#a678ff)" h={3} />
                </div>
              </div>
            </div>
          </div>

          {/* Recursos e Bioma */}
          <div className="flex flex-col items-end gap-1">
            <div className="pointer-events-auto flex items-center gap-1.5 rounded-xl border border-white/10 bg-black/55 px-2 py-1 backdrop-blur-sm">
              <span className="font-mono text-[10px] text-amber-200">⚙ {fmt(snap.scrap)}</span>
              <span className="font-mono text-[10px] text-cyan-300">◈ {fmt(snap.essence)}</span>
              {snap.eterna > 0 && <span className="font-mono text-[10px] text-orange-400">✦ {fmt(snap.eterna)}</span>}
            </div>
            <div className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-black/45 px-2 py-0.5 text-right backdrop-blur-sm">
              <span className="font-mono text-[8px] uppercase tracking-wider text-white/50">
                {snap.zoneEmblem} {snap.zoneName}
              </span>
              <span className="font-mono text-[8px] text-white/30">·</span>
              <span
                className="font-mono text-[8px] uppercase"
                style={{ color: snap.boss ? '#ff6b85' : 'rgba(255,255,255,0.42)' }}
              >
                {snap.boss
                  ? '⚔ chefe'
                  : `${Math.max(0, snap.killsToBoss - (snap.killsInZone % snap.killsToBoss))} p/ chefe`}
              </span>
            </div>
          </div>
        </div>

        {/* ---------- BARRA DE CHEFE COMPACTA NO TOPO (não invade o centro!) ---------- */}
        {snap.boss && (
          <div
            className="mx-auto w-full max-w-md rounded-lg border px-2.5 py-1 backdrop-blur-sm"
            style={{
              borderColor: snap.boss.enraged ? 'rgba(255,40,60,0.65)' : 'rgba(255,60,80,0.32)',
              background: `linear-gradient(180deg, rgba(35,6,10,0.72), rgba(0,0,0,0.58)), url(${metalUrl}) center/cover`,
            }}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex min-w-0 items-center gap-1.5">
                <span className="truncate font-mono text-[10px] font-bold uppercase tracking-wide text-rose-100">
                  {snap.boss.name}
                </span>
                <span className="shrink-0 font-mono text-[8px] uppercase text-rose-300/65">
                  F{snap.boss.phase + 1}/3{snap.boss.enraged ? ' · FÚRIA' : ''}
                </span>
              </div>
              <span className="shrink-0 font-mono text-[9px] text-white/65">
                {snap.boss.spawning ? 'SURGINDO' : `${fmt(snap.boss.hp)} (${Math.ceil(bossPct * 100)}%)`}
              </span>
            </div>
            <div className="relative mt-1">
              <Bar
                pct={bossPct}
                color={snap.boss.enraged ? 'linear-gradient(90deg,#ff0033,#ff5a1f)' : 'linear-gradient(90deg,#c8102e,#ff4d4d,#ff8a3d)'}
                h={6}
                bg="rgba(0,0,0,0.6)"
                glow
              />
              {[0.66, 0.33].map((m) => (
                <div key={m} className="absolute top-[-1px] h-[8px] w-[1.5px] bg-white/65" style={{ left: `${m * 100}%` }} />
              ))}
            </div>
          </div>
        )}

        {/* ---------- FAIXA DE EVENTO DISCRETA NO TOPO (substitui o banner no meio da tela) ---------- */}
        {snap.banner && !snap.boss && (() => {
          const b = snap.banner;
          const alpha = Math.min(1, b.t / 0.4);
          return (
            <div
              className="mx-auto flex items-center gap-2 rounded-full border border-white/10 bg-black/65 px-3 py-0.5 backdrop-blur-sm"
              style={{ opacity: alpha }}
            >
              <span className="font-mono text-[9px] font-bold uppercase tracking-wider" style={{ color: b.color }}>
                {b.title}
              </span>
              <span className="font-mono text-[8px] text-white/45">{b.sub}</span>
            </div>
          );
        })()}
      </div>

      {/* ---------- BASE (radar, avisos discretos na lateral, habilidades e menu) ---------- */}
      <div className="p-2 pb-[max(0.35rem,env(safe-area-inset-bottom))]">
        <div className="mb-2 flex items-end justify-between gap-2">
          {/* Coluna esquerda: avisos de drop discretos + radar + botão auto */}
          <div className="flex flex-col items-start gap-1.5">
            {snap.notices.length > 0 && (
              <div className="flex max-w-[185px] flex-col items-start gap-0.5">
                {snap.notices.map((n) => (
                  <div
                    key={n.id}
                    className="truncate rounded border border-white/10 bg-black/55 px-2 py-0.5 font-mono text-[9px] backdrop-blur-sm"
                    style={{ color: n.color, opacity: Math.min(0.92, n.life), maxWidth: '185px' }}
                  >
                    {n.text}
                  </div>
                ))}
              </div>
            )}
            <div className="flex items-end gap-1.5">
              <MiniMap game={game} />
              <button
                onClick={() => game.toggleAuto()}
                className="pointer-events-auto flex h-[48px] w-[48px] flex-col items-center justify-center rounded-xl border backdrop-blur-sm active:scale-95"
                style={{
                  borderColor: snap.autoMode ? 'rgba(255,180,90,0.55)' : 'rgba(255,255,255,0.12)',
                  background: snap.autoMode ? 'rgba(255,150,60,0.16)' : 'rgba(0,0,0,0.5)',
                  boxShadow: snap.autoMode ? '0 0 14px rgba(255,150,60,0.22)' : undefined,
                }}
              >
                <span className="text-[14px] leading-none">🜂</span>
                <span className="mt-0.5 font-mono text-[8px] uppercase tracking-wider" style={{ color: snap.autoMode ? '#ffc98a' : 'rgba(255,255,255,0.4)' }}>
                  auto
                </span>
              </button>
            </div>
          </div>

          {/* Habilidades */}
          <div className="pointer-events-auto flex items-end gap-2">
            {snap.abilities.map((a) => {
              const locked = snap.level < a.unlock;
              const ready = a.cd <= 0 && !locked;
              const pct = a.cdMax > 0 ? 1 - a.cd / a.cdMax : 1;
              return (
                <button
                  key={a.id}
                  disabled={locked}
                  onClick={() => game.cast(a.id)}
                  className="relative flex h-[54px] w-[54px] items-center justify-center overflow-hidden rounded-2xl border backdrop-blur-sm active:scale-95"
                  style={{
                    borderColor: locked ? 'rgba(255,255,255,0.08)' : `${a.color}88`,
                    background: locked ? 'rgba(0,0,0,0.45)' : ready ? `${a.color}22` : 'rgba(0,0,0,0.55)',
                    boxShadow: ready ? `0 0 16px ${a.color}55` : undefined,
                  }}
                >
                  <span className="text-[19px] leading-none" style={{ color: locked ? 'rgba(255,255,255,0.2)' : a.color }}>{a.icon}</span>
                  {locked && (
                    <span className="absolute bottom-0.5 font-mono text-[8px] text-white/40">n{a.unlock}</span>
                  )}
                  {!locked && a.cd > 0 && (
                    <>
                      <div className="absolute inset-x-0 bottom-0 bg-black/70" style={{ height: `${(1 - pct) * 100}%` }} />
                      <span className="absolute inset-0 flex items-center justify-center font-mono text-[14px] font-bold text-white/85">
                        {a.cd.toFixed(a.cd < 3 ? 1 : 0)}
                      </span>
                    </>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Navegação */}
        <div className="pointer-events-auto grid grid-cols-5 gap-1 rounded-2xl border border-white/10 bg-black/60 p-1 backdrop-blur">
          {PANELS.map((p) => {
            const active = panel === p.id;
            const badge =
              p.id === 'fire' ? snap.skillPoints > 0 ? snap.skillPoints : 0 :
                p.id === 'eternal' ? snap.eterna > 0 ? 1 : 0 : 0;
            return (
              <button
                key={p.id}
                onClick={() => setPanel(active ? null : (p.id as PanelId))}
                className="relative flex flex-col items-center gap-0.5 rounded-xl py-1.5 transition active:scale-95"
                style={{
                  background: active ? 'rgba(255,160,80,0.14)' : 'transparent',
                  boxShadow: active ? 'inset 0 0 0 1px rgba(255,180,120,0.35)' : undefined,
                }}
              >
                <span className="text-[14px] leading-none" style={{ color: active ? '#ffbb7a' : 'rgba(255,255,255,0.55)' }}>{p.icon}</span>
                <span className="font-mono text-[8px] uppercase tracking-wider" style={{ color: active ? '#ffbb7a' : 'rgba(255,255,255,0.4)' }}>
                  {p.label}
                </span>
                {badge > 0 && (
                  <span className="absolute right-1 top-0.5 h-2 w-2 animate-pulse rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24]" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export function StatusStrip({ snap }: { snap: Snapshot }) {
  return (
    <div className="flex gap-2 font-mono text-[9px] text-white/35">
      <span>abates {fmt(snap.totalKills)}</span>
      <span>chefes {snap.bossKills}</span>
      <span>tempo {fmtTime(snap.playtime)}</span>
      {snap.cycle > 0 && <span className="text-orange-400/70">ciclo {snap.cycle}</span>}
    </div>
  );
}
