import { useEffect, useRef, useState } from 'react';
import { ASSETS, keyartUrl, metalUrl } from '../game/assets';
import { ZONES } from '../game/world';
import { audio } from '../game/audio';
import { fmt, fmtTime } from '../game/rng';
import type { Snapshot } from '../game/engine';

export function StartMenu({
  ready,
  snap,
  onStart,
}: {
  ready: boolean;
  snap: Snapshot | null;
  onStart: () => void;
}) {
  const fxCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [tab, setTab] = useState<'none' | 'guide' | 'biomes'>('none');
  const [soundOn, setSoundOn] = useState(audio.enabled);

  const hasProgress = !!snap && (snap.totalKills > 0 || snap.level > 1 || snap.seenIntro);

  // Canvas de atmosfera: feixe do farol, brasas ascendentes e cinzas caindo
  useEffect(() => {
    const c = fxCanvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d')!;
    let W = (c.width = window.innerWidth);
    let H = (c.height = window.innerHeight);

    const onResize = () => {
      if (!c) return;
      W = c.width = window.innerWidth;
      H = c.height = window.innerHeight;
    };
    window.addEventListener('resize', onResize);

    const embers = Array.from({ length: 55 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      vx: -12 + Math.random() * 28,
      vy: -(18 + Math.random() * 52),
      r: 1 + Math.random() * 2.6,
      a: 0.25 + Math.random() * 0.7,
      phase: Math.random() * Math.PI * 2,
      warm: Math.random() > 0.28,
    }));

    let raf = 0;
    let t = 0;
    const draw = () => {
      t += 0.016;
      ctx.clearRect(0, 0, W, H);

      // Feixe giratório suave do Último Farol no horizonte
      const lx = W * 0.5;
      const ly = H * 0.34;
      const sweep = Math.sin(t * 0.55) * 0.42;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.translate(lx, ly);
      ctx.rotate(sweep);
      const beam = ctx.createLinearGradient(0, 0, 0, -Math.max(W, H) * 0.75);
      beam.addColorStop(0, 'rgba(255,175,85,0.22)');
      beam.addColorStop(0.35, 'rgba(255,140,55,0.07)');
      beam.addColorStop(1, 'rgba(255,120,40,0)');
      ctx.fillStyle = beam;
      ctx.beginPath();
      ctx.moveTo(-8, 0);
      ctx.lineTo(-W * 0.42, -H * 0.7);
      ctx.lineTo(W * 0.42, -H * 0.7);
      ctx.lineTo(8, 0);
      ctx.closePath();
      ctx.fill();

      // Pulso do núcleo do farol
      const coreR = 26 + Math.sin(t * 4) * 5;
      const cg = ctx.createRadialGradient(0, 0, 1, 0, 0, coreR);
      cg.addColorStop(0, 'rgba(255,240,190,0.65)');
      cg.addColorStop(0.45, 'rgba(255,150,55,0.25)');
      cg.addColorStop(1, 'rgba(255,100,30,0)');
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.arc(0, 0, coreR, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Brasas e cinzas
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      for (const e of embers) {
        e.x += (e.vx + Math.sin(t * 2 + e.phase) * 10) * 0.016;
        e.y += e.vy * 0.016;
        if (e.y < -12) {
          e.y = H + 10;
          e.x = Math.random() * W;
        }
        if (e.x < -12) e.x = W + 10;
        if (e.x > W + 12) e.x = -10;

        const flicker = 0.65 + Math.sin(t * 6 + e.phase) * 0.35;
        ctx.globalAlpha = e.a * flicker;
        if (e.warm) {
          const g = ctx.createRadialGradient(e.x, e.y, 0, e.x, e.y, e.r * 2.8);
          g.addColorStop(0, '#fff4d2');
          g.addColorStop(0.45, '#ff8f35');
          g.addColorStop(1, 'rgba(255,90,20,0)');
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(e.x, e.y, e.r * 2.8, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle = 'rgba(215,208,196,0.55)';
          ctx.fillRect(e.x, e.y, e.r, e.r);
        }
      }
      ctx.restore();

      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
    };
  }, []);

  const toggleSound = () => {
    audio.enabled = !audio.enabled;
    setSoundOn(audio.enabled);
    if (audio.enabled) {
      audio.resume();
      audio.ui(true);
    }
  };

  return (
    <div className="absolute inset-0 z-50 flex flex-col justify-between overflow-hidden bg-[#070609] text-white">
      {/* Arte de fundo com movimento Ken Burns */}
      <div
        className="pointer-events-none absolute inset-0 scale-105 bg-cover bg-center"
        style={{
          backgroundImage: `url(${keyartUrl})`,
          animation: 'kenburns 24s ease-in-out infinite alternate',
        }}
      />

      {/* Gradientes cinematográficos */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'linear-gradient(180deg, rgba(6,5,8,0.72) 0%, rgba(8,7,10,0.12) 28%, rgba(8,7,10,0.68) 58%, rgba(7,6,9,0.97) 88%, #070609 100%)',
        }}
      />

      {/* Partículas e feixe do farol em tempo real */}
      <canvas ref={fxCanvasRef} className="pointer-events-none absolute inset-0 block" />

      {/* ---------- BARRA SUPERIOR ---------- */}
      <div className="relative z-10 flex items-center justify-between px-4 pt-[max(0.85rem,env(safe-area-inset-top))]">
        <div className="flex items-center gap-2 rounded-full border border-white/10 bg-black/55 px-3 py-1 backdrop-blur-md">
          <span className="h-2 w-2 rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24]" />
          <span className="font-mono text-[9px] uppercase tracking-[0.22em] text-amber-100/80">
            {snap && snap.cycle > 0 ? `Ciclo ${snap.cycle} · Crônica Viva` : 'Crônica do Colapso'}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setTab(tab === 'biomes' ? 'none' : 'biomes')}
            className="rounded-full border border-white/15 bg-black/55 px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-white/75 backdrop-blur-md active:scale-95"
            style={{
              borderColor: tab === 'biomes' ? 'rgba(255,180,90,0.55)' : undefined,
              color: tab === 'biomes' ? '#ffd08a' : undefined,
            }}
          >
            ✧ Regiões
          </button>
          <button
            onClick={() => setTab(tab === 'guide' ? 'none' : 'guide')}
            className="rounded-full border border-white/15 bg-black/55 px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-white/75 backdrop-blur-md active:scale-95"
            style={{
              borderColor: tab === 'guide' ? 'rgba(255,180,90,0.55)' : undefined,
              color: tab === 'guide' ? '#ffd08a' : undefined,
            }}
          >
            ? Guia
          </button>
          <button
            onClick={toggleSound}
            className="flex h-7 w-7 items-center justify-center rounded-full border border-white/15 bg-black/55 font-mono text-[12px] text-white/75 backdrop-blur-md active:scale-95"
            title="Alternar Som"
          >
            {soundOn ? '🔊' : '🔇'}
          </button>
        </div>
      </div>

      {/* ---------- TÍTULO CENTRAL / BRASÃO ---------- */}
      <div className="relative z-10 mx-auto flex max-w-md flex-col items-center px-6 text-center">
        {/* Emblema do Farol */}
        <div className="mb-2 flex items-center gap-3">
          <span className="h-px w-10 bg-gradient-to-r from-transparent to-amber-400/60" />
          <div className="flex h-8 w-8 items-center justify-center rounded-full border border-amber-300/40 bg-amber-500/15 shadow-[0_0_20px_rgba(255,145,50,0.4)]">
            <span className="text-sm text-amber-200">🜂</span>
          </div>
          <span className="h-px w-10 bg-gradient-to-l from-transparent to-amber-400/60" />
        </div>

        <p className="font-mono text-[9px] uppercase tracking-[0.45em] text-amber-200/60">
          action-rpg · idle · procedural
        </p>

        <h1
          className="mt-1 text-6xl font-black tracking-tighter text-transparent sm:text-7xl"
          style={{
            backgroundImage: 'linear-gradient(180deg, #fff8eb 0%, #ffb85c 48%, #e05a1b 82%, #611c08 100%)',
            WebkitBackgroundClip: 'text',
            backgroundClip: 'text',
            filter: 'drop-shadow(0 6px 24px rgba(255,110,30,0.38))',
          }}
        >
          CINZAS
        </h1>

        <div className="mt-0.5 flex items-center gap-2">
          <span className="h-px w-6 bg-amber-300/35" />
          <span className="font-mono text-[11px] font-bold uppercase tracking-[0.38em] text-amber-100/85">
            o último farol
          </span>
          <span className="h-px w-6 bg-amber-300/35" />
        </div>

        <p className="mt-3 max-w-xs font-mono text-[11px] leading-relaxed text-white/60">
          O mundo virou poeira que respira. Você carrega o último núcleo de fogo — e cada Colosso abatido mantém a chama viva.
        </p>
      </div>

      {/* ---------- RODAPÉ: GAVETA OPCIONAL + CARTÃO DO GUARDIÃO + BOTÃO PRINCIPAL ---------- */}
      <div className="relative z-10 mx-auto w-full max-w-md px-5 pb-[max(1.25rem,env(safe-area-inset-bottom))]">
        {/* Aba retrátil: Guia Rápido */}
        {tab === 'guide' && (
          <div
            className="mb-3 rounded-2xl border border-amber-300/25 p-3 text-left backdrop-blur-md"
            style={{
              background: `linear-gradient(180deg, rgba(16,14,20,0.92), rgba(8,7,10,0.96)), url(${metalUrl}) center/cover`,
            }}
          >
            <div className="mb-2 flex items-center justify-between">
              <span className="font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-amber-200">
                Guia de Sobrevivência
              </span>
              <button onClick={() => setTab('none')} className="font-mono text-[10px] text-white/45">
                fechar ✕
              </button>
            </div>
            <div className="grid grid-cols-2 gap-1.5 font-mono text-[10px] text-white/65">
              <div className="rounded-lg border border-white/10 bg-black/45 p-2">
                <div className="font-bold text-amber-300">① Movimento Livre</div>
                <p className="mt-0.5 text-[9px] text-white/45">Toque e arraste em qualquer ponto para guiar o Guardião.</p>
              </div>
              <div className="rounded-lg border border-white/10 bg-black/45 p-2">
                <div className="font-bold text-amber-300">② Modo AUTO (Idle)</div>
                <p className="mt-0.5 text-[9px] text-white/45">Caça, desvia de golpes e coleta baús sozinho — mesmo offline.</p>
              </div>
              <div className="rounded-lg border border-white/10 bg-black/45 p-2">
                <div className="font-bold text-amber-300">③ Baús e Relíquias</div>
                <p className="mt-0.5 text-[9px] text-white/45">Procure baús brilhantes no radar para sucata e itens raros.</p>
              </div>
              <div className="rounded-lg border border-white/10 bg-black/45 p-2">
                <div className="font-bold text-amber-300">④ Colossos (40 abates)</div>
                <p className="mt-0.5 text-[9px] text-white/45">3 fases de batalha. Vencê-los abre a próxima região do mapa.</p>
              </div>
            </div>
          </div>
        )}

        {/* Aba retrátil: Regiões */}
        {tab === 'biomes' && (
          <div
            className="mb-3 rounded-2xl border border-amber-300/25 p-3 text-left backdrop-blur-md"
            style={{
              background: `linear-gradient(180deg, rgba(16,14,20,0.92), rgba(8,7,10,0.96)), url(${metalUrl}) center/cover`,
            }}
          >
            <div className="mb-2 flex items-center justify-between">
              <span className="font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-amber-200">
                As 7 Regiões do Colapso
              </span>
              <button onClick={() => setTab('none')} className="font-mono text-[10px] text-white/45">
                fechar ✕
              </button>
            </div>
            <div className="flex gap-1.5 overflow-x-auto pb-1">
              {ZONES.map((z) => {
                const unlocked = !snap || z.id <= snap.unlocked;
                return (
                  <div
                    key={z.id}
                    className="w-[125px] shrink-0 rounded-xl border border-white/10 bg-black/55 p-2"
                    style={{ opacity: unlocked ? 1 : 0.45 }}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm" style={{ color: z.accent }}>{z.emblem}</span>
                      <span className="font-mono text-[8px] text-white/40">Nv.{z.reqLevel}+</span>
                    </div>
                    <div className="mt-1 truncate font-mono text-[10px] font-bold text-white/85">{z.name}</div>
                    <div className="mt-0.5 line-clamp-2 font-mono text-[8px] text-white/45">{z.desc}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Cartão metálico do Guardião (mostra o progresso salvo ou estado inicial) */}
        {snap && (
          <div
            className="mb-3 flex items-center gap-3 rounded-2xl border border-white/15 p-2.5 backdrop-blur-md"
            style={{
              background: `linear-gradient(95deg, rgba(255,145,55,0.12), rgba(10,9,13,0.88)), url(${metalUrl}) center/cover`,
              boxShadow: '0 10px 30px rgba(0,0,0,0.55)',
            }}
          >
            <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-xl border border-amber-400/50 bg-black/60">
              {ASSETS?.heroFace ? (
                <img src={ASSETS.heroFace} alt="Guardião" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-lg text-amber-300">🜂</div>
              )}
              <span className="absolute bottom-0 right-0 rounded-tl bg-black/85 px-1 font-mono text-[8px] font-bold text-amber-300">
                Nv.{snap.level}
              </span>
            </div>

            <div className="min-w-0 flex-1 text-left">
              <div className="flex items-center gap-1.5">
                <span className="truncate font-mono text-[11px] font-bold text-amber-100">
                  {snap.zoneEmblem} {snap.zoneName}
                </span>
                {snap.cycle > 0 && (
                  <span className="rounded bg-orange-500/20 px-1.5 py-0.5 font-mono text-[8px] text-orange-300">
                    Ciclo {snap.cycle}
                  </span>
                )}
              </div>
              <div className="mt-0.5 flex flex-wrap gap-x-3 gap-y-0.5 font-mono text-[9px] text-white/50">
                <span>⚔ {fmt(snap.totalKills)} abates</span>
                <span>👑 {snap.bossKills} colossos</span>
                <span>⏱ {fmtTime(snap.playtime)}</span>
              </div>
            </div>
          </div>
        )}

        {/* Botão Principal de Ação */}
        <button
          onClick={onStart}
          disabled={!ready}
          className="relative w-full overflow-hidden rounded-2xl border border-amber-300/60 px-6 py-4 font-mono text-[13px] font-black uppercase tracking-[0.26em] text-amber-50 shadow-[0_0_45px_rgba(255,130,40,0.35)] transition active:scale-[0.98] disabled:opacity-40"
          style={{
            background:
              'linear-gradient(180deg, rgba(255,165,65,0.42) 0%, rgba(215,85,20,0.38) 55%, rgba(95,30,10,0.55) 100%)',
          }}
        >
          <span className="relative z-10 flex items-center justify-center gap-2">
            <span>🜂</span>
            <span>
              {!ready
                ? 'forjando texturas e relíquias…'
                : hasProgress
                  ? 'continuar jornada'
                  : 'acender o farol'}
            </span>
          </span>
        </button>

        <div className="mt-2.5 flex items-center justify-between px-1 font-mono text-[9px] text-white/35">
          <span>toque livre · auto-piloto · offline</span>
          <span>7 biomas procedurais</span>
        </div>
      </div>
    </div>
  );
}
