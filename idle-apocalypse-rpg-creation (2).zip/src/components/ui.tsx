import { useEffect, useRef } from 'react';
import { RARITIES, SLOT_LABEL, type Item, statsDescription, type Slot } from '../game/items';
import { hash2 } from '../game/rng';
import { ASSETS } from '../game/assets';

// ------------------------------------------------------------
//  Ícone procedural do item (desenhado em canvas, único por seed)
// ------------------------------------------------------------
export function ItemIcon({ item, size = 46 }: { item: Item; size?: number }) {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = size * dpr;
    c.height = size * dpr;
    const ctx = c.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, size, size);
    const R = RARITIES[item.rarity];
    const s = item.seed;
    const S = size;
    const rnd = (a: number, b: number) => a + hash2(s, a * 31 + b * 17, 977) * (b - a);

    // ---- versão ilustrada
    const art = ASSETS?.items[item.slot];
    if (art) {
      ctx.fillStyle = '#0c0b0f';
      ctx.fillRect(0, 0, S, S);
      // halo de raridade atrás do objeto
      const halo = ctx.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S * 0.7);
      halo.addColorStop(0, R.glow);
      halo.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.save();
      ctx.translate(S / 2, S / 2);
      const flip = hash2(s, 1, 5) > 0.5 ? -1 : 1;
      ctx.rotate(rnd(-0.12, 0.12));
      ctx.scale(flip, 1);
      ctx.drawImage(art, -S / 2 - 2, -S / 2 - 2, S + 4, S + 4);
      ctx.restore();
      // tinta de raridade (itens raros ganham reflexo colorido)
      if (item.rarity >= 2) {
        ctx.save();
        ctx.globalCompositeOperation = 'overlay';
        ctx.globalAlpha = 0.18 + item.rarity * 0.06;
        ctx.fillStyle = R.color;
        ctx.fillRect(0, 0, S, S);
        ctx.restore();
      }
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.25 + item.rarity * 0.07;
      ctx.fillStyle = halo;
      ctx.fillRect(0, 0, S, S);
      ctx.restore();
      // vinheta + moldura
      const vg = ctx.createRadialGradient(S / 2, S / 2, S * 0.35, S / 2, S / 2, S * 0.75);
      vg.addColorStop(0, 'rgba(0,0,0,0)');
      vg.addColorStop(1, 'rgba(0,0,0,0.65)');
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, S, S);
      ctx.strokeStyle = R.color;
      ctx.lineWidth = item.rarity >= 3 ? 2 : 1.5;
      ctx.strokeRect(0.75, 0.75, S - 1.5, S - 1.5);
      for (let i = 0; i < item.rarity; i++) {
        ctx.fillStyle = R.color;
        ctx.fillRect(3 + i * 4, S - 6, 2.5, 2.5);
      }
      return;
    }

    // fundo
    const g = ctx.createLinearGradient(0, 0, S, S);
    g.addColorStop(0, 'rgba(28,26,32,0.96)');
    g.addColorStop(1, 'rgba(14,13,16,0.96)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, S, S);
    // textura granulada
    for (let i = 0; i < 150; i++) {
      const x = hash2(i, s, 3) * S;
      const y = hash2(i, s, 5) * S;
      ctx.fillStyle = hash2(i, s, 7) > 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.35)';
      ctx.fillRect(x, y, 1, 1);
    }
    // moldura da raridade
    ctx.strokeStyle = R.color;
    ctx.globalAlpha = 0.85;
    ctx.lineWidth = 1.5;
    ctx.strokeRect(0.75, 0.75, S - 1.5, S - 1.5);
    ctx.globalAlpha = 1;

    // glifo por slot
    ctx.save();
    ctx.translate(S / 2, S / 2);
    const col = R.color;
    ctx.strokeStyle = col;
    ctx.fillStyle = col;
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.globalAlpha = 0.95;
    const k = S / 46;
    ctx.scale(k, k);
    ctx.shadowColor = R.glow;
    ctx.shadowBlur = 8;

    if (item.slot === 'arma') {
      ctx.rotate(rnd(-0.4, 0.4));
      ctx.beginPath();
      ctx.moveTo(-11, 11); ctx.lineTo(9, -9);
      ctx.moveTo(-11, 11); ctx.lineTo(-7, 11);
      ctx.moveTo(-11, 11); ctx.lineTo(-11, 7);
      ctx.moveTo(-2, 2); ctx.lineTo(3, 7);
      ctx.stroke();
    } else if (item.slot === 'nucleo') {
      ctx.beginPath();
      const n = 6;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 - Math.PI / 2;
        const r = 11 + rnd(-1.5, 1.5);
        ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      }
      ctx.closePath(); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, 3.5, 0, Math.PI * 2); ctx.fill();
    } else if (item.slot === 'armadura') {
      ctx.beginPath();
      ctx.moveTo(0, -12); ctx.lineTo(10, -8); ctx.lineTo(8, 8); ctx.lineTo(0, 13);
      ctx.lineTo(-8, 8); ctx.lineTo(-10, -8); ctx.closePath();
      ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, -6); ctx.lineTo(0, 8); ctx.stroke();
    } else if (item.slot === 'mascara') {
      ctx.beginPath();
      ctx.moveTo(-10, -11); ctx.lineTo(10, -11); ctx.lineTo(8, 10); ctx.lineTo(0, 14); ctx.lineTo(-8, 10);
      ctx.closePath(); ctx.stroke();
      ctx.globalAlpha = 0.9;
      ctx.fillRect(-6, -5, 4.5, 2.5);
      ctx.fillRect(2, -5, 4.5, 2.5);
    } else if (item.slot === 'botas') {
      ctx.beginPath();
      ctx.moveTo(-5, -12); ctx.lineTo(3, -12); ctx.lineTo(3, 3); ctx.lineTo(11, 6); ctx.lineTo(11, 11);
      ctx.lineTo(-5, 11); ctx.closePath(); ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.moveTo(0, -12);
      ctx.lineTo(4, -3); ctx.lineTo(12, -3); ctx.lineTo(5, 3); ctx.lineTo(8, 12);
      ctx.lineTo(0, 6); ctx.lineTo(-8, 12); ctx.lineTo(-5, 3); ctx.lineTo(-12, -3);
      ctx.lineTo(-4, -3); ctx.closePath();
      ctx.stroke();
    }
    ctx.restore();

    // pips de raridade
    if (item.rarity > 0) {
      for (let i = 0; i < item.rarity; i++) {
        ctx.fillStyle = R.color;
        ctx.globalAlpha = 0.95;
        ctx.fillRect(3 + i * 4, S - 6, 2.5, 2.5);
      }
      ctx.globalAlpha = 1;
    }
  }, [item, size]);

  return <canvas ref={ref} style={{ width: size, height: size }} className="rounded-md" />;
}

// ------------------------------------------------------------
export function ItemCard({ item, compare, onClick, actionLabel }: { item: Item; compare?: Item | null; onClick?: () => void; actionLabel?: string }) {
  const R = RARITIES[item.rarity];
  const diff = compare ? item.score - compare.score : null;
  return (
    <button
      onClick={onClick}
      className="group relative flex w-full gap-2.5 rounded-lg border border-white/5 bg-black/40 p-2 text-left transition active:scale-[0.98]"
      style={{ boxShadow: `inset 0 0 0 1px ${R.glow}` }}
    >
      <ItemIcon item={item} size={46} />
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline justify-between gap-2">
          <span className="truncate text-[13px] font-bold tracking-tight" style={{ color: R.color }}>
            {item.name}
          </span>
          <span className="shrink-0 font-mono text-[10px] text-white/40">n{item.ilvl}</span>
        </div>
        <div className="mt-0.5 flex flex-wrap gap-x-2.5 gap-y-0.5">
          {statsDescription(item).slice(0, 4).map((s, i) => (
            <span key={i} className="font-mono text-[10px] text-white/60">{s}</span>
          ))}
        </div>
        <div className="mt-1 flex items-center gap-2">
          <span className="font-mono text-[10px] text-white/35">poder {item.score}</span>
          {diff !== null && (
            <span className={`font-mono text-[10px] font-bold ${diff > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {diff > 0 ? '▲' : '▼'} {Math.abs(diff)}
            </span>
          )}
          {actionLabel && <span className="ml-auto font-mono text-[10px] text-amber-300/80">{actionLabel}</span>}
        </div>
      </div>
    </button>
  );
}

export function SlotBadge({ slot, item }: { slot: Slot; item: Item | null }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className="relative flex h-[52px] w-[52px] items-center justify-center rounded-lg border border-white/10 bg-black/50"
        style={item ? { boxShadow: `inset 0 0 12px ${RARITIES[item.rarity].glow}` } : undefined}
      >
        {item ? <ItemIcon item={item} size={50} /> : (
          <span className="font-mono text-[9px] uppercase tracking-wider text-white/25">{SLOT_LABEL[slot].slice(0, 4)}</span>
        )}
      </div>
      <span className="font-mono text-[9px] uppercase tracking-wide text-white/40">{SLOT_LABEL[slot]}</span>
    </div>
  );
}

export function Bar({ pct, color, bg = 'rgba(255,255,255,0.08)', h = 8, children, glow }: {
  pct: number; color: string; bg?: string; h?: number; children?: React.ReactNode; glow?: boolean;
}) {
  return (
    <div className="relative w-full overflow-hidden rounded-full" style={{ height: h, background: bg }}>
      <div
        className="h-full rounded-full transition-[width] duration-200"
        style={{ width: `${Math.max(0, Math.min(100, pct * 100))}%`, background: color, boxShadow: glow ? `0 0 10px ${color}` : undefined }}
      />
      {children}
    </div>
  );
}

export function Chip({ children, color = 'rgba(255,255,255,0.7)' }: { children: React.ReactNode; color?: string }) {
  return (
    <span className="rounded border border-white/10 bg-black/40 px-1.5 py-0.5 font-mono text-[10px]" style={{ color }}>
      {children}
    </span>
  );
}

export function SectionTitle({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <div className="mb-2 flex items-center justify-between">
      <h3 className="font-mono text-[11px] font-bold uppercase tracking-[0.22em] text-white/50">{children}</h3>
      {right}
    </div>
  );
}
