import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

// Sem StrictMode: o jogo cria loops (rAF/áudio) que não devem ser duplicados.
createRoot(document.getElementById("root")!).render(<App />);
