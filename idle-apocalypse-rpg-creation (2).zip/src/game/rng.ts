// ============================================================
//  CINZAS — utilitários procedurais (RNG determinístico, noise)
// ============================================================

export function hash2(x: number, y: number, seed = 1337): number {
  let h = x * 374761393 + y * 668265263 + seed * 1442695040;
  h = (h ^ (h >>> 13)) * 1274126177;
  h = h ^ (h >>> 16);
  return (h >>> 0) / 4294967296;
}

export function mulberry32(a: number) {
  let t = a >>> 0;
  return function () {
    t += 0x6d2b79f5;
    let r = t;
    r = Math.imul(r ^ (r >>> 15), r | 1);
    r ^= r + Math.imul(r ^ (r >>> 7), r | 61);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

/** Ruído de valor suave 2D */
export function valueNoise(x: number, y: number, seed = 7): number {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, seed);
  const b = hash2(xi + 1, yi, seed);
  const c = hash2(xi, yi + 1, seed);
  const d = hash2(xi + 1, yi + 1, seed);
  return a * (1 - u) * (1 - v) + b * u * (1 - v) + c * (1 - u) * v + d * u * v;
}

export function fbm(x: number, y: number, octaves = 4, seed = 7): number {
  let sum = 0;
  let amp = 0.5;
  let freq = 1;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += valueNoise(x * freq, y * freq, seed + i * 91) * amp;
    norm += amp;
    amp *= 0.5;
    freq *= 2;
  }
  return sum / norm;
}

export function randInt(rng: () => number, min: number, max: number) {
  return Math.floor(rng() * (max - min + 1)) + min;
}

export function pick<T>(rng: () => number, arr: readonly T[]): T {
  return arr[Math.floor(rng() * arr.length) % arr.length];
}

export function shuffle<T>(rng: () => number, arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function clamp(v: number, a: number, b: number) {
  return v < a ? a : v > b ? b : v;
}

export function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export function fmt(n: number): string {
  if (!isFinite(n)) return '∞';
  const abs = Math.abs(n);
  if (abs < 1000) return abs < 10 ? (Math.round(n * 10) / 10).toString() : Math.floor(n).toString();
  const units = ['K', 'M', 'B', 'T', 'Qa', 'Qi', 'Sx', 'Sp'];
  let u = -1;
  let v = n;
  while (Math.abs(v) >= 1000 && u < units.length - 1) {
    v /= 1000;
    u++;
  }
  return (v < 10 ? v.toFixed(2) : v < 100 ? v.toFixed(1) : Math.floor(v).toString()) + units[u];
}

export function fmtTime(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${r}s`;
  return `${r}s`;
}

// ------------------------------------------------------------
//  Geradores de nomes procedurais
// ------------------------------------------------------------
const SILABAS_A = ['Ka', 'Vor', 'Zul', 'Mor', 'Ish', 'Grah', 'Dre', 'Nok', 'Sev', 'Tal', 'Umb', 'Rha', 'Xa', 'Bel', 'Cin', 'Ful', 'Gol', 'Har'];
const SILABAS_B = ['ra', 'tok', 'vex', 'gorn', 'sha', 'lith', 'dun', 'mek', 'zar', 'quil', 'thrax', 'ven', 'dus', 'kor', 'mal'];
const TITULOS = ['o Devorador', 'da Cinza Branca', 'Sem Face', 'o Enferrujado', 'o Irrompido', 'o Silenciador', 'da Última Aurora', 'o Faminto', 'o Vitrificado', 'o Corrompido', 'o Sem-Rumo', 'o Rei de Sucata'];
const NOMES_ITEM_B = ['das Brasas', 'do Farol', 'da Tempestade', 'do Vazio', 'de Ferro Velho', 'do Vento Seco', 'da Chuva Ácida', 'do Eclipse', 'de Osso', 'do Colapso', 'das Profundezas', 'do Zero'];

export function nomeInimigo(rng: () => number): string {
  return pick(rng, SILABAS_A) + pick(rng, SILABAS_B);
}

export function nomeChefe(rng: () => number): string {
  return `${nomeInimigo(rng)}, ${pick(rng, TITULOS)}`;
}

export function nomeItem(rng: () => number, slot: string): string {
  const base = slot === 'arma' ? 'Lâmina' : slot === 'nucleo' ? 'Núcleo' : slot === 'mascara' ? 'Máscara' : slot === 'armadura' ? 'Placas' : slot === 'botas' ? 'Grevas' : 'Talismã';
  return `${base} ${pick(rng, NOMES_ITEM_B)}`;
}
