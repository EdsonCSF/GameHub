// ============================================================
//  CINZAS — motor de áudio 100% procedural (WebAudio)
//  Música adaptativa em camadas + SFX sintetizados
// ============================================================

type Layer = 'drone' | 'pad' | 'arp' | 'perc';

const SCALES: Record<string, number[]> = {
  phrygian: [0, 1, 3, 5, 7, 8, 10],
  minor: [0, 2, 3, 5, 7, 8, 10],
  penta: [0, 3, 5, 7, 10],
  hirajoshi: [0, 2, 3, 7, 8],
};

function midi(n: number) {
  return 440 * Math.pow(2, (n - 69) / 12);
}

export class AudioEngine {
  ctx: AudioContext | null = null;
  master!: GainNode;
  musicBus!: GainNode;
  sfxBus!: GainNode;
  verb!: ConvolverNode;
  verbGain!: GainNode;
  noiseBuf!: AudioBuffer;

  musicVol = 0.5;
  sfxVol = 0.7;
  enabled = true;

  private started = false;
  private step = 0;
  private nextStepTime = 0;
  private stepDur = 0.2;
  timer: number | null = null;
  private root = 45;
  private scale: number[] = SCALES.phrygian;
  private layers: Record<Layer, boolean> = { drone: true, pad: true, arp: false, perc: false };
  private intensity = 0; // 0..1 controla camadas
  private bossMode = false;
  private lastHit = 0;

  init() {
    if (this.ctx) return;
    const AC: typeof AudioContext =
      (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;

    this.master = ctx.createGain();
    this.master.gain.value = 0.9;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.ratio.value = 6;
    comp.attack.value = 0.005;
    comp.release.value = 0.25;
    this.master.connect(comp);
    comp.connect(ctx.destination);

    this.musicBus = ctx.createGain();
    this.musicBus.gain.value = this.musicVol * 0.7;
    this.sfxBus = ctx.createGain();
    this.sfxBus.gain.value = this.sfxVol;

    // reverb (impulso sintético — não precisa de arquivo)
    this.verb = ctx.createConvolver();
    const len = Math.floor(ctx.sampleRate * 2.6);
    const imp = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = imp.getChannelData(c);
      for (let i = 0; i < len; i++) {
        const t = i / len;
        d[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, 2.6) * 0.55;
      }
    }
    this.verb.buffer = imp;
    this.verbGain = ctx.createGain();
    this.verbGain.gain.value = 0.35;
    this.verb.connect(this.verbGain);
    this.verbGain.connect(this.master);

    this.musicBus.connect(this.master);
    this.musicBus.connect(this.verb);
    this.sfxBus.connect(this.master);
    this.sfxBus.connect(this.verb);

    // buffer de ruído reutilizável
    const nlen = Math.floor(ctx.sampleRate * 1.2);
    this.noiseBuf = ctx.createBuffer(1, nlen, ctx.sampleRate);
    const nd = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < nlen; i++) nd[i] = Math.random() * 2 - 1;
  }

  resume() {
    this.init();
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
    if (!this.started && this.ctx) {
      this.started = true;
      this.nextStepTime = this.ctx.currentTime + 0.1;
      this.timer = window.setInterval(() => this.scheduler(), 40);
    }
  }

  setMusicVol(v: number) {
    this.musicVol = v;
    if (this.ctx) this.musicBus.gain.value = v * 0.7;
  }
  setSfxVol(v: number) {
    this.sfxVol = v;
    if (this.ctx) this.sfxBus.gain.value = v;
  }

  setMood(root: number, scaleName: keyof typeof SCALES | string, tempo: number) {
    this.root = root;
    this.scale = SCALES[scaleName] || SCALES.phrygian;
    this.stepDur = 60 / tempo / 4;
  }

  /** 0 = exploração calma, 1 = combate frenético */
  setIntensity(v: number, boss = false) {
    this.intensity = v;
    this.bossMode = boss;
    this.layers.arp = v > 0.25;
    this.layers.perc = v > 0.45;
  }

  // ---------------- sequenciador ----------------
  private scheduler() {
    if (!this.ctx) return;
    const ct = this.ctx.currentTime;
    while (this.nextStepTime < ct + 0.25) {
      this.playStep(this.step, this.nextStepTime);
      this.step++;
      this.nextStepTime += this.stepDur;
    }
  }

  private playStep(step: number, t: number) {
    const bar = Math.floor(step / 16) % 4;
    const s = step % 16;
    if (this.layers.drone && s === 0 && bar % 2 === 0) {
      this.drone(midi(this.root - 12), t, this.stepDur * 34);
    }
    if (this.layers.pad && s === 0) {
      const deg = [0, 5, 3, 4][bar % 4];
      const n = this.root + this.scale[deg % this.scale.length] + (deg >= this.scale.length ? 12 : 0);
      this.pad(midi(n), midi(n + (this.bossMode ? 6 : 7)), t, this.stepDur * 16);
    }
    if (this.layers.arp) {
      const patt = this.bossMode ? [0, 4, 2, 5, 0, 4, 6, 3] : [0, 2, 4, 2, 5, 2, 4, 7];
      if (s % 2 === 0) {
        const idx = (s / 2) % 8;
        const deg = patt[idx];
        const oct = this.bossMode ? 24 : 12;
        const n = this.root + oct + this.scale[deg % this.scale.length];
        this.pluck(midi(n), t, 0.34 + this.intensity * 0.2);
      }
    }
    if (this.layers.perc) {
      if (s === 0 || s === 6 || s === 10) this.kick(t);
      if (s % 4 === 2) this.snare(t, 0.22 + this.intensity * 0.14);
      if (s % 2 === 1) this.hat(t, 0.05 + this.intensity * 0.05);
    }
  }

  // ---------------- vozes musicais ----------------
  private drone(f: number, t: number, dur: number) {
    const ctx = this.ctx!;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.22, t + 1.4);
    g.gain.linearRampToValueAtTime(0, t + dur);
    const filt = ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.setValueAtTime(220, t);
    filt.frequency.linearRampToValueAtTime(520, t + dur * 0.6);
    filt.Q.value = 4;
    [f, f * 1.005, f * 0.5].forEach((fr, i) => {
      const o = ctx.createOscillator();
      o.type = i === 2 ? 'sine' : 'sawtooth';
      o.frequency.value = fr;
      o.connect(filt);
      o.start(t);
      o.stop(t + dur + 0.1);
    });
    filt.connect(g);
    g.connect(this.musicBus);
  }

  private pad(f1: number, f2: number, t: number, dur: number) {
    const ctx = this.ctx!;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.12, t + dur * 0.35);
    g.gain.linearRampToValueAtTime(0, t + dur);
    const filt = ctx.createBiquadFilter();
    filt.type = 'bandpass';
    filt.frequency.value = 700 + this.intensity * 900;
    filt.Q.value = 1.2;
    [f1, f2, f1 * 2].forEach((fr) => {
      const o = ctx.createOscillator();
      o.type = 'triangle';
      o.frequency.value = fr;
      o.connect(filt);
      o.start(t);
      o.stop(t + dur + 0.1);
    });
    filt.connect(g);
    g.connect(this.musicBus);
  }

  private pluck(f: number, t: number, vol: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.type = 'square';
    o.frequency.value = f;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol * 0.16, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
    const filt = ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.setValueAtTime(3600, t);
    filt.frequency.exponentialRampToValueAtTime(700, t + 0.4);
    o.connect(filt);
    filt.connect(g);
    g.connect(this.musicBus);
    o.start(t);
    o.stop(t + 0.55);
  }

  private kick(t: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(150, t);
    o.frequency.exponentialRampToValueAtTime(42, t + 0.14);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.5, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    o.connect(g);
    g.connect(this.musicBus);
    o.start(t);
    o.stop(t + 0.32);
  }

  private snare(t: number, vol: number) {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 1.6;
    const filt = ctx.createBiquadFilter();
    filt.type = 'bandpass';
    filt.frequency.value = 1900;
    filt.Q.value = 0.7;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
    src.connect(filt);
    filt.connect(g);
    g.connect(this.musicBus);
    src.start(t, Math.random());
    src.stop(t + 0.2);
  }

  private hat(t: number, vol: number) {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 3.2;
    const filt = ctx.createBiquadFilter();
    filt.type = 'highpass';
    filt.frequency.value = 7200;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    src.connect(filt);
    filt.connect(g);
    g.connect(this.musicBus);
    src.start(t, Math.random());
    src.stop(t + 0.07);
  }

  // ---------------- SFX ----------------
  private noise(t: number, dur: number, vol: number, type: BiquadFilterType, freq: number, sweep?: number) {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 0.8 + Math.random() * 0.5;
    const filt = ctx.createBiquadFilter();
    filt.type = type;
    filt.frequency.setValueAtTime(freq, t);
    if (sweep) filt.frequency.exponentialRampToValueAtTime(Math.max(60, sweep), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filt);
    filt.connect(g);
    g.connect(this.sfxBus);
    src.start(t, Math.random());
    src.stop(t + dur + 0.02);
  }

  private tone(t: number, f: number, dur: number, vol: number, type: OscillatorType = 'square', bend?: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    if (bend) o.frequency.exponentialRampToValueAtTime(Math.max(30, bend), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(this.sfxBus);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private throttle(ms: number) {
    const now = performance.now();
    if (now - this.lastHit < ms) return false;
    this.lastHit = now;
    return true;
  }

  hit(crit = false) {
    if (!this.ctx || !this.enabled) return;
    if (!this.throttle(crit ? 40 : 55)) return;
    const t = this.ctx.currentTime;
    this.noise(t, 0.1, crit ? 0.32 : 0.18, 'bandpass', crit ? 2600 : 1400, 300);
    if (crit) this.tone(t, 1750, 0.16, 0.16, 'square', 640);
  }
  shoot() {
    if (!this.ctx || !this.enabled) return;
    if (!this.throttle(45)) return;
    const t = this.ctx.currentTime;
    this.tone(t, 620 + Math.random() * 140, 0.09, 0.075, 'sawtooth', 180);
  }
  hurt() {
    if (!this.ctx || !this.enabled) return;
    if (!this.throttle(140)) return;
    const t = this.ctx.currentTime;
    this.noise(t, 0.24, 0.3, 'lowpass', 900, 160);
    this.tone(t, 180, 0.2, 0.14, 'triangle', 70);
  }
  kill() {
    if (!this.ctx || !this.enabled) return;
    if (!this.throttle(60)) return;
    const t = this.ctx.currentTime;
    this.noise(t, 0.3, 0.26, 'lowpass', 2400, 200);
    this.tone(t, 120, 0.24, 0.1, 'square', 50);
  }
  loot() {
    if (!this.ctx || !this.enabled) return;
    if (!this.throttle(90)) return;
    const t = this.ctx.currentTime;
    [1320, 1760, 2640].forEach((f, i) => this.tone(t + i * 0.045, f, 0.16, 0.09, 'triangle'));
  }
  levelUp() {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    [0, 4, 7, 12, 16].forEach((n, i) => this.tone(t + i * 0.075, midi(64 + n), 0.34, 0.13, 'triangle'));
    this.noise(t, 0.7, 0.14, 'highpass', 500, 6000);
  }
  ability(kind: 'nova' | 'beam' | 'shield') {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    if (kind === 'nova') {
      this.noise(t, 0.55, 0.34, 'lowpass', 5200, 220);
      this.tone(t, 90, 0.6, 0.24, 'sawtooth', 40);
    } else if (kind === 'beam') {
      this.tone(t, 240, 0.7, 0.2, 'sawtooth', 1800);
      this.noise(t, 0.7, 0.2, 'bandpass', 1200, 5000);
    } else {
      [0, 7, 12].forEach((n, i) => this.tone(t + i * 0.05, midi(60 + n), 0.7, 0.1, 'sine'));
      this.noise(t, 0.5, 0.1, 'highpass', 2000, 600);
    }
  }
  bossRoar() {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    this.tone(t, 70, 1.5, 0.34, 'sawtooth', 32);
    this.tone(t, 105, 1.4, 0.2, 'square', 40);
    this.noise(t, 1.5, 0.24, 'lowpass', 900, 120);
  }
  ui(up = true) {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    this.tone(t, up ? 880 : 440, 0.07, 0.06, 'square', up ? 1320 : 330);
  }
}

export const audio = new AudioEngine();
