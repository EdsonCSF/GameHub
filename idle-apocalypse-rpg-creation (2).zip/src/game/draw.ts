// ============================================================
//  CINZAS — desenho de entidades (pixel-vetor procedural)
// ============================================================

export type EnemyKind = 'batedor' | 'cão' | 'espectro' | 'bruto' | 'drone';

export type EnemyView = {
  kind: EnemyKind;
  x: number; y: number; r: number;
  facing: number;
  anim: number;
  hitFlash: number;
  hp: number; maxHp: number;
  isBoss: boolean; isElite: boolean;
  accent: string;
  burn: number;
  stagger: number;
};

const px = (ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) => ctx.fillRect(x, y, w, h);

function healthBar(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, pct: number, color: string, boss = false) {
  ctx.fillStyle = 'rgba(6,6,8,0.82)';
  ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
  ctx.fillStyle = boss ? '#ff3b5c' : color;
  ctx.fillRect(x, y, Math.max(0, w * pct), h);
  if (boss) {
    ctx.fillStyle = 'rgba(255,220,120,0.5)';
    ctx.fillRect(x, y, Math.max(0, w * pct), 1.5);
  }
}

export function drawEnemy(ctx: CanvasRenderingContext2D, e: EnemyView, t: number) {
  const s = e.isBoss ? 2.1 : e.isElite ? 1.4 : 1;
  ctx.save();
  ctx.translate(e.x, e.y);
  const dir = e.facing >= 0 ? 1 : -1;
  ctx.scale(dir * s, s);

  // sombra
  ctx.fillStyle = 'rgba(0,0,0,0.4)';
  ctx.beginPath();
  ctx.ellipse(0, 2, 15, 5.5, 0, 0, Math.PI * 2);
  ctx.fill();

  const walk = Math.sin(e.anim * 9) * (e.stagger > 0 ? 0.3 : 1);
  const bob = Math.sin(e.anim * 6) * 1.6;
  const dark = 'rgba(18,16,20,0.95)';
  const body = e.isBoss ? '#2a1420' : e.isElite ? '#241f28' : '#1e1c22';
  const acc = e.accent;

  if (e.kind === 'batedor') {
    ctx.fillStyle = body;
    px(ctx, -6, -30 + bob, 12, 18);
    px(ctx, -8, -14 + bob, 16, 12);
    // pernas
    ctx.fillStyle = dark;
    px(ctx, -6, -3 + walk * 2, 5, 8 - walk);
    px(ctx, 1, -3 - walk * 2, 5, 8 + walk);
    // cabeça com máscara
    ctx.fillStyle = '#2b2830';
    px(ctx, -5, -40 + bob, 10, 10);
    ctx.fillStyle = acc;
    ctx.globalAlpha = 0.9;
    px(ctx, -3, -37 + bob, 7, 2.5);
    ctx.globalAlpha = 1;
    // lâmina enferrujada
    ctx.strokeStyle = '#8a7d6a';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(8, -22 + bob);
    ctx.lineTo(24, -30 + bob + walk * 2);
    ctx.stroke();
  } else if (e.kind === 'cão') {
    ctx.fillStyle = body;
    px(ctx, -14, -16 + bob * 0.5, 28, 10);
    ctx.fillStyle = dark;
    px(ctx, -12, -6 + walk, 4, 7);
    px(ctx, -4, -6 - walk, 4, 7);
    px(ctx, 4, -6 + walk, 4, 7);
    px(ctx, 10, -6 - walk, 4, 7);
    ctx.fillStyle = '#2b2830';
    px(ctx, 12, -24 + bob * 0.5, 12, 9);
    ctx.fillStyle = acc;
    px(ctx, 18, -21 + bob * 0.5, 4, 2.5);
    ctx.strokeStyle = dark;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(12, -24 + bob * 0.5); ctx.lineTo(6, -34 + bob * 0.5);
    ctx.moveTo(-14, -14 + bob * 0.5); ctx.lineTo(-22, -22 + bob * 0.5);
    ctx.stroke();
  } else if (e.kind === 'espectro') {
    const fl = Math.sin(t * 3 + e.anim) * 3;
    ctx.globalAlpha = 0.9;
    const g = ctx.createLinearGradient(0, -46, 0, 0);
    g.addColorStop(0, 'rgba(30,28,40,0.95)');
    g.addColorStop(1, 'rgba(20,18,28,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(-11, -44 + fl);
    ctx.lineTo(11, -44 + fl);
    ctx.lineTo(9, -10 + fl);
    ctx.lineTo(4, -16 + fl);
    ctx.lineTo(0, -6 + fl);
    ctx.lineTo(-4, -16 + fl);
    ctx.lineTo(-9, -10 + fl);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = acc;
    px(ctx, -7, -38 + fl, 4, 4);
    px(ctx, 3, -38 + fl, 4, 4);
    ctx.globalAlpha = 1;
  } else if (e.kind === 'bruto') {
    ctx.fillStyle = body;
    px(ctx, -13, -34 + bob * 0.4, 26, 22);
    px(ctx, -18, -30 + bob * 0.4, 7, 16);
    px(ctx, 11, -30 + bob * 0.4, 7, 16);
    ctx.fillStyle = dark;
    px(ctx, -11, -12, 8, 12 + walk);
    px(ctx, 3, -12, 8, 12 - walk);
    ctx.fillStyle = '#2b2830';
    px(ctx, -8, -46 + bob * 0.4, 16, 12);
    ctx.fillStyle = acc;
    px(ctx, -5, -42 + bob * 0.4, 4, 3);
    px(ctx, 1, -42 + bob * 0.4, 4, 3);
    // ombreiras
    ctx.fillStyle = '#4a4238';
    px(ctx, -20, -34 + bob * 0.4, 9, 6);
    px(ctx, 11, -34 + bob * 0.4, 9, 6);
  } else {
    // drone
    const fl = Math.sin(t * 4 + e.anim * 2) * 3;
    ctx.fillStyle = '#2b3038';
    px(ctx, -12, -34 + fl, 24, 12);
    ctx.fillStyle = '#3b4149';
    px(ctx, -18, -40 + fl, 36, 4);
    ctx.fillStyle = acc;
    ctx.globalAlpha = 0.5 + Math.sin(t * 10) * 0.2;
    ctx.beginPath();
    ctx.arc(0, -24 + fl, 4.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 0.16;
    ctx.beginPath();
    ctx.arc(0, -24 + fl, 14, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = 'rgba(200,210,220,0.35)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-8, -28 + fl); ctx.lineTo(-8, -18 + fl);
    ctx.moveTo(8, -28 + fl); ctx.lineTo(8, -18 + fl);
    ctx.stroke();
  }

  // aura de elite / chefe
  if (e.isBoss || e.isElite) {
    ctx.globalAlpha = 0.28 + Math.sin(t * 4) * 0.08;
    ctx.strokeStyle = e.isBoss ? '#ff3b5c' : acc;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(0, 0, 22, 9, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  // flash de dano
  if (e.hitFlash > 0) {
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = Math.min(0.85, e.hitFlash);
    ctx.fillStyle = '#fff3e0';
    ctx.fillRect(-22, -50, 44, 54);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
  }

  if (e.burn > 0) {
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.22;
    ctx.fillStyle = '#ff8a3d';
    ctx.fillRect(-18, -46, 36, 48);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.restore();

  // barra de vida
  if (e.hp < e.maxHp) {
    const w = e.isBoss ? 62 : 30;
    ctx.save();
    ctx.translate(e.x, e.y - (e.isBoss ? 68 : 48));
    ctx.scale(s, s);
    healthBar(ctx, -w / 2, 0, w, 4, e.hp / e.maxHp, e.isElite ? '#ffd24a' : '#e0563f', e.isBoss);
    ctx.restore();
  }
}

export type PlayerView = {
  x: number; y: number; facing: number; anim: number; moving: boolean;
  hp: number; maxHp: number; shield: number; flash: number; t: number;
  swing: number; power: number;
};

export function drawPlayer(ctx: CanvasRenderingContext2D, p: PlayerView) {
  const { t } = p;
  const dir = p.facing >= 0 ? 1 : -1;
  const walk = p.moving ? Math.sin(p.anim * 11) : Math.sin(t * 2) * 0.25;
  const bob = p.moving ? Math.abs(Math.sin(p.anim * 11)) * 1.8 : Math.sin(t * 2) * 1;

  // sombra
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.fillStyle = 'rgba(0,0,0,0.45)';
  ctx.beginPath();
  ctx.ellipse(0, 2, 14, 5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // brilho da lanterna
  const glow = ctx.createRadialGradient(p.x, p.y - 22, 4, p.x, p.y - 22, 90);
  glow.addColorStop(0, 'rgba(255,180,90,0.28)');
  glow.addColorStop(0.5, 'rgba(255,140,60,0.10)');
  glow.addColorStop(1, 'rgba(255,120,40,0)');
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(p.x, p.y - 22, 90, 0, Math.PI * 2);
  ctx.fill();

  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.scale(dir, 1);

  // pernas
  ctx.fillStyle = '#191a20';
  px(ctx, -6, -12, 5, 12 + walk * 3);
  px(ctx, 1, -12, 5, 12 - walk * 3);
  // capa
  const cape = ctx.createLinearGradient(0, -40, 0, -6);
  cape.addColorStop(0, '#2c2a33');
  cape.addColorStop(1, '#15151a');
  ctx.fillStyle = cape;
  ctx.beginPath();
  ctx.moveTo(-9, -38 + bob);
  ctx.lineTo(9, -38 + bob);
  ctx.lineTo(11 + walk * 2, -10 + bob);
  ctx.lineTo(-11 - walk * 2, -10 + bob);
  ctx.closePath();
  ctx.fill();
  // torso / núcleo
  ctx.fillStyle = '#3a3742';
  px(ctx, -7, -34 + bob, 14, 22);
  // núcleo de fogo no peito
  const core = 0.7 + Math.sin(t * 6) * 0.25;
  ctx.globalCompositeOperation = 'lighter';
  const cg = ctx.createRadialGradient(0, -25 + bob, 0, 0, -25 + bob, 13);
  cg.addColorStop(0, `rgba(255,225,150,${0.95 * core})`);
  cg.addColorStop(0.4, `rgba(255,140,50,${0.55 * core})`);
  cg.addColorStop(1, 'rgba(255,90,30,0)');
  ctx.fillStyle = cg;
  ctx.beginPath();
  ctx.arc(0, -25 + bob, 13, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalCompositeOperation = 'source-over';
  // capuz
  ctx.fillStyle = '#23222a';
  ctx.beginPath();
  ctx.moveTo(-8, -34 + bob);
  ctx.lineTo(8, -34 + bob);
  ctx.lineTo(6, -46 + bob);
  ctx.lineTo(-6, -46 + bob);
  ctx.closePath();
  ctx.fill();
  // visor brilhante
  ctx.fillStyle = `rgba(255,200,120,${0.75 + Math.sin(t * 5) * 0.2})`;
  px(ctx, -4, -42 + bob, 9, 3);
  // lanterna
  ctx.fillStyle = '#5b4a33';
  px(ctx, 8, -30 + bob, 3, 9);
  ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = `rgba(255,190,90,${0.7 + Math.sin(t * 7) * 0.25})`;
  ctx.beginPath();
  ctx.arc(9.5, -26 + bob, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalCompositeOperation = 'source-over';

  // golpe da arma
  if (p.swing > 0) {
    const a0 = -1.1 + (1 - p.swing) * 2.2;
    ctx.save();
    ctx.translate(4, -26 + bob);
    ctx.rotate(a0);
    ctx.globalCompositeOperation = 'lighter';
    const arc = ctx.createLinearGradient(0, 0, 40, 0);
    arc.addColorStop(0, 'rgba(255,200,120,0.05)');
    arc.addColorStop(0.6, 'rgba(255,170,80,0.55)');
    arc.addColorStop(1, 'rgba(255,240,200,0.95)');
    ctx.strokeStyle = arc;
    ctx.lineWidth = 9;
    ctx.beginPath();
    ctx.arc(0, 0, 34, -0.9, 0.5);
    ctx.stroke();
    ctx.restore();
    ctx.globalCompositeOperation = 'source-over';
    ctx.strokeStyle = '#cfd6de';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(4, -26 + bob);
    const ang = a0;
    ctx.lineTo(4 + Math.cos(ang) * 34, -26 + bob + Math.sin(ang) * 34);
    ctx.stroke();
  }

  if (p.flash > 0) {
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = Math.min(0.8, p.flash);
    ctx.fillStyle = '#ff6b6b';
    ctx.fillRect(-12, -48, 24, 50);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.restore();

  // escudo
  if (p.shield > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = `rgba(95,208,255,${0.5 + Math.sin(t * 8) * 0.2})`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(p.x, p.y - 24, 26 + Math.sin(t * 5) * 2, 32, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 0.12;
    ctx.fillStyle = '#5fd0ff';
    ctx.fill();
    ctx.restore();
  }
}
