// ============================================================
//  CINZAS — motor do jogo
// ============================================================
import {
  mulberry32, clamp, lerp, pick, fmt, nomeChefe, nomeInimigo,
} from './rng';
import {
  type Item, type Stats, SLOTS, applyStats, clampStats,
  emptyStats, isUpgrade, makeItem, RARITIES,
} from './items';
import { World, ZONES, propSprite, type Prop, CHUNK_PX } from './world';
import { applySkills, skillSpecial, applyEternals, eternalCost, ETERNALS, ABILITIES, SKILLS, type Ability } from './skills';
import { drawEnemy, drawPlayer, type EnemyKind } from './draw';
import { drawEnemySprite, drawPlayerSprite, drawExplosion, type BossType } from './sprites';
import { audio } from './audio';

const BOSS_TYPES: BossType[] = ['colossus', 'wraith', 'beast'];
const BOSS_TITLES: Record<BossType, string> = {
  colossus: 'Colosso de Sucata',
  wraith: 'Espectro de Cinza',
  beast: 'Besta Irradiada',
};

type EProj = { x: number; y: number; vx: number; vy: number; life: number; dmg: number; r: number; color: string };
type Tele = {
  kind: 'circle' | 'line'; x: number; y: number; x2: number; y2: number; r: number;
  t: number; max: number; dmg: number; owner: number; color: string;
};
type Fx = { x: number; y: number; life: number; max: number; size: number; rot: number };
export type Banner = { title: string; sub: string; color: string; t: number; max: number };

const SAVE_KEY = 'cinzas.save.v1';

export type SaveState = {
  level: number; xp: number;
  scrap: number; essence: number; eterna: number; cycle: number;
  zone: number; unlocked: number;
  kills: number; totalKills: number; bossKills: number; killsInZone: number;
  equipped: Record<string, Item | null>;
  inventory: Item[];
  skills: Record<string, number>;
  eternums: Record<string, number>;
  autoMode: boolean; autoEquip: boolean;
  playtime: number; lastSeen: number;
  skillPoints: number;
  bestDps: number;
  seenIntro: boolean;
};

function freshState(): SaveState {
  const equipped: Record<string, Item | null> = {};
  SLOTS.forEach((s) => (equipped[s] = null));
  return {
    level: 1, xp: 0, scrap: 0, essence: 0, eterna: 0, cycle: 0,
    zone: 0, unlocked: 0, kills: 0, totalKills: 0, bossKills: 0, killsInZone: 0,
    equipped, inventory: [], skills: {}, eternums: {},
    autoMode: true, autoEquip: true, playtime: 0, lastSeen: Date.now(),
    skillPoints: 0, bestDps: 0, seenIntro: false,
  };
}

type Enemy = {
  id: number; kind: EnemyKind; name: string;
  x: number; y: number; vx: number; vy: number;
  hp: number; maxHp: number; dmg: number; speed: number; r: number;
  facing: number; anim: number; hitFlash: number; stagger: number;
  burn: number; burnDmg: number;
  isBoss: boolean; isElite: boolean;
  xp: number; scrap: number; essence: number;
  atkCd: number;
  bossType?: BossType;
  spawnT: number; windup: number; aiT: number; phase: number; enraged: boolean;
  dashT: number; dashVx: number; dashVy: number;
};

type Proj = {
  x: number; y: number; vx: number; vy: number; life: number;
  dmg: number; crit: boolean; r: number; color: string; hits: number[]; pierce: number; spin: number;
};

type Particle = {
  x: number; y: number; vx: number; vy: number; life: number; max: number;
  size: number; color: string; grav: number; kind: 'spark' | 'ember' | 'smoke' | 'ring' | 'blood';
};

type Float = { x: number; y: number; vy: number; life: number; text: string; color: string; size: number };
type Notice = { id: number; text: string; color: string; life: number };
type Beam = { x: number; y: number; angle: number; life: number; dmg: number; width: number };

export type Snapshot = {
  level: number; xp: number; xpNeed: number; hp: number; maxHp: number;
  stats: Stats; dps: number; scrap: number; essence: number; eterna: number; cycle: number;
  zoneName: string; zoneDesc: string; zoneId: number; zoneEmblem: string; tier: number; reqLevel: number;
  unlocked: number; killsInZone: number; killsToBoss: number;
  boss: { name: string; title: string; hp: number; maxHp: number; phase: number; enraged: boolean; spawning: boolean } | null;
  banner: Banner | null;
  equipped: Record<string, Item | null>; inventory: Item[];
  skills: Record<string, number>; eternums: Record<string, number>; skillPoints: number;
  autoMode: boolean; autoEquip: boolean; notices: Notice[];
  abilities: { id: string; name: string; icon: string; cd: number; cdMax: number; unlock: number; color: string; desc: string }[];
  totalKills: number; bossKills: number; playtime: number; bestDps: number;
  killsPerSec: number; enemies: number; seenIntro: boolean;
};

export function xpNeed(level: number) {
  return Math.floor(13 * Math.pow(level, 1.52) + 18);
}

export class Game {
  state: SaveState;
  world: World;
  stats: Stats = emptyStats();
  rng: () => number;

  // player
  px = 0; py = 0; pvx = 0; pvy = 0;
  hp = 100; facing = 1; anim = 0; swing = 0; flash = 0;
  shield = 0; shieldT = 0; invuln = 0;
  reviveCd = 0;

  // combat state
  enemies: Enemy[] = [];
  projs: Proj[] = [];
  parts: Particle[] = [];
  floats: Float[] = [];
  beams: Beam[] = [];
  notices: Notice[] = [];
  cds: Record<string, number> = {};
  nextId = 1;
  atkTimer = 0;
  target: Enemy | null = null;
  wanderX = 0; wanderY = 0; wanderT = 0;

  // camera / render
  camX = 0; camY = 0; zoom = 1.4; shake = 0;
  moveVec = { x: 0, y: 0 };
  pointer: { active: boolean; x: number; y: number } = { active: false, x: 0, y: 0 };

  // telemetry
  dpsWindow: { t: number; d: number }[] = [];
  dps = 0; killsPerSec = 0; killWindow: number[] = [];
  bossActive: Enemy | null = null;
  bossMeter = 0;
  eprojs: EProj[] = [];
  teles: Tele[] = [];
  fxs: Fx[] = [];
  timeScale = 1;
  banner: Banner | null = null;
  zoomPunch = 0;
  ashParts: { x: number; y: number; vx: number; vy: number; s: number; a: number }[] = [];
  time = 0;
  private saveT = 0;
  private lootToastT = 0;
  onStateChange: (() => void) | null = null;

  constructor() {
    this.state = this.load() || freshState();
    this.rng = mulberry32(Date.now() & 0xffffff);
    this.world = new World(this.state.zone, 9001);
    const start = this.findOpenSpot(this.px, this.py);
    this.px = start.x; this.py = start.y;
    this.camX = this.px; this.camY = this.py;
    this.recompute();
    this.hp = this.stats.maxHp;
    for (let i = 0; i < 90; i++) {
      this.ashParts.push({ x: Math.random() * 800, y: Math.random() * 900, vx: 6 + Math.random() * 26, vy: 12 + Math.random() * 40, s: 0.6 + Math.random() * 1.8, a: 0.15 + Math.random() * 0.5 });
    }
    const away = Date.now() - (this.state.lastSeen || Date.now());
    this.state.lastSeen = Date.now();
    if (away > 60000) this.idleRewards(away / 1000);
  }

  // ---------------- persistência ----------------
  load(): SaveState | null {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      const s = JSON.parse(raw) as SaveState;
      const base = freshState();
      const merged = { ...base, ...s } as SaveState;
      if (!merged.equipped) merged.equipped = base.equipped;
      SLOTS.forEach((sl) => {
        if (!merged.equipped[sl]) merged.equipped[sl] = null;
      });
      merged.inventory = (merged.inventory || []).slice(0, 60);
      return merged;
    } catch {
      return null;
    }
  }

  save() {
    try {
      this.state.lastSeen = Date.now();
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.state));
    } catch { /* ignore */ }
  }

  // ---------------- stats ----------------
  recompute() {
    const s = emptyStats();
    const L = this.state.level;
    // base do Guardião
    s.atkSpeed = 1; s.speed = 1; s.range = 1; s.luck = 1;
    s.aoe = 1; s.proj = 1; s.xpGain = 1; s.scrapGain = 1;
    s.crit = 0.05; s.critDmg = 1.5;
    s.power = 8 + L * 2.7;
    s.maxHp = 70 + L * 17;
    s.hpRegen = 1.1 + L * 0.28;
    s.armor = 2 + L * 1.4;
    for (const slot of SLOTS) {
      const it = this.state.equipped[slot];
      if (it) applyStats(s, it);
    }
    applySkills(s, this.state.skills);
    applyEternals(s, this.state.eternums);
    clampStats(s);
    this.stats = s;
    if (this.hp > s.maxHp) this.hp = s.maxHp;
  }

  get power() { return this.stats.power; }

  // ---------------- helpers ----------------
  findOpenSpot(x: number, y: number) {
    for (let i = 0; i < 24; i++) {
      const nx = x + (this.rng() - 0.5) * 400;
      const ny = y + (this.rng() - 0.5) * 400;
      const c = this.world.collide(nx, ny, 16);
      if (Math.abs(c.x - nx) < 0.6 && Math.abs(c.y - ny) < 0.6) return { x: nx, y: ny };
    }
    return { x, y };
  }

  notice(text: string, color = '#e8e3d8') {
    this.notices.push({ id: this.nextId++, text, color, life: 2.1 });
    if (this.notices.length > 2) this.notices.shift();
  }

  float(x: number, y: number, text: string, color: string, size = 11) {
    this.floats.push({ x, y, vy: -28, life: 0.52, text, color, size });
    if (this.floats.length > 10) this.floats.shift();
  }

  burst(x: number, y: number, n: number, color: string, kind: Particle['kind'] = 'spark', spread = 120) {
    for (let i = 0; i < n; i++) {
      const a = this.rng() * Math.PI * 2;
      const sp = spread * (0.25 + this.rng());
      this.parts.push({
        x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 20,
        life: 0.35 + this.rng() * 0.45, max: 0.8, size: 1.5 + this.rng() * 2.6,
        color, grav: kind === 'ember' ? -60 : 240, kind,
      });
    }
    if (this.parts.length > 260) this.parts.splice(0, this.parts.length - 260);
  }

  ring(x: number, y: number, color: string, size = 20) {
    this.parts.push({ x, y, vx: 0, vy: 0, life: 0.42, max: 0.42, size, color, grav: 0, kind: 'ring' });
  }

  // ---------------- progresso ----------------
  gainXp(v: number) {
    const st = this.state;
    st.xp += v * this.stats.xpGain;
    let ups = 0;
    while (st.xp >= xpNeed(st.level)) {
      st.xp -= xpNeed(st.level);
      st.level++;
      st.skillPoints++;
      ups++;
    }
    if (ups > 0) {
      this.recompute();
      this.hp = this.stats.maxHp;
      audio.levelUp();
      this.burst(this.px, this.py - 26, 34, '#ffcf6b', 'ember', 190);
      this.ring(this.px, this.py, '#ffd24a', 26);
      this.notice(`Nível ${st.level} · +1 ponto de Fogo`, '#ffd24a');
      const nz = ZONES.find((z) => z.reqLevel === st.level);
      if (nz && nz.id > st.unlocked) this.notice(`Nova região sentida: ${nz.name}`, '#5fd0ff');
      this.save();
    }
  }

  addLoot(item: Item) {
    const inv = this.state.inventory;
    inv.push(item);
    if (inv.length > 48) {
      inv.sort((a, b) => a.score - b.score);
      const sold = inv.shift();
      if (sold) this.state.scrap += Math.round(6 + sold.ilvl * 1.5);
    }
    if (this.state.autoEquip && isUpgrade(this.state.equipped[item.slot], item)) {
      this.equip(item.uid);
    } else if (item.rarity >= 2) {
      const R = RARITIES[item.rarity];
      this.notice(`${R.name}: ${item.name}`, R.color);
      audio.loot();
    }
  }

  equip(uid: string) {
    const idx = this.state.inventory.findIndex((i) => i.uid === uid);
    if (idx < 0) return;
    const item = this.state.inventory[idx];
    const cur = this.state.equipped[item.slot];
    this.state.equipped[item.slot] = item;
    this.state.inventory.splice(idx, 1);
    if (cur) this.state.inventory.push(cur);
    this.recompute();
    audio.ui();
  }

  sell(uid: string) {
    const idx = this.state.inventory.findIndex((i) => i.uid === uid);
    if (idx < 0) return;
    const it = this.state.inventory[idx];
    const val = Math.round((8 + it.ilvl * 2.2) * (1 + it.rarity * 0.7));
    this.state.scrap += val;
    this.state.inventory.splice(idx, 1);
    audio.ui(false);
    this.float(this.px, this.py - 40, `+${fmt(val)} sucata`, '#c9b79a', 13);
  }

  sellAll(rarityMax = 1) {
    let total = 0;
    this.state.inventory = this.state.inventory.filter((it) => {
      if (it.rarity <= rarityMax && !isUpgrade(this.state.equipped[it.slot], it)) {
        total += Math.round((8 + it.ilvl * 2.2) * (1 + it.rarity * 0.7));
        return false;
      }
      return true;
    });
    this.state.scrap += total;
    if (total > 0) { audio.loot(); this.notice(`Vendidos: +${fmt(total)} sucata`, '#c9b79a'); }
  }

  learnSkill(id: string) {
    const node = SKILLS.find((s) => s.id === id);
    if (!node) return;
    const lvl = this.state.skills[id] || 0;
    if (lvl >= node.max) return;
    if (node.req && (this.state.skills[node.req] || 0) < 1) return;
    if (this.state.skillPoints < 1) return;
    this.state.skills[id] = lvl + 1;
    this.state.skillPoints -= 1;
    this.recompute();
    audio.ui();
    if (lvl + 1 === node.max) this.notice(`${node.name} — MÁXIMO`, node.branch === 0 ? '#ff7a3d' : node.branch === 1 ? '#5fd0ff' : '#c86bff');
  }

  buyEternal(id: string) {
    const def = ETERNALS.find((e) => e.id === id);
    if (!def) return;
    const lvl = this.state.eternums[id] || 0;
    if (lvl >= def.max) return;
    const c = eternalCost(def, lvl);
    if (this.state.eterna < c) return;
    this.state.eterna -= c;
    this.state.eternums[id] = lvl + 1;
    if (id === 'sentinela') this.state.autoEquip = true;
    this.recompute();
    audio.levelUp();
    this.notice(`${def.name} ${lvl + 1}`, '#ffd24a');
  }

  eternaGain() {
    const s = this.state;
    return Math.max(0, Math.floor(s.level / 10 + s.bossKills * 0.75 + s.unlocked * 2.2 + s.cycle * 0.5));
  }

  renascer() {
    const gain = this.eternaGain();
    if (gain <= 0) return;
    const keep = {
      eterna: this.state.eterna + gain,
      eternums: this.state.eternums,
      cycle: this.state.cycle + 1,
      totalKills: this.state.totalKills,
      bestDps: Math.max(this.state.bestDps, this.dps),
      seenIntro: true,
    };
    this.state = { ...freshState(), ...keep };
    this.world.setZone(0);
    this.enemies = []; this.projs = []; this.bossActive = null; this.bossMeter = 0;
    const spot = this.findOpenSpot(this.px, this.py);
    this.px = spot.x; this.py = spot.y;
    this.recompute();
    this.hp = this.stats.maxHp;
    audio.ability('nova');
    this.notice(`CICLO ${this.state.cycle} — +${gain} Cinzas Eternas`, '#ff7038');
    this.save();
  }

  travel(zoneId: number) {
    const z = ZONES[zoneId];
    if (!z || zoneId > this.state.unlocked) return;
    this.state.zone = zoneId;
    this.state.killsInZone = 0;
    this.teles = [];
    this.eprojs = [];
    this.banner = { title: z.name, sub: z.desc, color: z.accent, t: 2.6, max: 2.6 };
    this.bossMeter = 0;
    this.bossActive = null;
    this.enemies = [];
    this.projs = [];
    this.world.setZone(zoneId);
    const a = this.rng() * Math.PI * 2;
    const d = 400 + this.rng() * 900;
    const spot = this.findOpenSpot(this.px + Math.cos(a) * d, this.py + Math.sin(a) * d);
    this.px = spot.x; this.py = spot.y;
    this.camX = this.px; this.camY = this.py;
    this.recompute();
    audio.setMood(z.root, z.scale, z.tempo);
    audio.ability('shield');
    this.notice(`→ ${z.name}`, '#5fd0ff');
    this.save();
  }

  idleRewards(sec: number) {
    const capped = Math.min(sec, 8 * 3600);
    const kps = Math.max(0.05, this.killsPerSec || this.estimateKps());
    const kills = Math.floor(kps * capped * 0.55);
    if (kills <= 0) return;
    const z = ZONES[this.state.zone];
    const xp = kills * this.enemyXp(z.tier, false) * 0.9;
    const scrap = kills * this.enemyScrap(z.tier, false) * 0.9;
    this.state.totalKills += kills;
    this.state.kills += kills;
    this.gainXp(xp);
    this.state.scrap += scrap * this.stats.scrapGain;
    const drops = Math.floor(kills * 0.16);
    for (let i = 0; i < Math.min(drops, 14); i++) {
      this.addLoot(makeItem(this.state.level + z.tier * 5, this.stats.luck, Math.floor(this.rng() * 1e9)));
    }
    this.notice(`Expedição automática: ${kills} abates`, '#5fd0ff');
    this.offlineReport = { kills, xp, scrap, sec: capped };
    this.save();
  }

  offlineReport: { kills: number; xp: number; scrap: number; sec: number } | null = null;

  estimateKps() {
    const dps = this.dps || this.power * 1.2;
    const z = ZONES[this.state.zone];
    const hp = this.enemyHp(z.tier, false);
    return clamp(dps / Math.max(1, hp) / 1.4, 0.05, 8);
  }

  // ---------------- escalonamento ----------------
  cycleMult() { return Math.pow(1.85, this.state.cycle); }
  enemyHp(tier: number, boss: boolean) {
    const base = 22 * Math.pow(1.62, tier - 1) * (1 + this.state.level * 0.05) * this.cycleMult();
    return Math.floor(base * (boss ? 30 : 1));
  }
  enemyDmg(tier: number) {
    return 5 * Math.pow(1.4, tier - 1) * (1 + this.state.level * 0.015) * Math.pow(1.5, this.state.cycle);
  }
  enemyXp(tier: number, boss: boolean) {
    return (7 * Math.pow(1.34, tier - 1)) * (boss ? 16 : 1);
  }
  enemyScrap(tier: number, boss: boolean) {
    return (3 * Math.pow(1.28, tier - 1)) * (boss ? 14 : 1);
  }

  killsToBoss() { return 40; }

  // ---------------- spawn ----------------
  /** DPS teórico do jogador (usado para calibrar a vida do chefe) */
  theoreticalDps() {
    const s = this.stats;
    const critF = 1 + s.crit * (s.critDmg - 1);
    const chain = skillSpecial(this.state.skills, 'chain');
    return s.power * s.atkSpeed * 1.05 * Math.sqrt(Math.max(1, s.proj)) * critF * (1 + chain * 0.35);
  }

  spawnEnemy(boss = false) {
    const z = ZONES[this.state.zone];
    const view = this.viewRadius();
    const a = this.rng() * Math.PI * 2;
    // chefes surgem perto e dentro da tela, para você VER a entrada
    const d = boss ? 190 + this.rng() * 40 : view * (1.15 + this.rng() * 0.5);
    let x = this.px + Math.cos(a) * d;
    let y = this.py + Math.sin(a) * d;
    const spot = boss ? this.world.collide(x, y, 30) : this.findOpenSpot(x, y);
    x = spot.x; y = spot.y;
    const kind = pick(this.rng, z.enemies as EnemyKind[]);
    const isElite = !boss && this.rng() < 0.11;
    let hp = this.enemyHp(z.tier, boss) * (isElite ? 3.1 : 1);
    let bossType: BossType | undefined;
    if (boss) {
      bossType = BOSS_TYPES[(z.id + this.state.bossKills) % BOSS_TYPES.length];
      // luta dura ~40s com o seu dano atual (mais o piso por tier)
      const dpsRef = Math.max(this.dps, this.theoreticalDps());
      hp = Math.max(hp * 4, dpsRef * (38 + z.tier * 2));
    }
    const e: Enemy = {
      id: this.nextId++,
      kind, name: boss ? nomeChefe(this.rng) : isElite ? `${nomeInimigo(this.rng)} Alfa` : nomeInimigo(this.rng),
      x, y, vx: 0, vy: 0,
      hp, maxHp: hp,
      dmg: this.enemyDmg(z.tier) * (boss ? 2.2 : isElite ? 1.5 : 1),
      speed: (boss ? 44 : isElite ? 62 : 58 + this.rng() * 22) * (kind === 'cão' ? 1.45 : kind === 'espectro' ? 0.9 : 1),
      r: boss ? 34 : kind === 'bruto' ? 20 : 14,
      facing: 1, anim: this.rng() * 10, hitFlash: 0, stagger: 0, burn: 0, burnDmg: 0,
      isBoss: boss, isElite,
      xp: this.enemyXp(z.tier, boss) * (isElite ? 3 : 1),
      scrap: this.enemyScrap(z.tier, boss) * (isElite ? 2.4 : 1),
      essence: boss ? 12 + z.tier * 6 : isElite ? 3 : 0,
      atkCd: boss ? 2.5 : 0,
      bossType,
      spawnT: boss ? 1.8 : 0, windup: 0, aiT: boss ? 3.2 : 0, phase: 0, enraged: false,
      dashT: 0, dashVx: 0, dashVy: 0,
    };
    if (boss) {
      e.r = bossType === 'beast' ? 30 : 36;
      e.speed = bossType === 'beast' ? 58 : bossType === 'wraith' ? 50 : 40;
    }
    this.enemies.push(e);
    if (boss) {
      this.bossActive = e;
      // limpa a arena parcialmente para o duelo
      this.enemies = this.enemies.filter((o) => o === e || Math.hypot(o.x - this.px, o.y - this.py) > 260 || o.isElite);
      audio.bossRoar();
      this.shake = 20;
      this.timeScale = 0.35;
      this.zoomPunch = 0.25;
      this.banner = { title: e.name, sub: BOSS_TITLES[bossType!], color: '#ff3b5c', t: 3, max: 3 };
      this.fxs.push({ x: e.x, y: e.y - 20, life: 0.9, max: 0.9, size: 260, rot: this.rng() * 6 });
      this.burst(e.x, e.y, 60, '#3a2a20', 'smoke', 260);
      this.ring(e.x, e.y, '#ff3b5c', 70);
    }
    return e;
  }

  viewRadius() {
    const rx = this.viewW / (2 * this.zoom);
    const ry = this.viewH / (2 * this.zoom);
    return Math.max(320, Math.max(rx, ry) + 90);
  }

  // ---------------- dano ----------------
  rollDamage(mult = 1) {
    const crit = this.rng() < this.stats.crit;
    let d = this.stats.power * mult * (0.88 + this.rng() * 0.24);
    if (crit) d *= this.stats.critDmg;
    return { dmg: d, crit };
  }

  hurtEnemy(e: Enemy, dmg: number, crit: boolean, showFloat = true) {
    if (e.hp <= 0) return;
    if (e.spawnT > 0) return;
    e.hp -= dmg;
    e.hitFlash = 0.14;
    e.stagger = e.isBoss ? 0 : 0.12;
    if (e.isBoss && e.hp > 0) this.bossPhaseCheck(e);
    this.dpsWindow.push({ t: this.time, d: dmg });
    // mostra números apenas em críticos ou de forma esparsa e deslocada para não cobrir o monstro
    if (showFloat && (crit || this.rng() < 0.28)) {
      const side = (e.id % 2 === 0 ? 1 : -1) * (18 + this.rng() * 12);
      this.float(e.x + side, e.y - 36 - (e.isBoss ? 44 : 0), fmt(dmg), crit ? '#ffd24a' : 'rgba(242,236,224,0.8)', crit ? 13 : 10);
    }
    this.burst(e.x, e.y - 22, crit ? 9 : 4, crit ? '#ffd98a' : '#ffb27a', 'spark', crit ? 170 : 90);
    audio.hit(crit);
    // roubo de vida
    if (this.stats.lifesteal > 0) this.hp = Math.min(this.stats.maxHp, this.hp + dmg * this.stats.lifesteal);
    if (e.hp <= 0) this.killEnemy(e);
  }

  killEnemy(e: Enemy) {
    const s = this.state;
    s.kills++; s.totalKills++; s.killsInZone++;
    this.killWindow.push(this.time);
    const z = ZONES[s.zone];
    this.gainXp(e.xp);
    s.scrap += e.scrap * this.stats.scrapGain;
    if (e.essence > 0) s.essence += e.essence;
    this.burst(e.x, e.y - 20, e.isBoss ? 70 : 16, z.accent, 'ember', e.isBoss ? 320 : 150);
    this.burst(e.x, e.y - 20, e.isBoss ? 40 : 8, '#3a2a20', 'smoke', e.isBoss ? 260 : 110);
    this.ring(e.x, e.y, e.isBoss ? '#ff3b5c' : '#ff8a3d', e.isBoss ? 60 : 18);
    if (e.isElite) this.fxs.push({ x: e.x, y: e.y - 30, life: 0.55, max: 0.55, size: 130, rot: this.rng() * 6 });
    else if (this.rng() < 0.25) this.fxs.push({ x: e.x, y: e.y - 24, life: 0.35, max: 0.35, size: 70, rot: this.rng() * 6 });
    audio.kill();
    if (e.isBoss) {
      this.shake = 30;
      this.timeScale = 0.18;
      this.zoomPunch = 0.3;
      this.teles = this.teles.filter((t) => t.owner !== e.id);
      this.eprojs = [];
      for (let i = 0; i < 6; i++) {
        this.fxs.push({
          x: e.x + (this.rng() - 0.5) * 110, y: e.y - 30 - this.rng() * 110,
          life: 0.7 + i * 0.12, max: 0.7 + i * 0.12, size: 150 + this.rng() * 150, rot: this.rng() * 6,
        });
      }
      for (const c of ['#ffd24a', '#c86bff', '#41c8f5', '#ff7038']) this.burst(e.x, e.y - 60, 18, c, 'ember', 380);
      this.banner = { title: 'COLOSSO DERROTADO', sub: e.name, color: '#ffd24a', t: 3.2, max: 3.2 };
      s.bossKills++;
      this.bossActive = null;
      this.bossMeter = 0;
      if (s.zone >= s.unlocked && s.unlocked < ZONES.length - 1) {
        s.unlocked = s.zone + 1;
        this.notice(`REGIÃO LIBERADA: ${ZONES[s.unlocked].name}`, '#5fd0ff');
      }
      for (let i = 0; i < 3; i++) {
        this.addLoot(makeItem(s.level + z.tier * 6, this.stats.luck * 2.5, Math.floor(this.rng() * 1e9), Math.min(5, 3 + Math.floor(this.rng() * 3)) as 3 | 4 | 5));
      }
      this.state.eterna += 1;
      this.notice('+1 Cinza Eterna', '#ff7038');
    } else {
      const chance = (0.2 + this.stats.luck * 0.02) * (1 + 0.25 * (s.eternums.sentinela || 0));
      if (this.rng() < chance) {
        const ilvl = s.level + z.tier * 5 + Math.floor(this.rng() * 4);
        this.addLoot(makeItem(ilvl, this.stats.luck, Math.floor(this.rng() * 1e9)));
        if (this.lootToastT <= 0) { this.lootToastT = 1.2; }
      }
      if (e.isElite && this.rng() < 0.75) {
        this.addLoot(makeItem(s.level + z.tier * 5 + 2, this.stats.luck * 1.8, Math.floor(this.rng() * 1e9), undefined, undefined));
      }
    }
    this.enemies = this.enemies.filter((x) => x !== e);
    if (this.target === e) this.target = null;
  }

  // ---------------- IA de chefe ----------------
  bossPhaseCheck(e: Enemy) {
    const pct = e.hp / e.maxHp;
    const target = pct < 0.33 ? 2 : pct < 0.66 ? 1 : 0;
    if (target > e.phase) {
      e.phase = target;
      e.spawnT = 0.9; // breve imunidade + rugido
      e.windup = 0;
      this.teles = this.teles.filter((t) => t.owner !== e.id);
      audio.bossRoar();
      this.shake = 18;
      this.ring(e.x, e.y, '#ff3b5c', 60);
      this.fxs.push({ x: e.x, y: e.y - 50, life: 0.8, max: 0.8, size: 220, rot: this.rng() * 6 });
      this.notice(target === 1 ? 'O Colosso chama a matilha!' : 'O Colosso entra em FÚRIA!', '#ff3b5c');
      // invoca lacaios
      const z = ZONES[this.state.zone];
      const n = 3 + target;
      for (let i = 0; i < n; i++) {
        const add = this.spawnEnemy(false);
        const a = (i / n) * Math.PI * 2;
        const p = this.world.collide(e.x + Math.cos(a) * 90, e.y + Math.sin(a) * 90, 14);
        add.x = p.x; add.y = p.y;
        add.spawnT = 0.6;
        add.kind = pick(this.rng, z.enemies as EnemyKind[]);
      }
      if (target === 2) {
        e.enraged = true;
        e.speed *= 1.35;
        e.dmg *= 1.25;
      }
    }
  }

  bossAI(e: Enemy, dt: number) {
    if (e.spawnT > 0) return;
    // investida em andamento
    if (e.dashT > 0) {
      e.dashT -= dt;
      const c = this.world.collide(e.x + e.dashVx * dt, e.y + e.dashVy * dt, e.r * 0.7);
      e.x = c.x; e.y = c.y;
      if (this.rng() < dt * 30) this.burst(e.x, e.y - 10, 3, '#6b5a48', 'smoke', 60);
      if (Math.hypot(this.px - e.x, this.py - e.y) < e.r + 20 && e.atkCd <= 0) {
        e.atkCd = 0.8;
        this.hurtPlayer(e.dmg * 1.4, e);
        this.shake = 14;
      }
      return;
    }
    e.aiT -= dt;
    if (e.aiT > 0) return;
    const bt = e.bossType || 'colossus';
    const cdMult = e.enraged ? 0.6 : 1;
    const r = this.rng();
    // cada chefe tem um ataque favorito, mas usa os outros também
    let atk: 'slam' | 'volley' | 'charge';
    if (bt === 'colossus') atk = r < 0.6 ? 'slam' : r < 0.85 ? 'volley' : 'charge';
    else if (bt === 'wraith') atk = r < 0.6 ? 'volley' : r < 0.85 ? 'slam' : 'charge';
    else atk = r < 0.6 ? 'charge' : r < 0.85 ? 'slam' : 'volley';

    if (atk === 'slam') {
      const count = e.enraged ? 3 : 1;
      for (let i = 0; i < count; i++) {
        const ox = i === 0 ? 0 : (this.rng() - 0.5) * 160;
        const oy = i === 0 ? 0 : (this.rng() - 0.5) * 160;
        this.teles.push({
          kind: 'circle', x: this.px + ox, y: this.py + oy, x2: 0, y2: 0, r: 78,
          t: 1.25 + i * 0.25, max: 1.25 + i * 0.25, dmg: e.dmg * 1.8, owner: e.id, color: '255,60,40',
        });
      }
      e.windup = 1.2;
      e.aiT = 3.4 * cdMult;
    } else if (atk === 'volley') {
      e.windup = 0.7;
      this.teles.push({ kind: 'circle', x: e.x, y: e.y, x2: 0, y2: 0, r: 40, t: 0.7, max: 0.7, dmg: 0, owner: e.id, color: '200,90,255' });
      e.aiT = 3 * cdMult;
    } else {
      const dx = this.px - e.x, dy = this.py - e.y;
      const d = Math.hypot(dx, dy) || 1;
      const len = Math.min(420, d + 140);
      this.teles.push({
        kind: 'line', x: e.x, y: e.y, x2: e.x + (dx / d) * len, y2: e.y + (dy / d) * len, r: 44,
        t: 0.95, max: 0.95, dmg: e.dmg * 1.4, owner: e.id, color: '255,60,40',
      });
      e.windup = 0.95;
      e.aiT = 3.2 * cdMult;
    }
  }

  resolveTele(t: Tele) {
    const owner = this.enemies.find((e) => e.id === t.owner);
    if (t.kind === 'circle') {
      if (t.dmg === 0 && owner) {
        // rajada radial de projéteis
        const n = owner.enraged ? 22 : 15;
        const off = this.rng() * Math.PI;
        for (let i = 0; i < n; i++) {
          const a = off + (i / n) * Math.PI * 2;
          const sp = owner.enraged ? 190 : 150;
          this.eprojs.push({ x: owner.x, y: owner.y - 60, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 3.4, dmg: owner.dmg * 0.55, r: 9, color: owner.bossType === 'wraith' ? '#d86bff' : '#ff8a3d' });
        }
        audio.ability('beam');
        return;
      }
      this.fxs.push({ x: t.x, y: t.y - 10, life: 0.6, max: 0.6, size: t.r * 2.8, rot: this.rng() * 6 });
      this.burst(t.x, t.y, 26, '#5a4636', 'smoke', 200);
      this.ring(t.x, t.y, '#ff5a3d', t.r * 0.5);
      this.shake = Math.max(this.shake, 14);
      audio.ability('nova');
      if (Math.hypot(this.px - t.x, this.py - t.y) < t.r) this.hurtPlayer(t.dmg, owner);
    } else if (owner) {
      const dx = t.x2 - owner.x, dy = t.y2 - owner.y;
      const d = Math.hypot(dx, dy) || 1;
      const sp = 620;
      owner.dashVx = (dx / d) * sp; owner.dashVy = (dy / d) * sp;
      owner.dashT = d / sp;
      owner.atkCd = 0;
      audio.bossRoar();
    }
  }

  hurtPlayer(dmg: number, src?: Enemy) {
    if (this.invuln > 0) return;
    const z = ZONES[this.state.zone];
    const red = this.stats.armor / (this.stats.armor + 45 + z.tier * 22);
    const d = dmg * (1 - red);
    if (this.shield > 0) {
      const absorbed = Math.min(this.shield, d);
      this.shield -= absorbed;
      if (this.shield <= 0) this.shieldT = 0;
    } else {
      this.hp -= d;
      this.flash = 0.28;
      this.shake = Math.max(this.shake, 7);
    }
    // espinhos
    if (src && this.stats.thorns > 0) {
      this.hurtEnemy(src, this.stats.thorns * 2.2, false, false);
      this.ring(src.x, src.y, '#5fd0ff', 14);
    }
    audio.hurt();
    if (this.hp <= 0) this.playerDown();
  }

  playerDown() {
    const reviveLvl = skillSpecial(this.state.skills, 'revive');
    if (reviveLvl > 0 && this.reviveCd <= 0) {
      this.hp = this.stats.maxHp * (0.25 * reviveLvl);
      this.invuln = 5;
      this.reviveCd = 90;
      this.burst(this.px, this.py - 24, 50, '#ffd24a', 'ember', 260);
      this.ring(this.px, this.py, '#ffd24a', 40);
      audio.levelUp();
      this.notice('ÚLTIMO SUSPIRO! Você se levanta.', '#ffd24a');
      return;
    }
    this.hp = this.stats.maxHp * 0.35;
    this.invuln = 2.6;
    this.enemies = [];
    this.teles = [];
    this.eprojs = [];
    this.bossActive = null;
    this.bossMeter = Math.max(0, this.bossMeter - 15);
    const a = this.rng() * Math.PI * 2;
    const spot = this.findOpenSpot(this.px + Math.cos(a) * 500, this.py + Math.sin(a) * 500);
    this.px = spot.x; this.py = spot.y;
    this.state.killsInZone = Math.max(0, this.state.killsInZone - 6);
    this.notice('Você caiu. A cinza te arrasta de volta...', '#ff6b6b');
    audio.bossRoar();
  }

  // ---------------- habilidades ----------------
  abilityById(id: string) { return ABILITIES.find((a) => a.id === id); }

  cast(id: string) {
    const ab = this.abilityById(id);
    if (!ab) return false;
    if (this.state.level < ab.unlock) return false;
    const cdMult = 1 - 0.05 * (this.state.eternums.ciclone || 0);
    if ((this.cds[id] || 0) > 0) return false;
    this.cds[id] = ab.cd * cdMult;
    audio.ability(ab.id as 'nova' | 'beam' | 'shield');
    if (ab.id === 'nova') {
      const aoe = 150 * this.stats.aoe;
      this.ring(this.px, this.py, '#ff8a3d', aoe * 0.6);
      this.fxs.push({ x: this.px, y: this.py - 20, life: 0.6, max: 0.6, size: aoe * 1.9, rot: this.rng() * 6 });
      this.burst(this.px, this.py - 20, 44, '#ffb257', 'ember', 300);
      this.shake = 12;
      for (const e of this.enemies.slice()) {
        const dx = e.x - this.px, dy = e.y - this.py;
        if (dx * dx + dy * dy < aoe * aoe) {
          const { dmg, crit } = this.rollDamage(3.1);
          this.hurtEnemy(e, dmg, crit);
          const d = Math.hypot(dx, dy) || 1;
          e.vx += (dx / d) * 260; e.vy += (dy / d) * 260;
          e.burn = 2; e.burnDmg = dmg * 0.12 * (1 + skillSpecial(this.state.skills, 'burn') * 0.5);
        }
      }
    } else if (ab.id === 'beam') {
      const t = this.target || this.nearestEnemy();
      const ang = t ? Math.atan2(t.y - (this.py - 20), t.x - this.px) : (this.facing > 0 ? 0 : Math.PI);
      this.beams.push({ x: this.px, y: this.py - 22, angle: ang, life: 0.42, dmg: this.stats.power * 1.5, width: 26 * this.stats.aoe });
      this.shake = 9;
    } else {
      this.shield = this.stats.maxHp * 0.6 + this.stats.power * 3;
      this.shieldT = 7;
      this.invuln = Math.max(this.invuln, 0.5);
      this.ring(this.px, this.py, '#5fd0ff', 34);
    }
    return true;
  }

  nearestEnemy(maxDist = 9999): Enemy | null {
    let best: Enemy | null = null;
    let bd = maxDist * maxDist;
    for (const e of this.enemies) {
      const d = (e.x - this.px) ** 2 + (e.y - this.py) ** 2;
      if (d < bd) { bd = d; best = e; }
    }
    return best;
  }

  attack() {
    const range = 122 * this.stats.range;
    const t = this.target && this.target.hp > 0 && Math.hypot(this.target.x - this.px, this.target.y - this.py) < range * 1.15
      ? this.target : this.nearestEnemy(range * 1.15);
    if (!t) return false;
    this.target = t;
    this.facing = t.x >= this.px ? 1 : -1;
    this.swing = 0.22;
    audio.shoot();
    const n = Math.round(this.stats.proj);
    const chain = skillSpecial(this.state.skills, 'chain');
    const baseAng = Math.atan2(t.y - 20 - (this.py - 24), t.x - this.px);
    for (let i = 0; i < n; i++) {
      const spread = n === 1 ? 0 : (i - (n - 1) / 2) * (0.16 + 0.02 * n);
      const ang = baseAng + spread;
      const { dmg, crit } = this.rollDamage(1 / Math.sqrt(n));
      this.projs.push({
        x: this.px + Math.cos(ang) * 18, y: this.py - 24 + Math.sin(ang) * 18,
        vx: Math.cos(ang) * 620, vy: Math.sin(ang) * 620,
        life: 0.75, dmg, crit, r: 9, color: '#ffd08a', hits: [], pierce: 1 + chain, spin: 0,
      });
    }
    return true;
  }

  dodgeVector(): { x: number; y: number } | null {
    let best: { x: number; y: number } | null = null;
    let urgency = Infinity;
    for (const t of this.teles) {
      if (t.dmg <= 0) continue;
      if (t.kind === 'circle') {
        const dx = this.px - t.x, dy = this.py - t.y;
        const d = Math.hypot(dx, dy);
        if (d < t.r + 22 && t.t < urgency) {
          urgency = t.t;
          best = d < 1 ? { x: 1, y: 0 } : { x: dx / d, y: dy / d };
        }
      } else {
        const lx = t.x2 - t.x, ly = t.y2 - t.y;
        const L = Math.hypot(lx, ly) || 1;
        const ux = lx / L, uy = ly / L;
        const rx = this.px - t.x, ry = this.py - t.y;
        const along = rx * ux + ry * uy;
        const perp = -rx * uy + ry * ux;
        if (along > -30 && along < L + 30 && Math.abs(perp) < t.r + 24 && t.t < urgency) {
          urgency = t.t;
          const sgn = perp >= 0 ? 1 : -1;
          best = { x: -uy * sgn, y: ux * sgn };
        }
      }
    }
    if (!best) {
      for (const p of this.eprojs) {
        const dx = this.px - p.x, dy = (this.py - 24) - p.y;
        const d = Math.hypot(dx, dy);
        if (d > 90) continue;
        const sp = Math.hypot(p.vx, p.vy) || 1;
        const approaching = (dx * p.vx + dy * p.vy) / sp > 0;
        if (!approaching) continue;
        const sgn = (-dx * p.vy + dy * p.vx) >= 0 ? 1 : -1;
        best = { x: (-p.vy / sp) * sgn, y: (p.vx / sp) * sgn };
        break;
      }
    }
    return best;
  }

  // ---------------- loop ----------------
  update(dt: number) {
    dt = Math.min(dt, 0.05);
    // câmera lenta cinematográfica (entrada/morte de chefe)
    const realDt = dt;
    this.timeScale = lerp(this.timeScale, 1, 1 - Math.pow(0.35, realDt));
    dt *= this.timeScale;
    this.zoomPunch = Math.max(0, this.zoomPunch - realDt * 0.18);
    if (this.banner) { this.banner.t -= realDt; if (this.banner.t <= 0) this.banner = null; }
    this.time += dt;
    const s = this.state;
    s.playtime += dt;
    this.saveT += dt;
    if (this.saveT > 6) { this.saveT = 0; this.save(); }
    if (this.lootToastT > 0) this.lootToastT -= dt;

    // ---- input / movimento
    let mx = this.moveVec.x, my = this.moveVec.y;
    if (this.pointer.active) {
      const dx = this.pointer.x - this.px, dy = this.pointer.y - this.py;
      const d = Math.hypot(dx, dy);
      if (d > 18) { mx = dx / d; my = dy / d; }
    }
    if (s.autoMode && (mx === 0 && my === 0)) {
      // piloto automático: caça o inimigo mais próximo, senão vagueia
      const t = this.target && this.target.hp > 0 ? this.target : this.nearestEnemy(760);
      if (t) {
        const dx = t.x - this.px, dy = t.y - this.py;
        const d = Math.hypot(dx, dy);
        const keep = 74 * this.stats.range;
        if (d > keep) { mx = dx / d; my = dy / d; }
      } else {
        this.wanderT -= dt;
        if (this.wanderT <= 0) {
          this.wanderT = 2.4 + this.rng() * 2.4;
          const a = this.rng() * Math.PI * 2;
          this.wanderX = Math.cos(a); this.wanderY = Math.sin(a);
        }
        mx = this.wanderX; my = this.wanderY;
      }
    }
    // esquiva automática de ataques telegrafados
    if (s.autoMode && !this.pointer.active) {
      const dodge = this.dodgeVector();
      if (dodge) { mx = dodge.x; my = dodge.y; }
    }
    const mag = Math.hypot(mx, my);
    if (mag > 1) { mx /= mag; my /= mag; }
    const spd = 132 * this.stats.speed;
    let nx = this.px + mx * spd * dt;
    let ny = this.py + my * spd * dt;
    const col = this.world.collide(nx, ny, 13);
    nx = col.x; ny = col.y;
    this.pvx = (nx - this.px) / Math.max(dt, 0.001);
    this.pvy = (ny - this.py) / Math.max(dt, 0.001);
    this.px = nx; this.py = ny;
    const moving = Math.hypot(mx, my) > 0.05;
    if (moving) this.anim += dt * (0.6 + this.stats.speed * 0.4);
    if (mx !== 0) this.facing = mx > 0 ? 1 : -1;

    // ---- regeneração e timers
    this.hp = Math.min(this.stats.maxHp, this.hp + this.stats.hpRegen * dt);
    this.flash = Math.max(0, this.flash - dt * 3);
    this.swing = Math.max(0, this.swing - dt);
    this.invuln = Math.max(0, this.invuln - dt);
    this.reviveCd = Math.max(0, this.reviveCd - dt);
    if (this.shieldT > 0) { this.shieldT -= dt; if (this.shieldT <= 0) this.shield = 0; }
    for (const ab of ABILITIES) this.cds[ab.id] = Math.max(0, (this.cds[ab.id] || 0) - dt);

    // ---- ataque automático
    this.atkTimer -= dt;
    if (this.atkTimer <= 0) {
      if (this.attack()) this.atkTimer = 1 / (1.05 * this.stats.atkSpeed);
      else this.atkTimer = 0.12;
    }

    // ---- spawn
    const cap = this.bossActive ? 8 : 11;
    if (this.enemies.length < cap && this.rng() < dt * 3.4) this.spawnEnemy(false);
    if (!this.bossActive && s.killsInZone > 0 && s.killsInZone % this.killsToBoss() === 0 && this.bossMeter === 0) {
      this.bossMeter = 1;
      this.spawnEnemy(true);
    }
    // despawn distantes
    for (const e of this.enemies.slice()) {
      if (Math.hypot(e.x - this.px, e.y - this.py) > 1400) {
        if (e.isBoss) {
          this.bossActive = null;
          this.bossMeter = 0;
          this.state.killsInZone = Math.max(0, this.state.killsInZone - (this.state.killsInZone % this.killsToBoss()) - 1);
          this.notice('O Colosso se perdeu na névoa...', '#ff6b6b');
        }
        this.enemies = this.enemies.filter((x) => x !== e);
        if (this.target === e) this.target = null;
      }
    }

    // ---- projéteis
    for (const p of this.projs.slice()) {
      p.life -= dt;
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.spin += dt * 20;
      if (p.life <= 0) { this.projs = this.projs.filter((q) => q !== p); continue; }
      for (const e of this.enemies) {
        if (p.hits.includes(e.id)) continue;
        const dx = e.x - p.x, dy = e.y - 22 - p.y;
        if (dx * dx + dy * dy < (e.r + p.r) ** 2) {
          p.hits.push(e.id);
          const crit = p.crit;
          this.hurtEnemy(e, p.dmg, crit);
          const burn = skillSpecial(this.state.skills, 'burn');
          if (burn > 0 && this.rng() < 0.25) { e.burn = 2; e.burnDmg = p.dmg * 0.12 * burn; }
          p.pierce--;
          if (p.pierce <= 0) { this.projs = this.projs.filter((q) => q !== p); break; }
        }
      }
    }

    // ---- avisos de ataque (telegraphs)
    for (const t of this.teles.slice()) {
      t.t -= dt;
      if (t.t <= 0) {
        this.teles = this.teles.filter((q) => q !== t);
        this.resolveTele(t);
      }
    }
    // ---- projéteis inimigos
    for (const p of this.eprojs.slice()) {
      p.life -= dt;
      p.x += p.vx * dt; p.y += p.vy * dt;
      const hitP = Math.hypot(this.px - p.x, this.py - 26 - p.y) < p.r + 12;
      if (hitP) this.hurtPlayer(p.dmg);
      if (hitP || p.life <= 0) this.eprojs = this.eprojs.filter((q) => q !== p);
    }
    // ---- efeitos ilustrados
    if (this.fxs.length > 26) this.fxs.splice(0, this.fxs.length - 26);
    if (this.eprojs.length > 120) this.eprojs.splice(0, this.eprojs.length - 120);
    for (const f of this.fxs.slice()) {
      f.life -= realDt * 0.9 + dt * 0.1;
      if (f.life <= 0) this.fxs = this.fxs.filter((q) => q !== f);
    }

    // ---- feixes
    for (const b of this.beams.slice()) {
      b.life -= dt;
      if (b.life <= 0) { this.beams = this.beams.filter((x) => x !== b); continue; }
      const len = 460;
      const ca = Math.cos(b.angle), sa = Math.sin(b.angle);
      for (const e of this.enemies.slice()) {
        const dx = e.x - b.x, dy = (e.y - 22) - b.y;
        const proj = dx * ca + dy * sa;
        if (proj < 0 || proj > len) continue;
        const perp = Math.abs(-dx * sa + dy * ca);
        if (perp < b.width / 2 + e.r) this.hurtEnemy(e, b.dmg * dt * 6, false, this.rng() < 0.15);
      }
    }

    // ---- inimigos
    for (const e of this.enemies.slice()) {
      e.anim += dt;
      e.hitFlash = Math.max(0, e.hitFlash - dt);
      e.stagger = Math.max(0, e.stagger - dt);
      if (e.burn > 0) {
        e.burn -= dt;
        e.hp -= e.burnDmg * dt;
        if (this.rng() < dt * 8) this.parts.push({ x: e.x + (this.rng() - 0.5) * 14, y: e.y - 20, vx: 0, vy: -40, life: 0.5, max: 0.5, size: 2.5, color: '#ff9a4a', grav: -30, kind: 'ember' });
        if (e.hp <= 0) { this.killEnemy(e); continue; }
      }
      const dx = this.px - e.x, dy = this.py - e.y;
      const d = Math.hypot(dx, dy) || 1;
      e.windup = Math.max(0, e.windup - dt);
      e.atkCd -= dt;
      if (e.spawnT > 0) {
        e.spawnT -= dt;
        if (e.isBoss && this.rng() < dt * 25) this.burst(e.x + (this.rng() - 0.5) * 60, e.y, 2, '#5a4636', 'smoke', 80);
        continue;
      }
      if (e.dashT <= 0) e.facing = dx >= 0 ? 1 : -1;
      if (e.isBoss) {
        this.bossAI(e, dt);
        if (e.dashT > 0) continue;
      }
      const slow = e.stagger > 0 ? 0.35 : e.windup > 0 ? 0.15 : 1;
      const desired = e.r + 22;
      const move = d > desired ? 1 : -0.3;
      e.vx = lerp(e.vx, (dx / d) * e.speed * slow * move, 0.14);
      e.vy = lerp(e.vy, (dy / d) * e.speed * slow * move, 0.14);
      const c = this.world.collide(e.x + e.vx * dt, e.y + e.vy * dt, e.r * 0.7);
      e.x = c.x; e.y = c.y;
      if (d < e.r + 30 && e.atkCd <= 0) {
        e.atkCd = e.isBoss ? 1.1 : 1.6;
        this.hurtPlayer(e.dmg, e);
        this.burst(this.px, this.py - 24, 6, '#ff5555', 'blood', 90);
      }
      // separação simples
      for (const o of this.enemies) {
        if (o === e) continue;
        const ox = e.x - o.x, oy = e.y - o.y;
        const od = Math.hypot(ox, oy);
        const min = (e.r + o.r) * 0.9;
        if (od > 0.001 && od < min) {
          const push = ((min - od) / min) * 40 * dt;
          e.x += (ox / od) * push * 30;
          e.y += (oy / od) * push * 30;
        }
      }
    }

    // ---- caixas de suprimento
    for (const p of this.world.propsNear(this.px, this.py, CHUNK_PX * 0.7)) {
      if (p.kind !== 'caixa' || p.open) continue;
      if (Math.hypot(p.x - this.px, p.y - this.py) < 34) {
        p.open = true;
        const z = ZONES[s.zone];
        const gain = Math.round((14 + z.tier * 12) * this.stats.scrapGain);
        s.scrap += gain;
        this.burst(p.x, p.y - 14, 22, z.accent, 'ember', 180);
        this.ring(p.x, p.y, z.accent, 22);
        audio.loot();
        this.float(p.x, p.y - 38, `+${fmt(gain)}⚙`, '#ffd24a', 11);
        if (this.rng() < 0.55) this.addLoot(makeItem(s.level + z.tier * 5 + 3, this.stats.luck * 1.6, Math.floor(this.rng() * 1e9)));
      }
    }

    // ---- partículas
    for (const p of this.parts.slice()) {
      p.life -= dt;
      if (p.life <= 0) { this.parts = this.parts.filter((q) => q !== p); continue; }
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.vy += p.grav * dt;
      p.vx *= 1 - dt * 1.6;
    }
    for (const f of this.floats.slice()) {
      f.life -= dt;
      f.y += f.vy * dt;
      f.vy *= 1 - dt * 2;
      if (f.life <= 0) this.floats = this.floats.filter((q) => q !== f);
    }
    for (const n of this.notices.slice()) {
      n.life -= dt;
      if (n.life <= 0) this.notices = this.notices.filter((q) => q !== n);
    }

    // ---- telemetria
    this.dpsWindow = this.dpsWindow.filter((w) => this.time - w.t < 4);
    const total = this.dpsWindow.reduce((a, b) => a + b.d, 0);
    this.dps = total / 4;
    this.killWindow = this.killWindow.filter((t) => this.time - t < 6);
    this.killsPerSec = this.killWindow.length / 6;
    if (this.dps > s.bestDps) s.bestDps = this.dps;

    // ---- camera
    const lead = 0.22;
    const tx = this.px + this.pvx * lead;
    const ty = this.py + this.pvy * lead;
    this.camX = lerp(this.camX, tx, 1 - Math.pow(0.0015, dt));
    this.camY = lerp(this.camY, ty, 1 - Math.pow(0.0015, dt));
    this.shake = Math.max(0, this.shake - dt * 34);

    // ---- música adaptativa
    const near = this.enemies.filter((e) => Math.hypot(e.x - this.px, e.y - this.py) < 520).length;
    const intensity = clamp(near / 7 + (this.bossActive ? 0.55 : 0), 0, 1);
    audio.setIntensity(intensity, !!this.bossActive);
  }

  // ---------------- render ----------------
  viewW = 400; viewH = 700;

  render(ctx: CanvasRenderingContext2D, W: number, H: number) {
    this.viewW = W; this.viewH = H;
    const baseZoom = clamp(Math.min(W, H) / 400, 1, 2.3);
    const zoom = baseZoom * (1 + this.zoomPunch);
    this.zoom = zoom;
    const z = ZONES[this.state.zone];
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'medium';
    ctx.save();
    ctx.fillStyle = '#0a0a0c';
    ctx.fillRect(0, 0, W, H);

    const sx = this.shake > 0 ? (this.rng() - 0.5) * this.shake : 0;
    const sy = this.shake > 0 ? (this.rng() - 0.5) * this.shake : 0;
    ctx.translate(W / 2 + sx, H / 2 + sy);
    ctx.scale(zoom, zoom);
    ctx.translate(-this.camX, -this.camY);

    const halfW = W / (2 * zoom) + 80;
    const halfH = H / (2 * zoom) + 80;

    // --- chão (chunks)
    const c0 = Math.floor((this.camX - halfW) / CHUNK_PX);
    const c1 = Math.floor((this.camX + halfW) / CHUNK_PX);
    const r0 = Math.floor((this.camY - halfH) / CHUNK_PX);
    const r1 = Math.floor((this.camY + halfH) / CHUNK_PX);
    for (let cy = r0; cy <= r1; cy++) {
      for (let cx = c0; cx <= c1; cx++) {
        const ch = this.world.get(cx, cy);
        if (ch.canvas) ctx.drawImage(ch.canvas, cx * CHUNK_PX, cy * CHUNK_PX);
      }
    }

    // --- avisos de ataque no chão
    for (const t of this.teles) {
      const p = 1 - t.t / t.max;
      const pulse = 0.5 + Math.sin(this.time * 18) * 0.5;
      ctx.save();
      if (t.kind === 'circle') {
        ctx.fillStyle = `rgba(${t.color},${0.1 + p * 0.12})`;
        ctx.beginPath();
        ctx.ellipse(t.x, t.y, t.r, t.r * 0.62, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = `rgba(${t.color},${0.25 + p * 0.25})`;
        ctx.beginPath();
        ctx.ellipse(t.x, t.y, t.r * p, t.r * 0.62 * p, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = `rgba(${t.color},${0.6 + pulse * 0.4})`;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.ellipse(t.x, t.y, t.r, t.r * 0.62, 0, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        const ang = Math.atan2(t.y2 - t.y, t.x2 - t.x);
        const len = Math.hypot(t.x2 - t.x, t.y2 - t.y);
        ctx.translate(t.x, t.y);
        ctx.rotate(ang);
        ctx.fillStyle = `rgba(${t.color},${0.1 + p * 0.12})`;
        ctx.fillRect(0, -t.r, len, t.r * 2);
        ctx.fillStyle = `rgba(${t.color},${0.3 + p * 0.25})`;
        ctx.fillRect(0, -t.r, len * p, t.r * 2);
        ctx.strokeStyle = `rgba(${t.color},${0.6 + pulse * 0.4})`;
        ctx.lineWidth = 2;
        ctx.strokeRect(0, -t.r, len, t.r * 2);
        // setas
        ctx.fillStyle = `rgba(255,220,200,${0.5 + pulse * 0.4})`;
        for (let i = 1; i < 4; i++) {
          const ax = (len * i) / 4;
          ctx.beginPath();
          ctx.moveTo(ax + 10, 0); ctx.lineTo(ax - 6, -9); ctx.lineTo(ax - 6, 9);
          ctx.closePath(); ctx.fill();
        }
      }
      ctx.restore();
    }

    // --- adereços + entidades ordenados por Y
    type Drawable = { y: number; fn: () => void };
    const list: Drawable[] = [];
    const props = this.world.propsNear(this.camX, this.camY, CHUNK_PX * 1.6);
    for (const p of props) {
      if (Math.abs(p.x - this.camX) > halfW + 90 || Math.abs(p.y - this.camY) > halfH + 130) continue;
      list.push({ y: p.y, fn: () => this.drawProp(ctx, p, z) });
    }
    for (const e of this.enemies) {
      list.push({
        y: e.y, fn: () => {
          const ok = drawEnemySprite(ctx, {
            kind: e.kind, bossType: e.bossType, x: e.x, y: e.y, facing: e.facing, anim: e.anim,
            hitFlash: e.hitFlash, hp: e.hp, maxHp: e.maxHp, isBoss: e.isBoss, isElite: e.isElite,
            accent: z.accent, burn: e.burn, stagger: e.stagger, enraged: e.enraged, spawnT: e.spawnT, windup: e.windup,
          }, this.time);
          if (!ok) drawEnemy(ctx, {
            kind: e.kind, x: e.x, y: e.y, r: e.r, facing: e.facing, anim: e.anim,
            hitFlash: e.hitFlash, hp: e.hp, maxHp: e.maxHp, isBoss: e.isBoss, isElite: e.isElite,
            accent: z.accent, burn: e.burn, stagger: e.stagger,
          }, this.time);
        },
      });
    }
    list.push({
      y: this.py, fn: () => {
        const moving = Math.hypot(this.pvx, this.pvy) > 12;
        const ok = drawPlayerSprite(ctx, {
          x: this.px, y: this.py, facing: this.facing, anim: this.anim, moving,
          shield: this.shield, flash: this.flash, t: this.time, swing: this.swing / 0.22, invuln: this.invuln,
        });
        if (!ok) drawPlayer(ctx, {
          x: this.px, y: this.py, facing: this.facing, anim: this.anim,
          moving, hp: this.hp, maxHp: this.stats.maxHp,
          shield: this.shield, flash: this.flash, t: this.time, swing: this.swing / 0.22, power: this.stats.power,
        });
      },
    });
    list.sort((a, b) => a.y - b.y);
    for (const d of list) d.fn();

    // --- explosões ilustradas
    for (const f of this.fxs) drawExplosion(ctx, f.x, f.y, f.size, 1 - f.life / f.max, f.rot);

    // --- projéteis inimigos
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const p of this.eprojs) {
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 2.2);
      g.addColorStop(0, 'rgba(255,255,255,0.95)');
      g.addColorStop(0.35, p.color);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * 2.2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // --- feixes
    ctx.globalCompositeOperation = 'lighter';
    for (const b of this.beams) {
      const a = clamp(b.life / 0.42, 0, 1);
      const len = 460 + (1 - a) * 60;
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(b.angle);
      const g = ctx.createLinearGradient(0, 0, len, 0);
      g.addColorStop(0, `rgba(255,240,200,${0.95 * a})`);
      g.addColorStop(0.35, `rgba(255,190,90,${0.6 * a})`);
      g.addColorStop(1, 'rgba(255,120,40,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, (-b.width / 2) * a, len, b.width * a);
      ctx.fillStyle = `rgba(255,255,240,${0.9 * a})`;
      ctx.fillRect(0, -3 * a, len, 6 * a);
      ctx.restore();
    }
    // --- projéteis
    for (const p of this.projs) {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(Math.atan2(p.vy, p.vx) + p.spin * 0.2);
      const g = ctx.createLinearGradient(-12, 0, 12, 0);
      g.addColorStop(0, 'rgba(255,150,60,0)');
      g.addColorStop(1, p.crit ? 'rgba(255,240,190,0.95)' : 'rgba(255,205,130,0.9)');
      ctx.fillStyle = g;
      ctx.fillRect(-16, -2.5, 26, 5);
      ctx.fillStyle = '#fff6e0';
      ctx.fillRect(-2, -1.5, 7, 3);
      ctx.restore();
    }
    // --- partículas
    for (const p of this.parts) {
      const a = clamp(p.life / p.max, 0, 1);
      if (p.kind === 'ring') {
        ctx.strokeStyle = p.color;
        ctx.globalAlpha = a * 0.8;
        ctx.lineWidth = 3 * a + 1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (1.6 - a * 0.6) * 2.2, 0, Math.PI * 2);
        ctx.stroke();
      } else if (p.kind === 'smoke') {
        ctx.globalAlpha = a * 0.35;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (2.4 - a), 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.globalAlpha = a;
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
      }
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';

    // --- névoa do bioma
    ctx.fillStyle = z.fog;
    ctx.fillRect(this.camX - halfW, this.camY - halfH, halfW * 2, halfH * 2);

    // --- textos flutuantes
    ctx.textAlign = 'center';
    for (const f of this.floats) {
      const a = clamp(f.life / 0.9, 0, 1);
      ctx.globalAlpha = a;
      ctx.font = `bold ${f.size}px ui-monospace, monospace`;
      ctx.fillStyle = 'rgba(0,0,0,0.65)';
      ctx.fillText(f.text, f.x + 1.5, f.y + 1.5);
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, f.x, f.y);
    }
    ctx.globalAlpha = 1;
    ctx.restore();

    // --- cinzas caindo (espaço de tela)
    ctx.save();
    for (const a of this.ashParts) {
      a.x += a.vx * 0.016;
      a.y += a.vy * 0.016;
      if (a.y > H + 10) { a.y = -10; a.x = Math.random() * W; }
      if (a.x > W + 10) a.x = -10;
      ctx.globalAlpha = a.a;
      ctx.fillStyle = z.ash;
      ctx.fillRect(a.x, a.y, a.s, a.s);
    }
    ctx.restore();

    // --- vinheta
    const vg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.28, W / 2, H / 2, Math.max(W, H) * 0.75);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,0.62)');
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);

    // --- alerta de vida baixa
    const hpPct = this.hp / this.stats.maxHp;
    if (hpPct < 0.35) {
      const pulse = 0.14 + Math.sin(this.time * 7) * 0.08;
      const rg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.2, W / 2, H / 2, Math.max(W, H) * 0.7);
      rg.addColorStop(0, 'rgba(255,0,40,0)');
      rg.addColorStop(1, `rgba(255,20,50,${pulse})`);
      ctx.fillStyle = rg;
      ctx.fillRect(0, 0, W, H);
    }
    // --- scanlines sutis
    ctx.globalAlpha = 0.045;
    ctx.fillStyle = '#000';
    for (let y = 0; y < H; y += 3) ctx.fillRect(0, y, W, 1);
    ctx.globalAlpha = 1;
  }

  private drawProp(ctx: CanvasRenderingContext2D, p: Prop, z: typeof ZONES[0]) {
    const spr = propSprite(z, p.kind, p.seed, !!p.open);
    ctx.save();
    ctx.translate(p.x, p.y);
    if (p.flip && p.kind !== 'caixa') ctx.scale(-1, 1);
    const sc = p.scale;
    ctx.drawImage(spr, (-spr.width / 2) * sc, -spr.height * sc, spr.width * sc, spr.height * sc);
    ctx.restore();
    if (p.kind === 'caixa' && !p.open) {
      // coluna sutil de luz de relíquia + fagulhas flutuantes no baú fechado
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const pulse = 0.55 + Math.sin(this.time * 3.8 + p.seed) * 0.25;
      const beam = ctx.createLinearGradient(p.x, p.y - 14, p.x, p.y - 68);
      beam.addColorStop(0, z.accent);
      beam.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.globalAlpha = 0.24 * pulse;
      ctx.fillStyle = beam;
      ctx.beginPath();
      ctx.moveTo(p.x - 16, p.y - 12);
      ctx.lineTo(p.x - 8, p.y - 66);
      ctx.lineTo(p.x + 8, p.y - 66);
      ctx.lineTo(p.x + 16, p.y - 12);
      ctx.closePath();
      ctx.fill();
      // 2 fagulhas subindo
      for (let i = 0; i < 2; i++) {
        const ph = ((this.time * 0.9 + p.seed * 0.3 + i * 0.5) % 1);
        const sx = p.x + Math.sin(this.time * 3 + i * 2 + p.seed) * 10;
        const sy = p.y - 16 - ph * 38;
        ctx.globalAlpha = (1 - ph) * 0.75;
        ctx.fillStyle = '#fff5d6';
        ctx.fillRect(sx - 1, sy - 1, 2.2, 2.2);
      }
      ctx.restore();
    }
  }

  // ---------------- snapshot para UI ----------------
  snapshot(): Snapshot {
    const s = this.state;
    const z = ZONES[s.zone];
    return {
      level: s.level, xp: s.xp, xpNeed: xpNeed(s.level),
      hp: this.hp, maxHp: this.stats.maxHp, stats: this.stats,
      dps: this.dps, scrap: s.scrap, essence: s.essence, eterna: s.eterna, cycle: s.cycle,
      zoneName: z.name, zoneDesc: z.desc, zoneId: z.id, zoneEmblem: z.emblem, tier: z.tier, reqLevel: z.reqLevel,
      unlocked: s.unlocked, killsInZone: s.killsInZone, killsToBoss: this.killsToBoss(),
      boss: this.bossActive ? {
        name: this.bossActive.name,
        title: BOSS_TITLES[this.bossActive.bossType || 'colossus'],
        hp: Math.max(0, this.bossActive.hp), maxHp: this.bossActive.maxHp,
        phase: this.bossActive.phase, enraged: this.bossActive.enraged, spawning: this.bossActive.spawnT > 0,
      } : null,
      banner: this.banner ? { ...this.banner } : null,
      equipped: s.equipped, inventory: s.inventory, skills: s.skills, eternums: s.eternums, skillPoints: s.skillPoints,
      autoMode: s.autoMode, autoEquip: s.autoEquip, notices: this.notices,
      abilities: ABILITIES.map((a: Ability) => ({
        id: a.id, name: a.name, icon: a.icon, cd: this.cds[a.id] || 0,
        cdMax: a.cd * (1 - 0.05 * (s.eternums.ciclone || 0)), unlock: a.unlock, color: a.color, desc: a.desc,
      })),
      totalKills: s.totalKills, bossKills: s.bossKills, playtime: s.playtime, bestDps: s.bestDps,
      killsPerSec: this.killsPerSec, enemies: this.enemies.length, seenIntro: s.seenIntro,
    };
  }

  toggleAuto() { this.state.autoMode = !this.state.autoMode; audio.ui(this.state.autoMode); this.save(); }
  toggleAutoEquip() {
    this.state.autoEquip = !this.state.autoEquip;
    audio.ui(this.state.autoEquip);
    this.save();
  }
  markIntro() { this.state.seenIntro = true; this.save(); }
  hardReset() {
    localStorage.removeItem(SAVE_KEY);
    this.state = freshState();
    this.enemies = [];
    this.projs = [];
    this.bossActive = null;
    this.world.setZone(0);
    this.recompute();
    this.hp = this.stats.maxHp;
    this.notice('Um novo farol. Um novo ciclo.', '#ffd24a');
  }
}
