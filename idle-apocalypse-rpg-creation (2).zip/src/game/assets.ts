// ============================================================
//  CINZAS — carregamento de assets (chroma-key, recorte, variantes)
//  As imagens são embutidas no HTML (data-URI) pelo vite-singlefile,
//  então funcionam offline e sem "canvas contaminado".
// ============================================================
import heroUrl from '../assets/hero.jpg';
import colossusUrl from '../assets/boss_colossus.jpg';
import wraithUrl from '../assets/boss_wraith.jpg';
import beastUrl from '../assets/boss_beast.jpg';
import ghoulUrl from '../assets/enemy_ghoul.jpg';
import droneUrl from '../assets/enemy_drone.jpg';
import explosionUrl from '../assets/fx_explosion.jpg';
import itemsUrl from '../assets/items_sheet.jpg';
import keyartUrl from '../assets/keyart.jpg';
import metalUrl from '../assets/ui_metal.jpg';

export { keyartUrl, metalUrl };

export type Sprite = {
  img: HTMLCanvasElement;   // sprite recortado
  white: HTMLCanvasElement; // silhueta branca (flash de dano)
  red: HTMLCanvasElement;   // variante fúria/tingida
  w: number; h: number;
};

export type Assets = {
  hero: Sprite;
  colossus: Sprite;
  wraith: Sprite;
  beast: Sprite;
  ghoul: Sprite;
  drone: Sprite;
  explosion: HTMLCanvasElement;
  items: Record<string, HTMLCanvasElement>;
  metal: HTMLImageElement;
  heroFull: string;  // data-URL do herói recortado (tela de equipamento)
  heroFace: string;  // retrato do rosto (HUD)
};

function portraits(s: Sprite) {
  const full = s.img.toDataURL('image/png');
  const c = document.createElement('canvas');
  c.width = c.height = 96;
  const ctx = c.getContext('2d')!;
  const size = s.w * 0.55;
  const sx = s.w * 0.28, sy = 0;
  const g = ctx.createRadialGradient(48, 52, 4, 48, 52, 60);
  g.addColorStop(0, '#3a2414');
  g.addColorStop(1, '#0c0a0c');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 96, 96);
  ctx.drawImage(s.img, sx, sy, size, size, 0, 4, 96, 96);
  return { full, face: c.toDataURL('image/png') };
}

export let ASSETS: Assets | null = null;
const listeners = new Set<() => void>();
export function onAssets(fn: () => void) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function loadImg(src: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const im = new Image();
    im.onload = () => res(im);
    im.onerror = rej;
    im.src = src;
  });
}

function tinted(src: HTMLCanvasElement, color: string, alpha = 1): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = src.width; c.height = src.height;
  const ctx = c.getContext('2d')!;
  ctx.drawImage(src, 0, 0);
  ctx.globalCompositeOperation = 'source-atop';
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, c.width, c.height);
  return c;
}

/** Remove o fundo verde, apara bordas transparentes e reduz para `targetH` px */
function keyed(im: HTMLImageElement, targetH: number): Sprite {
  // 1) reduz primeiro (2x o alvo) para acelerar o processamento
  const workH = Math.min(im.height, targetH * 2);
  const workW = Math.round((im.width / im.height) * workH);
  const c = document.createElement('canvas');
  c.width = workW; c.height = workH;
  const ctx = c.getContext('2d', { willReadFrequently: true })!;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(im, 0, 0, workW, workH);
  const data = ctx.getImageData(0, 0, workW, workH);
  const d = data.data;
  let minX = workW, minY = workH, maxX = 0, maxY = 0;
  for (let i = 0, p = 0; i < d.length; i += 4, p++) {
    const r = d[i], g = d[i + 1], b = d[i + 2];
    const mx = Math.max(r, b);
    const dom = g - mx; // dominância do verde
    if (g > 70 && dom > 40) {
      d[i + 3] = 0;
    } else {
      if (dom > 8) {
        // borda: suaviza alpha e remove vazamento verde
        const a = 1 - Math.min(1, (dom - 8) / 40);
        d[i + 3] = Math.round(d[i + 3] * a);
        d[i + 1] = mx;
      }
      if (d[i + 3] > 24) {
        const x = p % workW, y = (p / workW) | 0;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  ctx.putImageData(data, 0, 0);
  if (maxX <= minX || maxY <= minY) { minX = 0; minY = 0; maxX = workW - 1; maxY = workH - 1; }

  // 2) recorta e reduz para o tamanho final
  const cw = maxX - minX + 1, ch = maxY - minY + 1;
  const scale = targetH / ch;
  const out = document.createElement('canvas');
  out.width = Math.max(1, Math.round(cw * scale));
  out.height = targetH;
  const octx = out.getContext('2d')!;
  octx.imageSmoothingQuality = 'high';
  octx.drawImage(c, minX, minY, cw, ch, 0, 0, out.width, out.height);

  return {
    img: out,
    white: tinted(out, '#fff4e0'),
    red: tinted(out, 'rgba(255,40,40,1)', 0.38),
    w: out.width, h: out.height,
  };
}

/** Explosão em fundo preto → canvas pronto para mistura aditiva */
function fxSprite(im: HTMLImageElement, size: number) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const ctx = c.getContext('2d')!;
  const s = Math.min(im.width, im.height);
  ctx.drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, size, size);
  // máscara radial para apagar bordas retas
  ctx.globalCompositeOperation = 'destination-in';
  const g = ctx.createRadialGradient(size / 2, size / 2, size * 0.25, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(0,0,0,1)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  return c;
}

/** Folha 3x2 de ícones → um canvas por slot */
function sliceItems(im: HTMLImageElement) {
  const order = ['arma', 'nucleo', 'armadura', 'mascara', 'botas', 'talisma'];
  const cx = [0.186, 0.501, 0.816];
  const cy = [0.277, 0.721];
  const size = Math.round(im.width * 0.262);
  const out: Record<string, HTMLCanvasElement> = {};
  order.forEach((slot, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const sx = Math.round(im.width * cx[col] - size / 2);
    const sy = Math.round(im.height * cy[row] - size / 2);
    const c = document.createElement('canvas');
    c.width = c.height = 128;
    const ctx = c.getContext('2d')!;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(im, sx, sy, size, size, 0, 0, 128, 128);
    out[slot] = c;
  });
  return out;
}

let loading: Promise<Assets> | null = null;

export function loadAssets(): Promise<Assets> {
  if (loading) return loading;
  loading = (async () => {
    const [hero, colossus, wraith, beast, ghoul, drone, expl, items, metal] = await Promise.all([
      loadImg(heroUrl), loadImg(colossusUrl), loadImg(wraithUrl), loadImg(beastUrl),
      loadImg(ghoulUrl), loadImg(droneUrl), loadImg(explosionUrl), loadImg(itemsUrl),
      loadImg(metalUrl),
    ]);
    const heroS = keyed(hero, 200);
    const pr = portraits(heroS);
    const a: Assets = {
      heroFull: pr.full,
      heroFace: pr.face,
      hero: heroS,
      colossus: keyed(colossus, 380),
      wraith: keyed(wraith, 380),
      beast: keyed(beast, 300),
      ghoul: keyed(ghoul, 170),
      drone: keyed(drone, 140),
      explosion: fxSprite(expl, 256),
      items: sliceItems(items),
      metal,
    };
    ASSETS = a;
    listeners.forEach((f) => f());
    return a;
  })();
  return loading;
}
