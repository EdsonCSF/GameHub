// ============================================================
//  CINZAS — mundo procedural: biomas, texturas, chunks, props
// ============================================================
import { fbm, hash2, mulberry32, clamp, lerp } from './rng';
import { ASSETS, onAssets } from './assets';

export const TILE = 64;
export const CHUNK = 6; // tiles por lado
export const CHUNK_PX = TILE * CHUNK;

export type PropKind =
  | 'rocha' | 'arvore' | 'carro' | 'pilar' | 'cristal' | 'arbusto'
  | 'barril' | 'ruina' | 'osso' | 'caixa' | 'antena';

export type Prop = {
  x: number; y: number; kind: PropKind; solid: boolean; r: number;
  seed: number; scale: number; flip: boolean; open?: boolean;
};

export type Chunk = { cx: number; cy: number; props: Prop[]; canvas: HTMLCanvasElement | null; lastUse: number };

export type ZoneDef = {
  id: number; name: string; desc: string; reqLevel: number; tier: number;
  emblem: string;
  ground: string[]; accent: string; fog: string; ash: string;
  scale: string; root: number; tempo: number;
  props: PropKind[];
  enemies: string[];
  density: number;
};

const rgb = (hex: string) => {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255] as [number, number, number];
};
const mix = (a: [number, number, number], b: [number, number, number], t: number): [number, number, number] =>
  [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const css = (c: [number, number, number]) => `rgb(${c[0] | 0},${c[1] | 0},${c[2] | 0})`;

function ramp(colors: string[], t: number): [number, number, number] {
  const stops = colors.map(rgb);
  const x = clamp(t, 0, 1) * (stops.length - 1);
  const i = Math.min(stops.length - 2, Math.floor(x));
  return mix(stops[i], stops[i + 1], x - i);
}

export const ZONES: ZoneDef[] = [
  {
    id: 0, name: 'Planície de Cinzas', desc: 'Onde o mundo terminou de queimar.', reqLevel: 1, tier: 1,
    emblem: '≋', ground: ['#262320', '#383430', '#4d4741', '#665e55'], accent: '#ff9d47', fog: 'rgba(180,155,130,0.08)', ash: '#d8d2c6',
    scale: 'penta', root: 45, tempo: 84,
    props: ['rocha', 'arbusto', 'arvore', 'osso', 'caixa'], enemies: ['batedor', 'cão', 'espectro'], density: 0.42,
  },
  {
    id: 1, name: 'Rodovia Morta', desc: 'Mil carros fugindo do mesmo nada.', reqLevel: 6, tier: 2,
    emblem: '≡', ground: ['#1d1f24', '#292c33', '#363a42', '#484c56'], accent: '#f0b942', fog: 'rgba(120,130,150,0.10)', ash: '#cfd6de',
    scale: 'phrygian', root: 43, tempo: 92,
    props: ['carro', 'rocha', 'pilar', 'barril', 'caixa', 'osso'], enemies: ['batedor', 'bruto', 'drone'], density: 0.5,
  },
  {
    id: 2, name: 'Pântano Ácido', desc: 'A chuva ainda cai, mas errada.', reqLevel: 14, tier: 3,
    emblem: '༄', ground: ['#152018', '#1f3023', '#2b4230', '#3b593c'], accent: '#7dff5c', fog: 'rgba(90,220,110,0.09)', ash: '#b6e08a',
    scale: 'hirajoshi', root: 41, tempo: 78,
    props: ['arvore', 'arbusto', 'cristal', 'barril', 'osso', 'caixa'], enemies: ['cão', 'espectro', 'bruto'], density: 0.62,
  },
  {
    id: 3, name: 'Cidade Afundada', desc: 'Arranha-céus ajoelhados na lama.', reqLevel: 24, tier: 4,
    emblem: '⌂', ground: ['#191c26', '#242936', '#303748', '#40495e'], accent: '#59c7ff', fog: 'rgba(80,150,220,0.11)', ash: '#a9c4d8',
    scale: 'minor', root: 40, tempo: 88,
    props: ['ruina', 'pilar', 'carro', 'antena', 'caixa', 'barril'], enemies: ['drone', 'espectro', 'bruto'], density: 0.66,
  },
  {
    id: 4, name: 'Fornalha', desc: 'O chão respira brasas.', reqLevel: 36, tier: 5,
    emblem: '⚭', ground: ['#221410', '#361d14', '#4f2918', '#6e3a1e'], accent: '#ff7a22', fog: 'rgba(255,110,35,0.11)', ash: '#ffc78a',
    scale: 'phrygian', root: 38, tempo: 104,
    props: ['rocha', 'cristal', 'pilar', 'osso', 'caixa', 'barril'], enemies: ['bruto', 'batedor', 'espectro'], density: 0.6,
  },
  {
    id: 5, name: 'Campos Vitrificados', desc: 'Areia virada em vidro e silêncio.', reqLevel: 50, tier: 6,
    emblem: '❖', ground: ['#26323d', '#364654', '#495e70', '#627c91'], accent: '#9be4ff', fog: 'rgba(185,230,255,0.12)', ash: '#e8f6ff',
    scale: 'penta', root: 36, tempo: 96,
    props: ['cristal', 'ruina', 'rocha', 'antena', 'caixa'], enemies: ['drone', 'espectro', 'bruto'], density: 0.55,
  },
  {
    id: 6, name: 'Coração da Cinza', desc: 'O que sobrou do primeiro dia.', reqLevel: 70, tier: 8,
    emblem: '✵', ground: ['#18101c', '#26172c', '#36203f', '#4b2c57'], accent: '#ff4fa3', fog: 'rgba(200,50,120,0.11)', ash: '#ffb3d6',
    scale: 'hirajoshi', root: 34, tempo: 112,
    props: ['cristal', 'ruina', 'osso', 'pilar', 'caixa', 'antena'], enemies: ['bruto', 'drone', 'espectro'], density: 0.7,
  },
];

export function zoneById(id: number): ZoneDef {
  return ZONES[clamp(id, 0, ZONES.length - 1)];
}

// ------------------------------------------------------------
//  Sprites de adereços e Baús detalhados
// ------------------------------------------------------------
const spriteCache = new Map<string, HTMLCanvasElement>();

function tex(ctx: CanvasRenderingContext2D, w: number, h: number, seed: number, alpha: number) {
  ctx.save();
  if (ASSETS?.metal) {
    ctx.globalCompositeOperation = 'overlay';
    ctx.globalAlpha = alpha * 0.45;
    ctx.drawImage(ASSETS.metal, -w / 2, -h, w, h);
  }
  ctx.globalCompositeOperation = 'source-over';
  ctx.globalAlpha = alpha * 0.7;
  for (let i = 0; i < w * h * 0.1; i++) {
    const x = (hash2(i, seed, 3) - 0.5) * w;
    const y = -hash2(i, seed, 7) * h;
    const v = hash2(i, seed, 11);
    ctx.fillStyle = v > 0.5 ? 'rgba(0,0,0,0.45)' : 'rgba(255,255,255,0.2)';
    ctx.fillRect(x, y, 1 + (v > 0.9 ? 1 : 0), 1);
  }
  ctx.restore();
}

function drawSupplyChest(
  ctx: CanvasRenderingContext2D,
  zone: ZoneDef,
  seed: number,
  open: boolean,
) {
  const acc = zone.accent;
  const accRgb = rgb(acc);
  const darkAcc = css(mix(accRgb, [10, 8, 12], 0.6));
  const brightAcc = css(mix(accRgb, [255, 250, 240], 0.65));

  // sombra projetada no chão + oclusão de ambiente
  ctx.save();
  const shGrad = ctx.createRadialGradient(0, -4, 4, 0, -4, 38);
  shGrad.addColorStop(0, 'rgba(0,0,0,0.78)');
  shGrad.addColorStop(0.65, 'rgba(0,0,0,0.42)');
  shGrad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = shGrad;
  ctx.beginPath();
  ctx.ellipse(0, -3, 38, 13, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // halo sutil na base quando fechado
  if (!open) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const baseGlow = ctx.createRadialGradient(0, -14, 2, 0, -14, 36);
    baseGlow.addColorStop(0, `rgba(${accRgb[0]},${accRgb[1]},${accRgb[2]},0.38)`);
    baseGlow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = baseGlow;
    ctx.beginPath();
    ctx.ellipse(0, -6, 34, 12, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  const bw = 48; // largura da arca
  const bh = 24; // altura do corpo inferior
  const lh = 13; // altura da tampa

  // --- Tampa aberta (atrás do corpo quando o baú já foi saqueado) ---
  if (open) {
    ctx.save();
    ctx.translate(0, -bh - 2);
    // interior da tampa aberta inclinada para trás
    const openLid = ctx.createLinearGradient(0, -lh - 10, 0, 0);
    openLid.addColorStop(0, '#3e2e20');
    openLid.addColorStop(0.5, '#251c14');
    openLid.addColorStop(1, '#120e0a');
    ctx.fillStyle = openLid;
    ctx.beginPath();
    ctx.moveTo(-bw / 2 + 2, 0);
    ctx.lineTo(-bw / 2 - 3, -lh - 6);
    ctx.quadraticCurveTo(0, -lh - 13, bw / 2 + 3, -lh - 6);
    ctx.lineTo(bw / 2 - 2, 0);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#5c4938';
    ctx.lineWidth = 2;
    ctx.stroke();

    // tiras de ferro internas da tampa
    ctx.fillStyle = '#3c4048';
    ctx.fillRect(-bw * 0.34, -lh - 7, 5, lh + 6);
    ctx.fillRect(bw * 0.34 - 5, -lh - 7, 5, lh + 6);
    ctx.restore();
  }

  // --- Corpo principal da arca (madeira carbonizada + placas de aço) ---
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(-bw / 2, -bh);
  ctx.lineTo(bw / 2, -bh);
  ctx.lineTo(bw / 2 - 2, -2);
  ctx.lineTo(-bw / 2 + 2, -2);
  ctx.closePath();

  const bodyGrad = ctx.createLinearGradient(-bw / 2, -bh, bw / 2, -2);
  bodyGrad.addColorStop(0, '#4f3a27');
  bodyGrad.addColorStop(0.45, '#38281b');
  bodyGrad.addColorStop(1, '#1e150e');
  ctx.fillStyle = bodyGrad;
  ctx.fill();

  ctx.save();
  ctx.clip();
  tex(ctx, bw * 1.4, bh * 2.5, seed, 0.9);
  // ripas horizontais
  ctx.strokeStyle = 'rgba(0,0,0,0.55)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-bw / 2, -bh * 0.55);
  ctx.lineTo(bw / 2, -bh * 0.55);
  ctx.stroke();
  ctx.restore();

  ctx.strokeStyle = '#140f0b';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  // --- Interior brilhante se estiver aberto ---
  if (open) {
    ctx.save();
    const inGrad = ctx.createLinearGradient(0, -bh - 4, 0, -bh + 7);
    inGrad.addColorStop(0, brightAcc);
    inGrad.addColorStop(0.6, acc);
    inGrad.addColorStop(1, '#1a110b');
    ctx.fillStyle = inGrad;
    ctx.beginPath();
    ctx.ellipse(0, -bh + 1, bw * 0.42, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // --- Cantoneiras e cintas de aço reforçado no corpo ---
  const strapX = [-bw * 0.36, bw * 0.36 - 6];
  for (const sx of strapX) {
    const stGrad = ctx.createLinearGradient(sx, -bh, sx + 6, -2);
    stGrad.addColorStop(0, '#7a828e');
    stGrad.addColorStop(0.5, '#494f58');
    stGrad.addColorStop(1, '#262a30');
    ctx.fillStyle = stGrad;
    ctx.fillRect(sx, -bh, 6, bh - 2);
    ctx.strokeStyle = '#15171b';
    ctx.lineWidth = 1;
    ctx.strokeRect(sx, -bh, 6, bh - 2);
    // rebites
    ctx.fillStyle = '#b8c0cc';
    ctx.fillRect(sx + 2, -bh + 3, 2, 2);
    ctx.fillRect(sx + 2, -7, 2, 2);
  }

  // base metálica inferior
  ctx.fillStyle = '#353941';
  ctx.fillRect(-bw / 2 + 1, -5, bw - 2, 3.5);

  // --- Tampa abobadada (quando fechado) ---
  if (!open) {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-bw / 2 - 1, -bh);
    ctx.lineTo(-bw / 2 + 2, -bh - lh + 2);
    ctx.quadraticCurveTo(0, -bh - lh - 6, bw / 2 - 2, -bh - lh + 2);
    ctx.lineTo(bw / 2 + 1, -bh);
    ctx.closePath();

    const lidGrad = ctx.createLinearGradient(0, -bh - lh - 5, 0, -bh);
    lidGrad.addColorStop(0, '#6e5238');
    lidGrad.addColorStop(0.55, '#463322');
    lidGrad.addColorStop(1, '#261b12');
    ctx.fillStyle = lidGrad;
    ctx.fill();

    ctx.save();
    ctx.clip();
    tex(ctx, bw * 1.4, (bh + lh) * 2, seed + 7, 0.85);
    // brilho especular no topo da tampa
    ctx.strokeStyle = 'rgba(255,235,205,0.28)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-bw * 0.38, -bh - lh + 2);
    ctx.quadraticCurveTo(0, -bh - lh - 3, bw * 0.38, -bh - lh + 2);
    ctx.stroke();
    ctx.restore();

    ctx.strokeStyle = '#140f0b';
    ctx.lineWidth = 2;
    ctx.stroke();

    // cintas de aço na tampa
    for (const sx of strapX) {
      const stGrad = ctx.createLinearGradient(0, -bh - lh - 3, 0, -bh);
      stGrad.addColorStop(0, '#99a3b2');
      stGrad.addColorStop(0.6, '#565d68');
      stGrad.addColorStop(1, '#2f333b');
      ctx.fillStyle = stGrad;
      ctx.fillRect(sx, -bh - lh, 6, lh);
      ctx.strokeStyle = '#15171b';
      ctx.lineWidth = 1;
      ctx.strokeRect(sx, -bh - lh, 6, lh);
    }

    // fresta luminosa entre a tampa e a caixa
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = brightAcc;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(-bw * 0.42, -bh);
    ctx.lineTo(bw * 0.42, -bh);
    ctx.stroke();
    ctx.restore();
    ctx.restore();
  }

  // --- Fechadura / Núcleo rúnico frontal ---
  const lockY = -bh + 2;
  ctx.save();
  // escudo metálico da fechadura
  ctx.fillStyle = '#2a2e36';
  ctx.strokeStyle = '#8d96a5';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-8, lockY - 7);
  ctx.lineTo(8, lockY - 7);
  ctx.lineTo(10, lockY + 3);
  ctx.lineTo(0, lockY + 11);
  ctx.lineTo(-10, lockY + 3);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  if (!open) {
    // cristal/núcleo aceso
    ctx.globalCompositeOperation = 'lighter';
    const gemGlow = ctx.createRadialGradient(0, lockY + 1, 0, 0, lockY + 1, 13);
    gemGlow.addColorStop(0, '#ffffff');
    gemGlow.addColorStop(0.35, brightAcc);
    gemGlow.addColorStop(0.7, acc);
    gemGlow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = gemGlow;
    ctx.beginPath();
    ctx.arc(0, lockY + 1, 13, 0, Math.PI * 2);
    ctx.fill();

    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = brightAcc;
    ctx.strokeStyle = darkAcc;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, lockY - 4);
    ctx.lineTo(5, lockY + 1);
    ctx.lineTo(0, lockY + 6);
    ctx.lineTo(-5, lockY + 1);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else {
    // encaixe vazio quando aberto
    ctx.fillStyle = '#121317';
    ctx.beginPath();
    ctx.arc(0, lockY + 1, 4, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function propSprite(zone: ZoneDef, kind: PropKind, seed: number, open = false): HTMLCanvasElement {
  const hasMetal = ASSETS?.metal ? 1 : 0;
  const key = `p${zone.id}_${kind}_${seed}_${open ? 1 : 0}_m${hasMetal}`;
  const hit = spriteCache.get(key);
  if (hit) return hit;

  const rng = mulberry32(seed);
  const W = kind === 'carro' || kind === 'ruina' ? 128 : kind === 'caixa' ? 112 : 96;
  const H = kind === 'ruina' || kind === 'antena' ? 160 : 112;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const ctx = c.getContext('2d')!;
  const g = zone.ground;
  const acc = zone.accent;
  const dark = (hex: string, f: number) => css(mix(rgb(hex), [8, 8, 10], f));
  const light = (hex: string, f: number) => css(mix(rgb(hex), [255, 250, 240], f));

  ctx.translate(W / 2, H);

  const shadow = () => {
    ctx.fillStyle = 'rgba(0,0,0,0.46)';
    ctx.beginPath();
    ctx.ellipse(0, -4, W * 0.3, 9, 0, 0, Math.PI * 2);
    ctx.fill();
  };

  switch (kind) {
    case 'rocha': {
      shadow();
      const n = 6 + Math.floor(rng() * 4);
      const R = 26 + rng() * 14;
      ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        const rr = R * (0.6 + rng() * 0.5);
        ctx.lineTo(Math.cos(a) * rr, -R * 0.75 + Math.sin(a) * rr * 0.72);
      }
      ctx.closePath();
      ctx.fillStyle = dark(g[1], 0.2);
      ctx.fill();
      ctx.strokeStyle = light(g[2], 0.16);
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.clip();
      tex(ctx, W, H, seed, 0.9);
      ctx.fillStyle = light(g[3], 0.22);
      ctx.beginPath();
      ctx.ellipse(-R * 0.25, -R * 1.1, R * 0.42, R * 0.3, -0.4, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case 'arbusto': {
      shadow();
      for (let i = 0; i < 9; i++) {
        const x = (rng() - 0.5) * 40;
        const h = 16 + rng() * 26;
        ctx.strokeStyle = i % 3 === 0 ? light(g[3], 0.08) : dark(g[0], 0.05);
        ctx.lineWidth = 1 + rng() * 1.6;
        ctx.beginPath();
        ctx.moveTo(x * 0.3, -2);
        ctx.quadraticCurveTo(x * 0.8, -h * 0.6, x + (rng() - 0.5) * 10, -h);
        ctx.stroke();
      }
      break;
    }
    case 'arvore': {
      shadow();
      const h = 70 + rng() * 34;
      ctx.strokeStyle = dark(g[0], 0.15);
      ctx.lineWidth = 8 + rng() * 4;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo((rng() - 0.5) * 14, -h * 0.6, (rng() - 0.5) * 20, -h);
      ctx.stroke();
      for (let i = 0; i < 6; i++) {
        const t = 0.35 + rng() * 0.5;
        ctx.lineWidth = 2 + rng() * 2;
        ctx.beginPath();
        ctx.moveTo((rng() - 0.5) * 8, -h * t);
        ctx.lineTo((rng() - 0.5) * 60, -h * t - 12 - rng() * 26);
        ctx.stroke();
      }
      break;
    }
    case 'carro': {
      shadow();
      const w = 96 + rng() * 18;
      const h = 30;
      ctx.fillStyle = dark(g[2], 0.45 + rng() * 0.2);
      ctx.beginPath();
      ctx.moveTo(-w / 2, -6);
      ctx.lineTo(-w / 2 + 6, -h);
      ctx.lineTo(-w * 0.22, -h);
      ctx.lineTo(-w * 0.12, -h - 22);
      ctx.lineTo(w * 0.16, -h - 22);
      ctx.lineTo(w * 0.26, -h);
      ctx.lineTo(w / 2 - 6, -h);
      ctx.lineTo(w / 2, -6);
      ctx.closePath();
      ctx.fill();
      ctx.save();
      ctx.clip();
      tex(ctx, W, H, seed, 1);
      ctx.fillStyle = 'rgba(120,60,25,0.45)';
      for (let i = 0; i < 14; i++) {
        ctx.beginPath();
        ctx.ellipse((rng() - 0.5) * w, -rng() * h * 1.6, 4 + rng() * 12, 3 + rng() * 6, rng(), 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
      ctx.fillStyle = 'rgba(160,190,200,0.25)';
      ctx.fillRect(-w * 0.1, -h - 20, w * 0.24, 16);
      ctx.fillStyle = '#151517';
      [-w * 0.3, w * 0.3].forEach((wx) => {
        ctx.beginPath(); ctx.ellipse(wx, -4, 12, 11, 0, 0, Math.PI * 2); ctx.fill();
      });
      ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = 2;
      ctx.stroke();
      break;
    }
    case 'pilar': {
      shadow();
      const w = 22 + rng() * 10;
      const h = 60 + rng() * 60;
      ctx.fillStyle = dark(g[2], 0.3);
      ctx.beginPath();
      ctx.moveTo(-w / 2, 0); ctx.lineTo(-w / 2 + rng() * 5, -h);
      ctx.lineTo(w / 2 - rng() * 5, -h + rng() * 10); ctx.lineTo(w / 2, 0);
      ctx.closePath(); ctx.fill();
      ctx.save(); ctx.clip(); tex(ctx, W, H, seed, 1); ctx.restore();
      ctx.strokeStyle = 'rgba(20,20,22,0.8)'; ctx.lineWidth = 2; ctx.stroke();
      ctx.strokeStyle = 'rgba(180,170,160,0.55)';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo(-w / 2 + i * 5, -h + 4);
        ctx.lineTo(-w / 2 + i * 5 + (rng() - 0.5) * 12, -h - 10 - rng() * 14);
        ctx.stroke();
      }
      break;
    }
    case 'cristal': {
      shadow();
      const n = 3 + Math.floor(rng() * 3);
      for (let i = 0; i < n; i++) {
        const h = 34 + rng() * 52;
        const w = 9 + rng() * 12;
        const x = (rng() - 0.5) * 34;
        const grd = ctx.createLinearGradient(x, 0, x, -h);
        grd.addColorStop(0, dark(acc, 0.5));
        grd.addColorStop(0.55, acc);
        grd.addColorStop(1, light(acc, 0.65));
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.moveTo(x - w / 2, 0); ctx.lineTo(x, -h); ctx.lineTo(x + w / 2, 0);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = light(acc, 0.8); ctx.lineWidth = 1; ctx.stroke();
      }
      break;
    }
    case 'barril': {
      shadow();
      const w = 24, h = 36;
      const grd = ctx.createLinearGradient(-w / 2, 0, w / 2, 0);
      grd.addColorStop(0, dark(g[1], 0.5));
      grd.addColorStop(0.5, light(g[2], 0.08));
      grd.addColorStop(1, dark(g[0], 0.4));
      ctx.fillStyle = grd;
      ctx.fillRect(-w / 2, -h, w, h);
      ctx.fillStyle = acc;
      ctx.globalAlpha = 0.55;
      ctx.fillRect(-w / 2, -h * 0.66, w, 5);
      ctx.fillRect(-w / 2, -h * 0.3, w, 5);
      ctx.globalAlpha = 1;
      ctx.save(); ctx.beginPath(); ctx.rect(-w / 2, -h, w, h); ctx.clip(); tex(ctx, W, H, seed, 0.8); ctx.restore();
      break;
    }
    case 'ruina': {
      shadow();
      const w = 60 + rng() * 40;
      const h = 70 + rng() * 60;
      ctx.fillStyle = dark(g[2], 0.35);
      ctx.beginPath();
      ctx.moveTo(-w / 2, 0);
      ctx.lineTo(-w / 2 + 4, -h + (rng() - 0.5) * 20);
      ctx.lineTo(-w * 0.1, -h - 10 - rng() * 22);
      ctx.lineTo(w * 0.2, -h + 8);
      ctx.lineTo(w / 2 - 5, -h * 0.7);
      ctx.lineTo(w / 2, 0);
      ctx.closePath(); ctx.fill();
      ctx.save(); ctx.clip(); tex(ctx, W, H, seed, 1);
      ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1.5;
      for (let i = 1; i < 5; i++) {
        ctx.beginPath(); ctx.moveTo(-w / 2, -h * (i / 5)); ctx.lineTo(w / 2, -h * (i / 5) + 4); ctx.stroke();
      }
      ctx.restore();
      ctx.strokeStyle = 'rgba(15,15,18,0.85)'; ctx.lineWidth = 2.5; ctx.stroke();
      break;
    }
    case 'osso': {
      shadow();
      ctx.strokeStyle = 'rgba(226,218,200,0.8)';
      for (let i = 0; i < 5; i++) {
        ctx.lineWidth = 3 + rng() * 3;
        ctx.beginPath();
        ctx.moveTo((rng() - 0.5) * 40, -4);
        ctx.quadraticCurveTo((rng() - 0.5) * 50, -20 - rng() * 20, (rng() - 0.5) * 70, -30 - rng() * 26);
        ctx.stroke();
      }
      break;
    }
    case 'caixa': {
      drawSupplyChest(ctx, zone, seed, open);
      break;
    }
    case 'antena': {
      shadow();
      const h = 120 + rng() * 30;
      ctx.strokeStyle = dark(g[2], 0.2);
      ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -h); ctx.stroke();
      ctx.lineWidth = 2;
      for (let i = 0; i < 5; i++) {
        const y = -h * (0.3 + i * 0.14);
        ctx.beginPath(); ctx.moveTo(-16, y); ctx.lineTo(16, y); ctx.stroke();
      }
      ctx.fillStyle = acc;
      ctx.globalAlpha = 0.85;
      ctx.beginPath(); ctx.arc(0, -h - 4, 5, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = 0.28;
      ctx.beginPath(); ctx.arc(0, -h - 4, 13, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = 1;
      break;
    }
  }
  spriteCache.set(key, c);
  return c;
}

// ------------------------------------------------------------
//  Chunks e Terreno Contínuo (sem emendas de tile + relevo 3D)
// ------------------------------------------------------------
export class World {
  zone: ZoneDef;
  chunks = new Map<string, Chunk>();
  rngSeed: number;
  private cacheOrder: string[] = [];

  constructor(zoneId: number, seed: number) {
    this.zone = zoneById(zoneId);
    this.rngSeed = seed;
    // quando a textura metálica terminar de carregar, atualiza o cache dos chunks
    onAssets(() => {
      spriteCache.clear();
      this.chunks.clear();
      this.cacheOrder = [];
    });
  }

  setZone(zoneId: number) {
    if (this.zone.id === zoneId) return;
    this.zone = zoneById(zoneId);
    this.chunks.clear();
    this.cacheOrder = [];
  }

  key(cx: number, cy: number) {
    return `${cx},${cy}`;
  }

  get(cx: number, cy: number): Chunk {
    const k = this.key(cx, cy);
    let ch = this.chunks.get(k);
    if (!ch) {
      ch = this.generate(cx, cy);
      this.chunks.set(k, ch);
      this.cacheOrder.push(k);
      if (this.cacheOrder.length > 26) {
        const old = this.cacheOrder.shift()!;
        const oc = this.chunks.get(old);
        if (oc && oc.canvas) oc.canvas = null;
        this.chunks.delete(old);
      }
    }
    ch.lastUse = performance.now();
    return ch;
  }

  private generate(cx: number, cy: number): Chunk {
    const rng = mulberry32(Math.floor(hash2(cx, cy, this.rngSeed + this.zone.id * 7919) * 1e9));
    const props: Prop[] = [];
    const step = 108;
    const zone = this.zone;
    for (let ty = 0; ty < CHUNK; ty++) {
      for (let tx = 0; tx < CHUNK; tx++) {
        const px = cx * CHUNK_PX + tx * (CHUNK_PX / CHUNK) + 24;
        const py = cy * CHUNK_PX + ty * (CHUNK_PX / CHUNK) + 24;
        const clump = fbm(cx * 0.7 + tx * 0.35, cy * 0.7 + ty * 0.35, 3, this.rngSeed + 31);
        if (rng() > zone.density * (0.45 + clump)) continue;
        const jx = px + (rng() - 0.5) * step * 0.9;
        const jy = py + (rng() - 0.5) * step * 0.9;
        let kind = zone.props[Math.floor(rng() * zone.props.length)];
        if (rng() < 0.07) kind = 'caixa';
        if (kind === 'caixa' && rng() > 0.34) kind = zone.props[0];
        const solid = kind !== 'arbusto' && kind !== 'osso' && kind !== 'caixa';
        props.push({
          x: jx, y: jy, kind, solid,
          r: kind === 'carro' ? 40 : kind === 'ruina' ? 34 : kind === 'rocha' ? 24 : kind === 'pilar' ? 15 : kind === 'cristal' ? 14 : 12,
          seed: Math.floor(rng() * 64), scale: kind === 'caixa' ? 1.05 : 0.85 + rng() * 0.4, flip: kind === 'caixa' ? false : rng() > 0.5,
        });
      }
    }
    return { cx, cy, props, canvas: this.renderGround(cx, cy), lastUse: performance.now() };
  }

  private renderGround(cx: number, cy: number): HTMLCanvasElement {
    const c = document.createElement('canvas');
    c.width = c.height = CHUNK_PX;
    const ctx = c.getContext('2d')!;
    const zone = this.zone;
    const s = this.rngSeed + zone.id * 911;
    const accRgb = rgb(zone.accent);

    // 1) Mapa de altura e cor contínuo em coordenadas globais (sem costuras entre tiles!)
    const RES = 192; // 2px por amostra = super rápido e nítido
    const scalePx = CHUNK_PX / RES;
    const buf = document.createElement('canvas');
    buf.width = buf.height = RES;
    const bctx = buf.getContext('2d')!;
    const img = bctx.createImageData(RES, RES);
    const d = img.data;

    for (let y = 0; y < RES; y++) {
      const wy = (cy * CHUNK_PX + y * scalePx) * 0.012;
      for (let x = 0; x < RES; x++) {
        const wx = (cx * CHUNK_PX + x * scalePx) * 0.012;

        // ruído multi-escala contínuo
        const macro = fbm(wx * 0.45, wy * 0.45, 3, s);
        const detail = fbm(wx * 2.1 + 17, wy * 2.1 - 11, 3, s + 29);
        const ridge = Math.abs(fbm(wx * 1.35 - 8, wy * 1.35 + 23, 2, s + 73) - 0.5) * 2;

        // derivada direcional para sombreamento 3D (luz vinda de cima-esquerda)
        const h1 = macro * 0.65 + detail * 0.35;
        const h2 = fbm((wx + 0.035) * 2.1 + 17, (wy + 0.035) * 2.1 - 11, 2, s + 29);
        const slope = clamp((h1 - h2) * 2.4, -0.32, 0.32);

        let col = ramp(zone.ground, clamp(h1 + slope * 0.45, 0, 1));

        // iluminação de relevo
        if (slope > 0) col = mix(col, [245, 235, 220], slope * 0.55);
        else col = mix(col, [8, 7, 10], -slope * 0.68);

        // fissuras / veios de acordo com o bioma
        if (ridge < 0.048) {
          const tCrack = 1 - ridge / 0.048;
          if (zone.id === 4 || zone.id === 2 || zone.id === 6 || zone.id === 5) {
            // fissuras incandescentes (lava, ácido, vidro, corrupção)
            col = mix(col, [12, 10, 12], 0.55);
            if (ridge < 0.019) col = mix(col, accRgb, tCrack * 0.85);
          } else {
            // rachaduras profundas de terra/asfalto
            col = mix(col, [10, 9, 11], tCrack * 0.65);
          }
        }

        // seixos e cascalho esparso
        const grit = hash2(cx * RES + x, cy * RES + y, s + 19);
        if (grit > 0.985) col = mix(col, [230, 224, 210], 0.45);
        else if (grit < 0.018) col = mix(col, [10, 9, 10], 0.5);

        const i = (y * RES + x) * 4;
        d[i] = col[0]; d[i + 1] = col[1]; d[i + 2] = col[2]; d[i + 3] = 255;
      }
    }
    bctx.putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(buf, 0, 0, CHUNK_PX, CHUNK_PX);

    // 2) Textura fotográfica de superfície (ASSETS.metal em modo overlay)
    if (ASSETS?.metal) {
      ctx.save();
      ctx.globalCompositeOperation = 'overlay';
      ctx.globalAlpha = 0.24;
      ctx.drawImage(ASSETS.metal, 0, 0, CHUNK_PX, CHUNK_PX);
      ctx.restore();
    }

    // 3) Detalhes ambientais específicos de cada fase/bioma
    const rng = mulberry32(Math.floor(hash2(cx, cy, this.rngSeed + 991 + zone.id * 131) * 1e9));
    this.drawBiomeGroundDetails(ctx, zone, rng, accRgb);

    return c;
  }

  private drawBiomeGroundDetails(
    ctx: CanvasRenderingContext2D,
    zone: ZoneDef,
    rng: () => number,
    accRgb: [number, number, number],
  ) {
    ctx.save();

    // Lajes, placas de pedra e crateras naturais em todos os biomas
    for (let i = 0; i < 9; i++) {
      const x = rng() * CHUNK_PX;
      const y = rng() * CHUNK_PX;
      const r = 16 + rng() * 38;
      const grd = ctx.createRadialGradient(x, y, r * 0.1, x, y, r);
      grd.addColorStop(0, 'rgba(0,0,0,0.28)');
      grd.addColorStop(0.75, 'rgba(0,0,0,0.12)');
      grd.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.ellipse(x, y, r, r * 0.65, rng() * Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }

    // Seixos e pedrinhas com sombra e brilho
    for (let i = 0; i < 28; i++) {
      const px = rng() * CHUNK_PX;
      const py = rng() * CHUNK_PX;
      const pr = 1.5 + rng() * 3.5;
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.beginPath();
      ctx.ellipse(px + 1, py + 1.5, pr, pr * 0.7, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = zone.ground[3];
      ctx.beginPath();
      ctx.ellipse(px, py, pr, pr * 0.7, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Detalhes exclusivos por bioma
    if (zone.id === 0) {
      // Planície de Cinzas: dunas de cinza soprada e pequenas crateras de brasa
      ctx.strokeStyle = 'rgba(220,210,195,0.12)';
      ctx.lineWidth = 2;
      for (let i = 0; i < 7; i++) {
        const x = rng() * CHUNK_PX, y = rng() * CHUNK_PX;
        ctx.beginPath();
        ctx.moveTo(x - 36, y);
        ctx.quadraticCurveTo(x, y - 10, x + 36, y + 3);
        ctx.stroke();
      }
      for (let i = 0; i < 3; i++) {
        const x = 40 + rng() * (CHUNK_PX - 80), y = 40 + rng() * (CHUNK_PX - 80);
        const g = ctx.createRadialGradient(x, y, 1, x, y, 16);
        g.addColorStop(0, 'rgba(255,160,70,0.45)');
        g.addColorStop(0.5, 'rgba(60,25,10,0.4)');
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(x, y, 16, 0, Math.PI * 2); ctx.fill();
      }
    } else if (zone.id === 1) {
      // Rodovia Morta: faixas amarelas desgastadas de asfalto e marcas de pneu
      ctx.save();
      ctx.strokeStyle = 'rgba(235,185,60,0.28)';
      ctx.lineWidth = 5;
      ctx.setLineDash([22, 18]);
      ctx.beginPath();
      ctx.moveTo(CHUNK_PX * 0.5, 0);
      ctx.lineTo(CHUNK_PX * 0.5, CHUNK_PX);
      ctx.stroke();
      ctx.setLineDash([]);
      // marcas de derrapagem
      ctx.strokeStyle = 'rgba(10,10,12,0.42)';
      ctx.lineWidth = 3;
      for (let i = 0; i < 4; i++) {
        const x = rng() * CHUNK_PX, y = rng() * CHUNK_PX;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.quadraticCurveTo(x + 25, y + 35, x + (rng() - 0.5) * 60, y + 75);
        ctx.stroke();
      }
      ctx.restore();
    } else if (zone.id === 2) {
      // Pântano Ácido: poças borbulhantes de lodo ácido
      for (let i = 0; i < 4; i++) {
        const x = 45 + rng() * (CHUNK_PX - 90), y = 45 + rng() * (CHUNK_PX - 90);
        const rx = 20 + rng() * 26, ry = 13 + rng() * 18;
        const g = ctx.createRadialGradient(x, y, 2, x, y, rx);
        g.addColorStop(0, 'rgba(155,255,95,0.42)');
        g.addColorStop(0.65, 'rgba(50,120,40,0.38)');
        g.addColorStop(1, 'rgba(15,30,15,0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.ellipse(x, y, rx, ry, rng() * 2, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = 'rgba(150,255,100,0.35)';
        ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.arc(x + (rng() - 0.5) * 12, y + (rng() - 0.5) * 8, 3 + rng() * 4, 0, Math.PI * 2); ctx.stroke();
      }
    } else if (zone.id === 3) {
      // Cidade Afundada: juntas de calçada de concreto e poças d'água reflexivas
      ctx.strokeStyle = 'rgba(10,12,18,0.35)';
      ctx.lineWidth = 1.5;
      for (let g = 64; g < CHUNK_PX; g += 64) {
        ctx.beginPath(); ctx.moveTo(g, 0); ctx.lineTo(g, CHUNK_PX); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, g); ctx.lineTo(CHUNK_PX, g); ctx.stroke();
      }
      for (let i = 0; i < 3; i++) {
        const x = 40 + rng() * (CHUNK_PX - 80), y = 40 + rng() * (CHUNK_PX - 80);
        const rx = 22 + rng() * 28, ry = 14 + rng() * 16;
        const g = ctx.createRadialGradient(x, y, 2, x, y, rx);
        g.addColorStop(0, 'rgba(90,195,255,0.28)');
        g.addColorStop(0.7, 'rgba(30,65,100,0.24)');
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.ellipse(x, y, rx, ry, rng(), 0, Math.PI * 2); ctx.fill();
      }
    } else if (zone.id === 4) {
      // Fornalha: bolsões de magma incandescente
      for (let i = 0; i < 4; i++) {
        const x = 40 + rng() * (CHUNK_PX - 80), y = 40 + rng() * (CHUNK_PX - 80);
        const r = 16 + rng() * 22;
        const g = ctx.createRadialGradient(x, y, 1, x, y, r);
        g.addColorStop(0, 'rgba(255,230,120,0.6)');
        g.addColorStop(0.45, 'rgba(255,100,25,0.42)');
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.ellipse(x, y, r, r * 0.65, rng() * 3, 0, Math.PI * 2); ctx.fill();
      }
    } else if (zone.id === 5) {
      // Campos Vitrificados: linhas de fratura cristalina espelhada
      ctx.strokeStyle = 'rgba(185,238,255,0.32)';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < 6; i++) {
        const x = rng() * CHUNK_PX, y = rng() * CHUNK_PX;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + (rng() - 0.5) * 70, y + (rng() - 0.5) * 70);
        ctx.lineTo(x + (rng() - 0.5) * 90, y + (rng() - 0.5) * 90);
        ctx.stroke();
      }
    } else if (zone.id === 6) {
      // Coração da Cinza: círculos rúnicos corrompidos no chão
      for (let i = 0; i < 2; i++) {
        const x = 60 + rng() * (CHUNK_PX - 120), y = 60 + rng() * (CHUNK_PX - 120);
        const r = 24 + rng() * 18;
        ctx.strokeStyle = `rgba(${accRgb[0]},${accRgb[1]},${accRgb[2]},0.28)`;
        ctx.lineWidth = 1.8;
        ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.arc(x, y, r * 0.65, 0, Math.PI * 2); ctx.stroke();
      }
    }

    ctx.restore();
  }

  /** Colisão circular com props sólidos ao redor (apenas chunks necessários) */
  collide(x: number, y: number, r: number): { x: number; y: number } {
    const reach = r + 48;
    const x0 = Math.floor((x - reach) / CHUNK_PX), x1 = Math.floor((x + reach) / CHUNK_PX);
    const y0 = Math.floor((y - reach) / CHUNK_PX), y1 = Math.floor((y + reach) / CHUNK_PX);
    let px = x, py = y;
    for (let cy = y0; cy <= y1; cy++) {
      for (let cx = x0; cx <= x1; cx++) {
        const ch = this.get(cx, cy);
        for (const p of ch.props) {
          if (!p.solid) continue;
          const ddx = px - p.x, ddy = py - p.y;
          const rr = p.r + r;
          const d2 = ddx * ddx + ddy * ddy;
          if (d2 < rr * rr && d2 > 0.001) {
            const d = Math.sqrt(d2);
            const push = (rr - d) / d;
            px += ddx * push;
            py += ddy * push;
          }
        }
      }
    }
    return { x: px, y: py };
  }

  propsNear(x: number, y: number, range = CHUNK_PX): Prop[] {
    const out: Prop[] = [];
    const c0 = Math.floor(x / CHUNK_PX), c1 = Math.floor(y / CHUNK_PX);
    const rad = Math.ceil(range / CHUNK_PX);
    for (let dy = -rad; dy <= rad; dy++) {
      for (let dx = -rad; dx <= rad; dx++) {
        const ch = this.chunks.get(this.key(c0 + dx, c1 + dy));
        if (ch) out.push(...ch.props);
      }
    }
    return out;
  }
}
