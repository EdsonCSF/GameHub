// ============================================================
//  CINZAS — itens, afixos e loot procedural
// ============================================================
import { mulberry32, pick, clamp } from './rng';

export type StatKey =
  | 'power' | 'atkSpeed' | 'crit' | 'critDmg' | 'armor' | 'maxHp' | 'hpRegen'
  | 'speed' | 'luck' | 'range' | 'lifesteal' | 'thorns' | 'aoe' | 'proj' | 'xpGain' | 'scrapGain';

export type Stats = Record<StatKey, number>;

export const STAT_LABEL: Record<StatKey, string> = {
  power: 'Potência',
  atkSpeed: 'Vel. Ataque',
  crit: 'Crítico',
  critDmg: 'Dano Crítico',
  armor: 'Armadura',
  maxHp: 'Vida Máx.',
  hpRegen: 'Regeneração',
  speed: 'Mobilidade',
  luck: 'Sorte',
  range: 'Alcance',
  lifesteal: 'Roubo de Vida',
  thorns: 'Espinhos',
  aoe: 'Área',
  proj: 'Projéteis',
  xpGain: 'XP',
  scrapGain: 'Sucata',
};

export const PCT_STATS: StatKey[] = ['crit', 'critDmg', 'lifesteal', 'xpGain', 'scrapGain', 'aoe', 'atkSpeed', 'speed'];

export type Slot = 'arma' | 'nucleo' | 'armadura' | 'mascara' | 'botas' | 'talisma';
export const SLOTS: Slot[] = ['arma', 'nucleo', 'armadura', 'mascara', 'botas', 'talisma'];
export const SLOT_LABEL: Record<Slot, string> = {
  arma: 'Arma', nucleo: 'Núcleo', armadura: 'Armadura', mascara: 'Máscara', botas: 'Grevas', talisma: 'Talismã',
};

export type Rarity = 0 | 1 | 2 | 3 | 4 | 5;
export const RARITIES: { name: string; color: string; glow: string; mult: number; affixes: number }[] = [
  { name: 'Comum', color: '#9aa3ad', glow: 'rgba(154,163,173,0.45)', mult: 1.0, affixes: 1 },
  { name: 'Reforjado', color: '#5fe3a1', glow: 'rgba(95,227,161,0.45)', mult: 1.35, affixes: 2 },
  { name: 'Irradiante', color: '#41c8f5', glow: 'rgba(65,200,245,0.5)', mult: 1.8, affixes: 3 },
  { name: 'Áureo', color: '#f6c352', glow: 'rgba(246,195,82,0.55)', mult: 2.45, affixes: 4 },
  { name: 'Mítico', color: '#c86bff', glow: 'rgba(200,107,255,0.6)', mult: 3.35, affixes: 5 },
  { name: 'Eterno', color: '#ff7038', glow: 'rgba(255,112,56,0.65)', mult: 4.6, affixes: 6 },
];

export type Affix = { stat: StatKey; value: number; pct: boolean };

export type Item = {
  uid: string;
  slot: Slot;
  name: string;
  rarity: Rarity;
  ilvl: number;
  affixes: Affix[];
  seed: number;
  score: number;
};

const PRIMARY: Record<Slot, StatKey> = {
  arma: 'power', nucleo: 'power', armadura: 'maxHp', mascara: 'crit', botas: 'speed', talisma: 'lifesteal',
};
const SECONDARY: Record<Slot, StatKey[]> = {
  arma: ['atkSpeed', 'critDmg', 'crit', 'range', 'proj'],
  nucleo: ['critDmg', 'aoe', 'power', 'proj'],
  armadura: ['armor', 'hpRegen', 'thorns', 'maxHp'],
  mascara: ['luck', 'critDmg', 'crit', 'scrapGain'],
  botas: ['maxHp', 'speed', 'hpRegen', 'armor'],
  talisma: ['xpGain', 'scrapGain', 'lifesteal', 'luck'],
};

/** Curva de crescimento de cada afixo: base + crescimento * nível de item */
const AFFIX: Record<StatKey, { base: number; growth: number; flat: boolean; primary?: number }> = {
  power: { base: 3.2, growth: 0.44, flat: true, primary: 1 },
  maxHp: { base: 10, growth: 0.5, flat: true, primary: 1 },
  armor: { base: 1.1, growth: 0.44, flat: true },
  hpRegen: { base: 0.32, growth: 0.42, flat: true },
  thorns: { base: 0.9, growth: 0.42, flat: true },
  atkSpeed: { base: 0.03, growth: 0.013, flat: false },
  crit: { base: 0.009, growth: 0.0038, flat: false },
  critDmg: { base: 0.025, growth: 0.022, flat: false },
  speed: { base: 0.022, growth: 0.009, flat: false },
  range: { base: 0.022, growth: 0.011, flat: false },
  lifesteal: { base: 0.004, growth: 0.0018, flat: false },
  aoe: { base: 0.02, growth: 0.013, flat: false },
  proj: { base: 0.02, growth: 0.03, flat: true },
  luck: { base: 0.4, growth: 0.18, flat: true },
  xpGain: { base: 0.035, growth: 0.022, flat: false },
  scrapGain: { base: 0.045, growth: 0.028, flat: false },
};

let uidCounter = 1;

export function emptyStats(): Stats {
  return {
    power: 0, atkSpeed: 0, crit: 0, critDmg: 0, armor: 0, maxHp: 0, hpRegen: 0,
    speed: 0, luck: 0, range: 0, lifesteal: 0, thorns: 0, aoe: 0, proj: 0, xpGain: 0, scrapGain: 0,
  };
}



export function rollRarity(rng: () => number, luck: number, bonus = 0): Rarity {
  const l = 1 + luck * 0.12 + bonus;
  const r = rng() / l;
  if (r < 0.0035) return 5;
  if (r < 0.017) return 4;
  if (r < 0.062) return 3;
  if (r < 0.17) return 2;
  if (r < 0.42) return 1;
  return 0;
}

export function makeItem(ilvl: number, luck: number, rngSeed: number, forcedRarity?: Rarity, forcedSlot?: Slot): Item {
  const rng = mulberry32(rngSeed);
  const rarity = forcedRarity !== undefined ? forcedRarity : rollRarity(rng, luck);
  const slot = forcedSlot ?? pick(rng, SLOTS);
  const R = RARITIES[rarity];
  const affixes: Affix[] = [];

  const add = (stat: StatKey, mult = 1) => {
    const def = AFFIX[stat];
    const raw = (def.base + def.growth * ilvl) * R.mult * mult * (0.85 + rng() * 0.3);
    const flat = def.flat;
    const value = stat === 'proj'
      ? Math.max(1, Math.round(raw))
      : flat ? Math.max(1, Math.round(raw)) : raw;
    affixes.push({ stat, value, pct: !flat });
  };

  add(PRIMARY[slot], 1.5);
  const pool = SECONDARY[slot].slice();
  const n = Math.min(pool.length, R.affixes);
  for (let i = 0; i < n; i++) {
    const idx = Math.floor(rng() * pool.length);
    const st = pool.splice(idx, 1)[0];
    add(st, 0.85);
  }

  const item: Item = {
    uid: `i${uidCounter++}_${Math.floor(rng() * 1e6)}`,
    slot,
    name: '',
    rarity,
    ilvl,
    affixes,
    seed: Math.floor(rng() * 1e9),
    score: 0,
  };
  item.name = nomeDoItem(item, rng);
  item.score = itemScore(item);
  return item;
}

const SUFIXO: Record<Rarity, string[]> = {
  0: ['gasta', 'de sucata', 'rachada'],
  1: ['reforjada', 'afiada', 'remendada'],
  2: ['irradiante', 'zumbindo', 'de vidro'],
  3: ['áurea', 'incandescente', 'selada'],
  4: ['mítica', 'sussurrante', 'estrelar'],
  5: ['eterna', 'do último farol', 'de fogo vivo'],
};

function nomeDoItem(item: Item, rng: () => number): string {
  const base = SLOT_LABEL[item.slot];
  const adj = pick(rng, SUFIXO[item.rarity]);
  return `${base} ${adj}`;
}

export function itemScore(it: Item): number {
  let s = 0;
  for (const a of it.affixes) {
    const w = a.stat === 'power' ? 1 : a.stat === 'maxHp' ? 0.12 : a.stat === 'armor' ? 0.6
      : a.stat === 'atkSpeed' ? 26 : a.stat === 'crit' ? 120 : a.stat === 'critDmg' ? 55
        : a.stat === 'proj' ? 40 : a.stat === 'speed' ? 30 : a.stat === 'lifesteal' ? 90 : 4;
    s += a.value * w;
  }
  return Math.round(s);
}

export function isUpgrade(a: Item | null, b: Item | null): boolean {
  if (!a) return !!b;
  if (!b) return false;
  if (b.slot !== a.slot) return false;
  return b.score > a.score;
}

export function applyStats(target: Stats, it: Item) {
  for (const a of it.affixes) {
    target[a.stat] += a.value;
  }
}

export function statsDescription(it: Item): string[] {
  return it.affixes.map((a) => {
    const v = PCT_STATS.includes(a.stat)
      ? `${(a.value * 100).toFixed(a.value < 0.1 ? 1 : 0)}%`
      : a.stat === 'proj' ? `+${Math.round(a.value)}` : `${Math.round(a.value)}`;
    return `${STAT_LABEL[a.stat]} ${v.startsWith('+') ? '' : '+'}${v}`;
  });
}

export function clampStats(s: Stats) {
  s.crit = clamp(s.crit, 0, 0.85);
  s.atkSpeed = clamp(s.atkSpeed, 0.2, 6);
  s.speed = clamp(s.speed, 0.2, 3);
  s.proj = clamp(s.proj, 1, 12);
}
