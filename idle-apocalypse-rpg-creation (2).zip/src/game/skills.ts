// ============================================================
//  CINZAS — árvore de habilidades, prestígio e habilidades ativas
// ============================================================
import type { Stats, StatKey } from './items';

export type Branch = { id: number; name: string; color: string; icon: string; blurb: string };

export const BRANCHES: Branch[] = [
  { id: 0, name: 'Chama', color: '#ff7a3d', icon: '🜂', blurb: 'Dano, crítico e destruição em área.' },
  { id: 1, name: 'Aço', color: '#5fd0ff', icon: '🛡', blurb: 'Sobrevivência, armadura e retorno de dano.' },
  { id: 2, name: 'Vazio', color: '#c86bff', icon: '🜃', blurb: 'Mobilidade, projéteis, sorte e ganhos.' },
];

export type SkillNode = {
  id: string;
  branch: number;
  name: string;
  desc: (lvl: number) => string;
  max: number;
  req?: string;
  tier: number;
  flat?: { stat: StatKey; per: number; pct: boolean };
  special?: string;
};

export const SKILLS: SkillNode[] = [
  // --- CHAMA ---
  { id: 'fogo1', branch: 0, tier: 0, name: 'Brasa Viva', max: 20, flat: { stat: 'power', per: 0.08, pct: true }, desc: (l) => `+${(l * 8)}% Potência` },
  { id: 'fogo2', branch: 0, tier: 1, req: 'fogo1', name: 'Golpe Súbito', max: 15, flat: { stat: 'atkSpeed', per: 0.05, pct: true }, desc: (l) => `+${l * 5}% Vel. de Ataque` },
  { id: 'fogo3', branch: 0, tier: 1, req: 'fogo1', name: 'Ponto Fraco', max: 12, flat: { stat: 'crit', per: 0.02, pct: false }, desc: (l) => `+${(l * 2).toFixed(0)}% Crítico` },
  { id: 'fogo4', branch: 0, tier: 2, req: 'fogo2', name: 'Execução', max: 10, flat: { stat: 'critDmg', per: 0.15, pct: false }, desc: (l) => `+${l * 15}% Dano Crítico` },
  { id: 'fogo5', branch: 0, tier: 2, req: 'fogo3', name: 'Onda Expansiva', max: 10, flat: { stat: 'aoe', per: 0.12, pct: true }, special: 'aoe', desc: (l) => `+${l * 12}% Área de efeito` },
  { id: 'fogo6', branch: 0, tier: 3, req: 'fogo4', name: 'Fome do Fogo', max: 8, special: 'burn', flat: { stat: 'power', per: 0.1, pct: true }, desc: (l) => `Queimadura: ${l * 12}% do dano por 2s` },
  { id: 'fogo7', branch: 0, tier: 3, req: 'fogo5', name: 'Ruptura', max: 6, special: 'chain', desc: (l) => `Acertos ricocheteiam em +${l} alvo(s)` },

  // --- AÇO ---
  { id: 'aco1', branch: 1, tier: 0, name: 'Chassi Reforçado', max: 20, flat: { stat: 'maxHp', per: 0.1, pct: true }, desc: (l) => `+${l * 10}% Vida Máx.` },
  { id: 'aco2', branch: 1, tier: 1, req: 'aco1', name: 'Placas de Sucata', max: 15, flat: { stat: 'armor', per: 0.12, pct: true }, desc: (l) => `+${l * 12}% Armadura` },
  { id: 'aco3', branch: 1, tier: 1, req: 'aco1', name: 'Cicatrização', max: 12, flat: { stat: 'hpRegen', per: 0.18, pct: true }, desc: (l) => `+${l * 18}% Regeneração` },
  { id: 'aco4', branch: 1, tier: 2, req: 'aco2', name: 'Carapaça', max: 10, flat: { stat: 'thorns', per: 0.3, pct: true }, desc: (l) => `+${l * 30}% Espinhos` },
  { id: 'aco5', branch: 1, tier: 2, req: 'aco3', name: 'Sede de Sangue', max: 10, flat: { stat: 'lifesteal', per: 0.03, pct: false }, desc: (l) => `+${l * 3}% Roubo de Vida` },
  { id: 'aco6', branch: 1, tier: 3, req: 'aco4', name: 'Último Suspiro', max: 4, special: 'revive', desc: (l) => `Revive com ${25 * l}% da vida (${5 * l}s de invulnerabilidade)` },

  // --- VAZIO ---
  { id: 'vazio1', branch: 2, tier: 0, name: 'Passo Leve', max: 12, flat: { stat: 'speed', per: 0.06, pct: true }, desc: (l) => `+${l * 6}% Mobilidade` },
  { id: 'vazio2', branch: 2, tier: 1, req: 'vazio1', name: 'Cacos de Vitrificado', max: 8, flat: { stat: 'proj', per: 1, pct: false }, desc: (l) => `+${l} Projétil(is)` },
  { id: 'vazio3', branch: 2, tier: 1, req: 'vazio1', name: 'Faro de Sucata', max: 15, flat: { stat: 'scrapGain', per: 0.15, pct: true }, desc: (l) => `+${l * 15}% Sucata` },
  { id: 'vazio4', branch: 2, tier: 2, req: 'vazio2', name: 'Alcance Fantasma', max: 10, flat: { stat: 'range', per: 0.08, pct: true }, desc: (l) => `+${l * 8}% Alcance` },
  { id: 'vazio5', branch: 2, tier: 2, req: 'vazio3', name: 'Sorte do Abismo', max: 15, flat: { stat: 'luck', per: 0.3, pct: true }, desc: (l) => `+${l * 30}% Sorte` },
  { id: 'vazio6', branch: 2, tier: 3, req: 'vazio5', name: 'Eco do Farol', max: 10, flat: { stat: 'xpGain', per: 0.2, pct: true }, desc: (l) => `+${l * 20}% XP` },
];

export function applySkills(stats: Stats, levels: Record<string, number>) {
  for (const sk of SKILLS) {
    const lvl = levels[sk.id] || 0;
    if (!lvl || !sk.flat) continue;
    if (sk.flat.pct) stats[sk.flat.stat] *= 1 + sk.flat.per * lvl;
    else stats[sk.flat.stat] += sk.flat.per * lvl;
  }
}

export function skillSpecial(levels: Record<string, number>, key: string): number {
  const node = SKILLS.find((s) => s.special === key);
  if (!node) return 0;
  return levels[node.id] || 0;
}

// ------------------------------------------------------------
//  Prestígio — Cinzas Eternas
// ------------------------------------------------------------
export type Eternal = {
  id: string; name: string; desc: (l: number) => string; max: number;
  baseCost: number; growth: number; icon: string;
};

export const ETERNALS: Eternal[] = [
  { id: 'brasas', name: 'Brasas Herdadas', icon: '🔥', max: 50, baseCost: 1, growth: 1.35, desc: (l) => `+${l * 25}% Potência global` },
  { id: 'casco', name: 'Casco Ancestral', icon: '🛡', max: 50, baseCost: 1, growth: 1.35, desc: (l) => `+${l * 30}% Vida global` },
  { id: 'forja', name: 'Forja Eterna', icon: '⚒', max: 20, baseCost: 2, growth: 1.5, desc: (l) => `+${l * 8}% Sorte de item (rarity)` },
  { id: 'motor', name: 'Motor Ruidoso', icon: '⚙', max: 20, baseCost: 3, growth: 1.5, desc: (l) => `+${l * 6}% Vel. de Ataque` },
  { id: 'predador', name: 'Instinto Predador', icon: '🐺', max: 20, baseCost: 4, growth: 1.55, desc: (l) => `+${l * 20}% Dano em Chefes` },
  { id: 'colecionador', name: 'Colecionador', icon: '🧲', max: 20, baseCost: 3, growth: 1.45, desc: (l) => `+${l * 25}% Sucata e Essência` },
  { id: 'erudito', name: 'Erudito do Colapso', icon: '📖', max: 20, baseCost: 3, growth: 1.45, desc: (l) => `+${l * 25}% XP ganho` },
  { id: 'sentinela', name: 'Sentinela de Ferro', icon: '📡', max: 4, baseCost: 5, growth: 1.6, desc: (l) => `+${l * 25}% de chance de item ao abater` },
  { id: 'ciclone', name: 'Ciclone Interior', icon: '🌀', max: 10, baseCost: 6, growth: 1.6, desc: (l) => `-${l * 5}% recarga das habilidades` },
];

export function eternalCost(e: Eternal, lvl: number) {
  return Math.ceil(e.baseCost * Math.pow(e.growth, lvl));
}

export function applyEternals(stats: Stats, levels: Record<string, number>) {
  stats.power *= 1 + 0.25 * (levels.brasas || 0);
  stats.maxHp *= 1 + 0.3 * (levels.casco || 0);
  stats.atkSpeed *= 1 + 0.06 * (levels.motor || 0);
  stats.scrapGain *= 1 + 0.25 * (levels.colecionador || 0);
  stats.xpGain *= 1 + 0.25 * (levels.erudito || 0);
  stats.luck *= 1 + 0.5 * (levels.forja || 0);
}

// ------------------------------------------------------------
//  Habilidades ativas
// ------------------------------------------------------------
export type Ability = {
  id: 'nova' | 'beam' | 'shield';
  name: string; icon: string; cd: number; unlock: number; desc: string; color: string;
};

export const ABILITIES: Ability[] = [
  { id: 'nova', name: 'Onda de Cinza', icon: '✺', cd: 7, unlock: 3, color: '#ff8a3d', desc: 'Explosão ao redor, empurra e queima.' },
  { id: 'beam', name: 'Lança-Sol', icon: '☀', cd: 11, unlock: 8, color: '#ffd24a', desc: 'Feixe perfurante na direção do alvo.' },
  { id: 'shield', name: 'Manto de Brasas', icon: '❂', cd: 20, unlock: 14, color: '#5fd0ff', desc: 'Escudo absorve dano e reflete espinhos.' },
];
