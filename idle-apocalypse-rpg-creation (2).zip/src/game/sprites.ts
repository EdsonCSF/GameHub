// ============================================================
//  CINZAS — renderização com sprites ilustrados
// ============================================================
import { ASSETS, type Sprite } from './assets';
import type { EnemyKind } from './draw';

export type BossType = 'colossus' | 'wraith' | 'beast';

export type SpriteEnemyView = {
  kind: EnemyKind; bossType?: BossType;
  x: number; y: number; facing: number; anim: number;
  hitFlash: number; hp: number; maxHp: number;
  isBoss: boolean; isElite: boolean; accent: string;
  burn: number; stagger: number; enraged: boolean; spawnT: number; windup: number;
};

function spriteFor(e: SpriteEnemyView): { s: Sprite; h: number; float: number; alpha: number; red: boolean } | null {
  const A = ASSETS;
  if (!A) return null;
  if (e.isBoss) {
    const bt = e.bossType || 'colossus';
    if (bt === 'colossus') return { s: A.colossus, h: 175, float: 0, alpha: 1, red: false };
    if (bt === 'wraith') return { s: A.wraith, h: 195, float: 14, alpha: 0.96, red: false };
    return { s: A.beast, h: 128, float: 0, alpha: 1, red: false };
  }
  const el = e.isElite ? 1.3 : 1;
  switch (e.kind) {
    case 'batedor': return { s: A.ghoul, h: 58 * el, float: 0, alpha: 1, red: false };
    case 'bruto': return { s: A.ghoul, h: 80 * el, float: 0, alpha: 1, red: true };
    case 'cão': return { s: A.beast, h: 42 * el, float: 0, alpha: 1, red: false };
    case 'espectro': return { s: A.wraith, h: 66 * el, float: 8, alpha: 0.82, red: false };
    case 'drone': return { s: A.drone, h: 40 * el, float: 22, alpha: 1, red: false };
  }
  return null;
}

export function enemyTopY(e: SpriteEnemyView): number {
  const sp = spriteFor(e);
  if (!sp) return e.y - (e.isBoss ? 90 : 50);
  return e.y - sp.h - sp.float - 8;
}

export function drawEnemySprite(ctx: CanvasRenderingContext2D, e: SpriteEnemyView, t: number): boolean {
  const sp = spriteFor(e);
  if (!sp) return false;
  const { s, h, float } = sp;
  const w = (s.w / s.h) * h;
  const dir = e.facing >= 0 ? 1 : -1;
  const moving = e.stagger <= 0;
  const step = Math.sin(e.anim * (e.isBoss ? 5 : 9));
  const bob = moving ? Math.abs(step) * (e.isBoss ? 4 : 2.5) : 0;
  const hover = float > 0 ? Math.sin(t * 3 + e.anim) * 4 : 0;
  const breathe = e.isBoss ? 1 + Math.sin(t * 2.2) * 0.022 : 1;
  const spawnP = e.spawnT > 0 ? 1 - Math.min(1, e.spawnT / 1.8) : 1;
  const windShake = e.windup > 0 ? Math.sin(t * 60) * 2.5 : 0;

  // sombra
  ctx.save();
  ctx.fillStyle = 'rgba(0,0,0,0.45)';
  ctx.beginPath();
  ctx.ellipse(e.x, e.y + 1, w * 0.36 * (0.6 + spawnP * 0.4), Math.max(5, w * 0.1), 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // aura (chefe / elite / fúria)
  if (e.isBoss || e.isElite) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const col = e.enraged ? '255,40,40' : e.isBoss ? '255,70,60' : '255,210,80';
    const r = w * 0.55;
    const g = ctx.createRadialGradient(e.x, e.y - h * 0.45, 0, e.x, e.y - h * 0.45, r * 1.2);
    g.addColorStop(0, `rgba(${col},${0.2 + Math.sin(t * 4) * 0.06})`);
    g.addColorStop(1, `rgba(${col},0)`);
    ctx.fillStyle = g;
    ctx.fillRect(e.x - r * 1.3, e.y - h * 1.1, r * 2.6, h * 1.3);
    ctx.strokeStyle = `rgba(${col},${0.45 + Math.sin(t * 5) * 0.15})`;
    ctx.lineWidth = e.isBoss ? 3 : 2;
    ctx.beginPath();
    ctx.ellipse(e.x, e.y, w * 0.42, w * 0.13, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  ctx.save();
  ctx.translate(e.x + windShake, e.y - float - hover - bob);
  if (moving && !e.isBoss) ctx.rotate(step * 0.05);
  ctx.scale(dir * breathe, (1 / breathe) * (1 - bob * 0.006));

  // surgimento: sobe do chão
  if (spawnP < 1) {
    ctx.beginPath();
    ctx.rect(-w, -h * 1.2, w * 2, h * 1.2 + float + hover + bob);
    ctx.clip();
    ctx.translate(0, h * (1 - spawnP) * 0.9);
  }

  ctx.globalAlpha = sp.alpha;
  ctx.drawImage(s.img, -w / 2, -h, w, h);
  if (sp.red) {
    ctx.globalAlpha = 0.75;
    ctx.drawImage(s.red, -w / 2, -h, w, h);
  }
  if (e.enraged) {
    ctx.globalAlpha = 0.35 + Math.sin(t * 8) * 0.2;
    ctx.drawImage(s.red, -w / 2, -h, w, h);
  }
  if (e.windup > 0) {
    ctx.globalAlpha = 0.25 + Math.sin(t * 30) * 0.2;
    ctx.globalCompositeOperation = 'lighter';
    ctx.drawImage(s.red, -w / 2, -h, w, h);
    ctx.globalCompositeOperation = 'source-over';
  }
  if (e.burn > 0) {
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.28;
    ctx.drawImage(s.red, -w / 2, -h, w, h);
    ctx.globalCompositeOperation = 'source-over';
  }
  if (e.hitFlash > 0) {
    ctx.globalAlpha = Math.min(0.9, e.hitFlash * 6);
    ctx.drawImage(s.white, -w / 2, -h, w, h);
  }
  ctx.restore();

  // barra de vida (normais; chefes têm barra no HUD)
  if (!e.isBoss && e.hp < e.maxHp) {
    const bw = e.isElite ? 42 : 30;
    const by = e.y - h - float - 10;
    ctx.fillStyle = 'rgba(6,6,8,0.85)';
    ctx.fillRect(e.x - bw / 2 - 1, by - 1, bw + 2, 6);
    ctx.fillStyle = e.isElite ? '#ffd24a' : '#e0563f';
    ctx.fillRect(e.x - bw / 2, by, bw * Math.max(0, e.hp / e.maxHp), 4);
  }
  return true;
}

export type SpritePlayerView = {
  x: number; y: number; facing: number; anim: number; moving: boolean;
  shield: number; flash: number; t: number; swing: number; invuln: number;
};

export function drawPlayerSprite(ctx: CanvasRenderingContext2D, p: SpritePlayerView): boolean {
  const A = ASSETS;
  if (!A) return false;
  const s = A.hero;
  const h = 72;
  const w = (s.w / s.h) * h;
  const dir = p.facing >= 0 ? 1 : -1;
  const step = Math.sin(p.anim * 11);
  const bob = p.moving ? Math.abs(step) * 3 : Math.sin(p.t * 2) * 0.8;
  const tilt = p.moving ? step * 0.045 : 0;

  // sombra
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.beginPath();
  ctx.ellipse(p.x, p.y + 1, 17, 6, 0, 0, Math.PI * 2);
  ctx.fill();

  // luz da lanterna no chão
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const glow = ctx.createRadialGradient(p.x, p.y - 20, 6, p.x, p.y - 20, 120);
  const fl = 0.85 + Math.sin(p.t * 9) * 0.06 + Math.sin(p.t * 23) * 0.04;
  glow.addColorStop(0, `rgba(255,170,80,${0.22 * fl})`);
  glow.addColorStop(0.5, `rgba(255,120,40,${0.08 * fl})`);
  glow.addColorStop(1, 'rgba(255,100,30,0)');
  ctx.fillStyle = glow;
  ctx.fillRect(p.x - 120, p.y - 140, 240, 240);
  ctx.restore();

  ctx.save();
  ctx.translate(p.x, p.y - bob);
  ctx.rotate(tilt);
  ctx.scale(dir, 1 - bob * 0.008);
  if (p.invuln > 0) ctx.globalAlpha = 0.55 + Math.sin(p.t * 30) * 0.35;
  ctx.drawImage(s.img, -w / 2, -h, w, h);
  if (p.flash > 0) {
    ctx.globalAlpha = Math.min(0.8, p.flash * 2.5);
    ctx.drawImage(s.red, -w / 2, -h, w, h);
  }
  ctx.globalAlpha = 1;

  // núcleo de fogo pulsando
  ctx.globalCompositeOperation = 'lighter';
  const core = 0.75 + Math.sin(p.t * 6) * 0.25;
  const cx = w * 0.02, cy = -h * 0.63;
  const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, 16);
  cg.addColorStop(0, `rgba(255,230,160,${0.8 * core})`);
  cg.addColorStop(0.4, `rgba(255,140,50,${0.45 * core})`);
  cg.addColorStop(1, 'rgba(255,90,30,0)');
  ctx.fillStyle = cg;
  ctx.beginPath();
  ctx.arc(cx, cy, 16, 0, Math.PI * 2);
  ctx.fill();

  // arco do golpe
  if (p.swing > 0) {
    const a = p.swing;
    ctx.save();
    ctx.translate(w * 0.25, -h * 0.5);
    ctx.rotate(-0.9 + (1 - a) * 1.8);
    const arc = ctx.createLinearGradient(0, 0, 44, 0);
    arc.addColorStop(0, 'rgba(255,200,120,0)');
    arc.addColorStop(0.6, `rgba(255,160,70,${0.6 * a})`);
    arc.addColorStop(1, `rgba(255,245,210,${0.95 * a})`);
    ctx.strokeStyle = arc;
    ctx.lineWidth = 10 * a + 2;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(0, 0, 36, -1, 0.6);
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();

  if (p.shield > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = `rgba(95,208,255,${0.55 + Math.sin(p.t * 8) * 0.2})`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(p.x, p.y - 34, 32 + Math.sin(p.t * 5) * 2, 44, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 0.12;
    ctx.fillStyle = '#5fd0ff';
    ctx.fill();
    ctx.restore();
  }
  return true;
}

/** Explosão ilustrada (aditiva) */
export function drawExplosion(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, p: number, rot: number) {
  const A = ASSETS;
  if (!A) return;
  const scale = 0.35 + Math.pow(p, 0.5) * 0.9;
  const alpha = p < 0.15 ? p / 0.15 : 1 - (p - 0.15) / 0.85;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = Math.max(0, alpha);
  ctx.translate(x, y);
  ctx.rotate(rot);
  const s = size * scale;
  ctx.drawImage(A.explosion, -s / 2, -s / 2, s, s);
  ctx.restore();
}
