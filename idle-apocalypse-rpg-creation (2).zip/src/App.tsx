import { useCallback, useEffect, useRef, useState } from 'react';
import { Game, type Snapshot } from './game/engine';
import { ZONES } from './game/world';
import { audio } from './game/audio';
import { loadAssets } from './game/assets';
import { fmt, fmtTime } from './game/rng';
import { Hud, type PanelId } from './components/Hud';
import { BagPanel, EternalPanel, FirePanel, InfoPanel, MapPanel, Panel } from './components/Panels';
import { StartMenu } from './components/StartMenu';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const gameRef = useRef<Game | null>(null);
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [panel, setPanel] = useState<PanelId>(null);
  const [intro, setIntro] = useState(true);
  const [offline, setOffline] = useState<{ kills: number; xp: number; scrap: number; sec: number } | null>(null);
  const [ready, setReady] = useState(false);

  // ---------------- boot ----------------
  useEffect(() => {
    const game = new Game();
    gameRef.current = game;
    const z = ZONES[game.state.zone];
    setSnap(game.snapshot());
    if (game.offlineReport) {
      setOffline(game.offlineReport);
      game.offlineReport = null;
    }

    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d', { alpha: false })!;
    let W = 0, H = 0, dpr = 1;

    const resize = () => {
      dpr = Math.min(2, window.devicePixelRatio || 1);
      W = window.innerWidth;
      H = window.innerHeight;
      canvas.width = Math.floor(W * dpr);
      canvas.height = Math.floor(H * dpr);
      canvas.style.width = W + 'px';
      canvas.style.height = H + 'px';
    };
    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('orientationchange', resize);

    let raf = 0;
    let last = performance.now();
    let hidden = false;
    let bgTimer: number | null = null;

    const frame = (now: number) => {
      const dt = Math.min(0.06, (now - last) / 1000);
      last = now;
      if (!hidden) {
        game.update(dt);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        game.render(ctx, W, H);
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    const poll = window.setInterval(() => setSnap(game.snapshot()), 130);

    const onVis = () => {
      hidden = document.hidden;
      if (document.hidden) {
        game.save();
        last = performance.now();
        bgTimer = window.setInterval(() => game.update(1), 1000);
      } else if (bgTimer !== null) {
        window.clearInterval(bgTimer);
        bgTimer = null;
        last = performance.now();
      }
    };
    document.addEventListener('visibilitychange', onVis);
    const onLeave = () => game.save();
    window.addEventListener('beforeunload', onLeave);
    window.addEventListener('pagehide', onLeave);

    audio.setMood(z.root, z.scale, z.tempo);
    loadAssets()
      .then(() => setReady(true))
      .catch(() => setReady(true)); // se algo falhar, o jogo usa a arte procedural

    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(poll);
      if (bgTimer !== null) window.clearInterval(bgTimer);
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('beforeunload', onLeave);
      window.removeEventListener('pagehide', onLeave);
      window.removeEventListener('resize', resize);
      window.removeEventListener('orientationchange', resize);
      game.save();
    };
  }, []);

  // ---------------- input ----------------
  const toWorld = useCallback((cx: number, cy: number) => {
    const g = gameRef.current;
    if (!g) return { x: 0, y: 0 };
    const W = window.innerWidth, H = window.innerHeight;
    const zoom = g.zoom;
    return { x: (cx - W / 2) / zoom + g.camX, y: (cy - H / 2) / zoom + g.camY };
  }, []);

  const onPointerDown = (e: React.PointerEvent) => {
    const g = gameRef.current;
    if (!g) return;
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    const w = toWorld(e.clientX, e.clientY);
    g.pointer = { active: true, x: w.x, y: w.y };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const g = gameRef.current;
    if (!g || !g.pointer.active) return;
    const w = toWorld(e.clientX, e.clientY);
    g.pointer.x = w.x; g.pointer.y = w.y;
  };
  const onPointerUp = () => {
    const g = gameRef.current;
    if (g) g.pointer.active = false;
  };

  const start = () => {
    audio.resume();
    const g = gameRef.current;
    const z = ZONES[g?.state.zone ?? 0];
    audio.setMood(z.root, z.scale, z.tempo);
    g?.markIntro();
    setIntro(false);
  };

  const g = gameRef.current;

  return (
    <div className="relative h-[100dvh] w-screen select-none overflow-hidden bg-black text-white"
      style={{ touchAction: 'none', fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace' }}>
      <canvas
        ref={canvasRef}
        className="absolute inset-0 block"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
      />

      {snap && <Hud snap={snap} game={g!} panel={panel} setPanel={setPanel} />}

      {/* ---------------- PAINÉIS ---------------- */}
      {snap && panel && g && (
        <>
          {panel === 'bag' && (
            <Panel title="Mochila" subtitle={`${snap.inventory.length} relíquias carregadas`} onClose={() => setPanel(null)}>
              <BagPanel snap={snap} game={g} />
            </Panel>
          )}
          {panel === 'fire' && (
            <Panel title="Árvore de Fogo" subtitle="Três caminhos, um farol" onClose={() => setPanel(null)}>
              <FirePanel snap={snap} game={g} />
            </Panel>
          )}
          {panel === 'map' && (
            <Panel title="Mapa do Colapso" subtitle="viaje para regiões mais fundas" onClose={() => setPanel(null)}>
              <MapPanel snap={snap} game={g} />
            </Panel>
          )}
          {panel === 'eternal' && (
            <Panel title="Forja Eterna" subtitle="o que sobrevive ao renascimento" onClose={() => setPanel(null)}>
              <EternalPanel snap={snap} game={g} />
            </Panel>
          )}
          {panel === 'info' && (
            <Panel title="Status" subtitle="diário · som · perigos" onClose={() => setPanel(null)}>
              <InfoPanel
                snap={snap}
                game={g}
                onReset={() => setPanel(null)}
                onOpenMenu={() => { setPanel(null); setIntro(true); }}
              />
            </Panel>
          )}
        </>
      )}

      {/* ---------------- RELATÓRIO OFFLINE ---------------- */}
      {offline && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/80 p-6">
          <div className="w-full max-w-sm rounded-2xl border border-amber-400/25 bg-[#0b0a0e] p-5 text-center">
            <div className="text-3xl">🜂</div>
            <h3 className="mt-2 font-mono text-[12px] font-bold uppercase tracking-[0.2em] text-amber-200">O farol ficou aceso</h3>
            <p className="mt-1 font-mono text-[10px] text-white/40">Enquanto você esteve fora ({fmtTime(offline.sec)})</p>
            <div className="mt-4 space-y-1.5">
              {[['Abates', fmt(offline.kills), '#ff9a4a'], ['Experiência', fmt(offline.xp), '#a678ff'], ['Sucata', fmt(offline.scrap), '#ffd24a']].map(([l, v, c]) => (
                <div key={l} className="flex justify-between rounded-lg border border-white/10 bg-black/50 px-3 py-1.5">
                  <span className="font-mono text-[10px] text-white/45">{l}</span>
                  <span className="font-mono text-[11px] font-bold" style={{ color: c }}>+{v}</span>
                </div>
              ))}
            </div>
            <button onClick={() => setOffline(null)} className="mt-4 w-full rounded-xl border border-amber-300/40 bg-amber-500/15 py-2.5 font-mono text-[11px] font-bold uppercase tracking-[0.15em] text-amber-100 active:scale-95">
              coletar
            </button>
          </div>
        </div>
      )}

      {/* ---------------- MENU INICIAL ---------------- */}
      {intro && <StartMenu ready={ready} snap={snap} onStart={start} />}
    </div>
  );
}
